# MiFlix Extractor

Mini navegador que te muestra los enlaces reales de video (.m3u8, .mp4, .mpd…) que carga una página, para pegarlos en MiFlix cuando MiFlix no los detecta solo.

## Cómo se usa
1. Pega el enlace de la página (📋 pega desde el portapapeles) o, desde tu navegador, usa **Compartir → MiFlix Extractor**.
2. Dale **play** al video dentro de la página. Los enlaces aparecen en el botón rojo 🔗 abajo a la derecha.
3. Ábrelo: el marcado con ★ es el principal (el más largo que responde). Toca un enlace para **copiarlo** (o *Compartir*).
4. En MiFlix, pégalo al agregar o editar la película o el capítulo.

## Reproductores e iframes
- Ahora también entra en los iframes: lee lo que pide y recibe el reproductor (fetch/XHR, JW Player), detecta listas HLS/DASH sin extensión y lista los REPRODUCTOR (iframe) con botón «Abrir».
- Cada enlace se verifica con el Referer real del reproductor; el botón «Referer» lo copia.

## Notas
- Cada enlace se comprueba en segundo plano: ✓ responde y cuánto dura. «sin verificar» no significa que no sirva: algunos servidores solo responden dentro del reproductor.
- Se ocultan tráilers, miniaturas y anuncios; actívalos con **Mostrar todos** si el video que buscas no sale.
- 🖥 cambia a modo escritorio (algunas páginas muestran otro reproductor); ⟳ recarga y vuelve a buscar.
- Funciona con enlaces normales. No sirve con videos protegidos con DRM (Netflix, Disney+, etc.), que no exponen un enlace reproducible.
- Compilar: igual que MiFlix (GitHub o Android Studio). Usa la misma firma `miflix.jks`.

## Protección (🛡) contra anuncios y redirecciones
- La página **se queda donde está**: después de cargarla, ningún salto automático ni ventana emergente puede sacarte de ella. Solo se permite un toque real dentro del mismo sitio (por ejemplo, otro capítulo).
- Se bloquean: `window.open` y ventanas nuevas, enlaces que abren otro sitio, redirecciones de JavaScript o `meta refresh`, apps externas (`intent://`, `market://`), dominios de anuncios y las capas transparentes que cubren el video para robar el primer toque.
- El contador 🛡 de arriba muestra cuántas cosas se han bloqueado. Tócalo para apagar o encender la protección.
- Si algo legítimo se bloquea, sale un aviso abajo («Bloqueado: sitio · Permitir»): tócalo para ir ahí. Lo que escribes tú en la barra, ⟳ y «Permitir» nunca se bloquean.
