package com.miflix.extractor

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

/**
 * MiFlix Extractor: un mini navegador que muestra los enlaces de video (.m3u8, .mp4, .mpd…)
 * que la página pide mientras se reproduce, para copiarlos y pegarlos en MiFlix.
 */
class MainActivity : Activity() {
    private class Hit(
        val url: String,
        val kind: String,          // HLS, MP4, DASH, WEBM, MKV, SUB
        val maybe: Boolean,        // parece tráiler / miniatura / anuncio
        val referer: String
    ) {
        var checked = false
        var ok = false
        var durMs = 0L
        var master = false
    }

    private lateinit var web: WebView
    private lateinit var urlBox: EditText
    private lateinit var bar: ProgressBar
    private lateinit var fab: TextView
    private val hits = LinkedHashMap<String, Hit>()
    private val pool = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())
    private var dialog: AlertDialog? = null
    private var listBox: LinearLayout? = null
    private var showAll = false
    private var desktop = false
    private var pageUrl = ""
    private var ua = ""
    // ---- protección: anuncios, ventanas emergentes y redirecciones ----
    private var protect = true          // 🛡 activada
    private var navAllowed = false      // true mientras carga lo que la persona pidió (URL escrita, recargar, «Permitir»)
    private var blocked = 0
    private lateinit var shield: TextView
    private lateinit var banner: TextView
    private var bannerUrl = ""
    private val hideBanner = Runnable { banner.visibility = View.GONE }
    private var dp = 1f

    companion object {
        private val ADS = listOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "popads.net", "popcash.net", "propellerads.com", "adsterra.com", "exoclick.com", "exosrv.com",
            "juicyads.com", "trafficjunky.com", "adnxs.com", "taboola.com", "outbrain.com", "onclickads.net",
            "onclkds.com", "clickadu.com", "hilltopads.net", "mgid.com", "revcontent.com", "adcash.com",
            "a-ads.com", "admaven.com", "ad-maven.com", "adsco.re", "pubfuture.com", "richads.com",
            "trafficstars.com", "adskeeper.com", "yllix.com", "bidvertiser.com", "clickaine.com"
        )
        private val STREAM_EXT = listOf(".m3u8", ".mpd", ".mp4", ".webm", ".mkv", ".m4v", ".mov")
        private val SUB_EXT = listOf(".vtt", ".srt", ".ass", ".ssa", ".ttml", ".dfxp")
        private val MAYBE = listOf("/ads/", "/ad/", "preroll", "banner", "sprite", "thumb", "preview", "teaser", "trailer")
        private const val DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

        private val AD_WORDS = listOf(
            "popunder", "popads", "popcash", "adsterra", "exoclick", "propellerads", "clickadu", "juicyads",
            "trafficjunky", "adcash", "hilltopads", "onclickads", "adserver", "doubleclick", "adnxs", "googlesyndication",
            "pushwhy", "pushance", "notifpush", "tsyndicate", "realsrv", "syndication.exosrv"
        )

        fun isAd(host: String?): Boolean {
            if (host == null) return false
            val h = host.lowercase()
            return ADS.any { h == it || h.endsWith(".$it") } || AD_WORDS.any { h.contains(it) } ||
                h.startsWith("ads.") || h.contains(".ads.")
        }

        /** Dominio "principal" (aprox.): www.sitio.com y video.sitio.com cuentan como el mismo sitio */
        fun siteOf(host: String?): String {
            val h = (host ?: "").lowercase().removePrefix("www.")
            val p = h.split('.')
            if (p.size <= 2) return h
            val sl = setOf("co", "com", "org", "net", "gov", "edu", "ac")
            return if (p.last().length == 2 && p[p.size - 2] in sl) p.takeLast(3).joinToString(".") else p.takeLast(2).joinToString(".")
        }

        /**
         * Se ejecuta al empezar cada página y en cada iframe: bloquea window.open, clics que mandan a otro sitio
         * y las capas transparentes que cubren el video para robar el primer toque (el truco de los anuncios).
         */
        private val GUARD = """(function(){if(window.__mg)return;window.__mg=1;
try{Object.defineProperty(window,'open',{value:function(){try{MX.blocked('')}catch(e){}return null},writable:false,configurable:false})}catch(e){window.open=function(){return null}}
function site(h){var p=String(h||'').toLowerCase().replace(/^www\./,'').split('.');if(p.length<=2)return p.join('.');var sl={co:1,com:1,org:1,net:1,gov:1,edu:1,ac:1};return(p[p.length-1].length==2&&sl[p[p.length-2]])?p.slice(-3).join('.'):p.slice(-2).join('.')}
var me=site(location.hostname);
function on(){return window.__mgOn!==false}
document.addEventListener('click',function(e){if(!on())return;var a=e.target&&e.target.closest?e.target.closest('a[href]'):null;if(!a)return;var bad=false;
try{var u=new URL(a.href,location.href);bad=(a.target==='_blank')||(/^https?:$/.test(u.protocol)&&site(u.hostname)!==me)||(!/^https?:$/.test(u.protocol)&&u.protocol!=='javascript:')}catch(x){}
if(bad){e.preventDefault();e.stopImmediatePropagation();try{MX.blocked(a.href)}catch(x){}}},true);
try{var oc=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){if(on()){try{var u=new URL(this.href,location.href);if(this.target==='_blank'||site(u.hostname)!==me)return}catch(x){}}return oc.apply(this,arguments)}}catch(e){}
function sweep(){if(!on())return;try{var W=innerWidth,H=innerHeight;if(!W||!H||!document.body)return;var els=document.body.querySelectorAll('div,a,span,section');
for(var i=0;i<els.length;i++){var el=els[i],cs=getComputedStyle(el);if(cs.position!=='fixed'&&cs.position!=='absolute')continue;var r=el.getBoundingClientRect();if(r.width<W*0.85||r.height<H*0.85)continue;
if((parseInt(cs.zIndex)||0)<100)continue;if(el.querySelector('video,iframe,canvas,input,button,img,svg,form,object,embed'))continue;if(el.textContent.trim().length>0)continue;el.remove()}}catch(e){}}
setInterval(sweep,600)})();"""

        fun kindOf(u: Uri): String? {
            val full = u.toString().lowercase()
            val path = (u.path ?: "").lowercase()
            return when {
                path.endsWith(".m3u8") || full.contains(".m3u8") -> "HLS"
                path.endsWith(".mpd") || full.contains(".mpd?") -> "DASH"
                path.endsWith(".mp4") || path.endsWith(".m4v") || path.endsWith(".mov") -> "MP4"
                path.endsWith(".webm") -> "WEBM"
                path.endsWith(".mkv") -> "MKV"
                SUB_EXT.any { path.endsWith(it) } -> "SUB"
                else -> null
            }
        }

        /** Busca el <video> de la página, intenta darle play (en silencio) y revisa el código por enlaces de video */
        private val SNIFF = """(function(){if(window.__mx)return;window.__mx=1;var seen={};
function rep(u,d){try{if(u&&/^https?:/i.test(u)&&!seen[u]){seen[u]=1;MX.link(u,(isFinite(d)&&d>0&&d<259200)?d:0)}}catch(e){}}
function scan(){var v=document.querySelectorAll('video');for(var i=0;i<v.length;i++){var x=v[i],s=x.currentSrc||x.src;
if(s&&s.indexOf('blob:')!==0){rep(s,x.duration)}else{try{x.muted=true;var p=x.play();if(p&&p.catch)p.catch(function(){})}catch(e){}}
var t=x.querySelectorAll('track');for(var k=0;k<t.length;k++){if(t[k].src)rep(t[k].src,0)}}
var b=document.querySelector('.vjs-big-play-button,.jw-icon-display,.plyr__control--overlaid,.play-button,[class*="play-btn"],[class*="PlayButton"]');if(b){try{b.click()}catch(e){}}}
function html(){try{var t=document.documentElement.innerHTML.replace(/\\\//g,'/').replace(/&amp;/g,'&');
var r=t.match(/https?:\/\/[^\s"'<>\\)]+?\.(?:m3u8|mpd|mp4|webm|mkv|vtt|srt)(?:\?[^\s"'<>\\)]*)?/gi);
if(r)for(var i=0;i<r.length;i++)rep(r[i],0)}catch(e){}}
setInterval(scan,1000);setInterval(html,3000);html()})();"""
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dp = resources.displayMetrics.density
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF141414.toInt())

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setBackgroundColor(0xFF1C1C1C.toInt())
        top.setPadding(px(6), px(6), px(6), px(6))
        urlBox = EditText(this)
        urlBox.hint = "Pega o escribe el enlace de la página"
        urlBox.setHintTextColor(0xFF888888.toInt())
        urlBox.setTextColor(Color.WHITE)
        urlBox.textSize = 14f
        urlBox.setSingleLine(true)
        urlBox.inputType = InputType.TYPE_TEXT_VARIATION_URI
        urlBox.imeOptions = EditorInfo.IME_ACTION_GO
        urlBox.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_GO) { go(); true } else false }
        top.addView(urlBox, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(smallBtn("📋") { pasteFromClipboard() })
        top.addView(smallBtn("⟳") { if (pageUrl.isNotEmpty()) { clearHits(); navAllowed = true; web.reload() } })
        top.addView(smallBtn("🖥") { toggleDesktop() })
        shield = smallBtn("🛡 0") { toggleProtect() }
        top.addView(shield)
        top.addView(smallBtn("Ir") { go() })
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.visibility = View.GONE
        root.addView(bar, LinearLayout.LayoutParams(-1, px(3)))

        val frame = FrameLayout(this)
        web = WebView(this)
        web.setBackgroundColor(0xFF000000.toInt())
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(true)   // así las ventanas emergentes llegan a onCreateWindow y se descartan
        s.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        ua = s.userAgentString
        CookieManager.getInstance().setAcceptCookie(true)
        web.addJavascriptInterface(object {
            @JavascriptInterface
            fun link(u: String, dur: Double) { ui.post { add(u, (dur * 1000).toLong()) } }

            @JavascriptInterface
            fun blocked(u: String) { ui.post { onBlocked(u) } }
        }, "MX")
        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                onBlocked("")      // ventana emergente: se descarta, la página sigue donde está
                return false
            }

            override fun onProgressChanged(view: WebView, p: Int) {
                bar.progress = p
                bar.visibility = if (p in 1..99) View.VISIBLE else View.GONE
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, r: WebResourceRequest): Boolean {
                val sc = r.url.scheme
                if (sc != "http" && sc != "https") { onBlocked(""); return true }   // nada de abrir otras apps (intent://, market://…)
                if (!protect) return false
                if (isAd(r.url.host)) { onBlocked(""); return true }
                if (!r.isForMainFrame) return false           // iframes: solo se filtran los anuncios
                if (navAllowed) return false                   // lo pidió la persona (URL escrita, recargar, «Permitir»)
                // Ya cargada la página: solo se permite un toque real dentro del mismo sitio. Todo lo demás se queda donde está.
                val same = siteOf(r.url.host) == siteOf(Uri.parse(pageUrl).host)
                if (r.hasGesture() && same) return false
                onBlocked(r.url.toString())
                return true
            }

            override fun shouldInterceptRequest(view: WebView, r: WebResourceRequest): WebResourceResponse? {
                if (protect && isAd(r.url.host)) {
                    ui.post { count() }
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                val k = kindOf(r.url)
                if (k != null) ui.post { add(r.url.toString(), 0, k) }
                return null
            }

            override fun onPageStarted(view: WebView, url: String, f: android.graphics.Bitmap?) {
                pageUrl = url
                view.evaluateJavascript("window.__mgOn=$protect;" + GUARD, null)
                if (!urlBox.hasFocus()) urlBox.setText(url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                navAllowed = false                           // a partir de aquí, nada de saltos solos a otra página
                view.evaluateJavascript(GUARD, null)
                view.evaluateJavascript(SNIFF, null)
            }
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            // Antes de que corra cualquier script de la página (también dentro de iframes)
            try { WebViewCompat.addDocumentStartJavaScript(web, GUARD, setOf("*")) } catch (e: Exception) {}
        }
        frame.addView(web, FrameLayout.LayoutParams(-1, -1))

        banner = TextView(this)
        banner.setTextColor(Color.WHITE)
        banner.textSize = 13f
        banner.setPadding(px(14), px(10), px(14), px(10))
        val bb = GradientDrawable()
        bb.setColor(0xEE222222.toInt())
        bb.cornerRadius = px(20).toFloat()
        bb.setStroke(1, 0x66FFFFFF)
        banner.background = bb
        banner.visibility = View.GONE
        banner.setOnClickListener {
            val u = bannerUrl
            banner.visibility = View.GONE
            if (u.isNotEmpty()) { navAllowed = true; web.loadUrl(u) }
        }
        val blp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START)
        blp.setMargins(px(12), 0, px(90), px(24))
        frame.addView(banner, blp)

        fab = TextView(this)
        fab.text = "🔗 0"
        fab.setTextColor(Color.WHITE)
        fab.textSize = 16f
        fab.typeface = Typeface.DEFAULT_BOLD
        fab.gravity = Gravity.CENTER
        fab.setPadding(px(18), px(12), px(18), px(12))
        val bg = GradientDrawable()
        bg.setColor(0xFFE50914.toInt())
        bg.cornerRadius = px(28).toFloat()
        fab.background = bg
        fab.elevation = px(8).toFloat()
        fab.setOnClickListener { showList() }
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END)
        lp.setMargins(0, 0, px(16), px(20))
        frame.addView(fab, lp)
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        handleIntent(intent)
        if (pageUrl.isEmpty()) showHelp()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val m = Regex("https?://\\S+").find(t) ?: return
            urlBox.setText(m.value)
            go()
        }
    }

    private fun px(v: Int) = (v * dp).toInt()

    private fun smallBtn(t: String, f: () -> Unit): TextView {
        val b = TextView(this)
        b.text = t
        b.setTextColor(Color.WHITE)
        b.textSize = 16f
        b.gravity = Gravity.CENTER
        b.minimumWidth = px(40)
        b.setPadding(px(8), px(8), px(8), px(8))
        b.setOnClickListener { f() }
        return b
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ---------- navegación ----------
    private fun go() {
        var u = urlBox.text.toString().trim()
        if (u.isEmpty()) return
        if (!u.contains("://")) u = if (u.contains(' ') || !u.contains('.')) "https://www.google.com/search?q=" + Uri.encode(u) else "https://$u"
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(urlBox.windowToken, 0)
        urlBox.clearFocus()
        clearHits()
        navAllowed = true
        pageUrl = u
        web.loadUrl(u)
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
        if (t.isNullOrEmpty()) { toast("El portapapeles está vacío"); return }
        urlBox.setText(t)
        go()
    }

    private fun toggleDesktop() {
        desktop = !desktop
        web.settings.userAgentString = if (desktop) DESKTOP_UA else ua
        toast(if (desktop) "Modo escritorio activado" else "Modo móvil activado")
        if (pageUrl.isNotEmpty()) { clearHits(); navAllowed = true; web.reload() }
    }

    // ---------- protección ----------
    private fun count() {
        blocked++
        shield.text = (if (protect) "🛡 " else "⚠ ") + blocked
    }

    /** Se bloqueó un anuncio, una ventana emergente o un salto a otra página */
    private fun onBlocked(u: String) {
        if (!protect) return
        count()
        val host = try { Uri.parse(u).host } catch (e: Exception) { null }
        if (u.startsWith("http") && !host.isNullOrEmpty() && !isAd(host)) {
            // Por si fue un falso positivo: un toque para permitirlo
            bannerUrl = u
            banner.text = "🛡 Bloqueado: $host  ·  Permitir"
            banner.visibility = View.VISIBLE
            ui.removeCallbacks(hideBanner)
            ui.postDelayed(hideBanner, 6000)
        }
    }

    private fun toggleProtect() {
        protect = !protect
        shield.text = (if (protect) "🛡 " else "⚠ ") + blocked
        web.evaluateJavascript("window.__mgOn=$protect", null)
        toast(if (protect) "Protección activada: sin anuncios ni redirecciones" else "Protección desactivada")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        pool.shutdownNow()
        web.destroy()
        super.onDestroy()
    }

    // ---------- enlaces encontrados ----------
    private fun clearHits() {
        hits.clear()
        blocked = 0
        shield.text = (if (protect) "🛡 " else "⚠ ") + 0
        fab.text = "🔗 0"
        refresh()
    }

    private fun add(raw: String, durMs: Long, kind0: String? = null) {
        val u = raw.substringBefore('#')
        val uri = Uri.parse(u)
        if (isAd(uri.host)) return
        val k = kind0 ?: kindOf(uri) ?: "MP4"
        if (hits.containsKey(u)) return
        val low = u.lowercase()
        val h = Hit(u, k, MAYBE.any { low.contains(it) }, pageUrl)
        if (durMs > 0) h.durMs = durMs
        hits[u] = h
        fab.text = "🔗 ${visible().size}"
        refresh()
        val uaNow = web.settings.userAgentString   // se lee aquí (hilo principal); WebView no permite leerlo desde otro hilo
        if (k != "SUB") pool.execute {
            val hd = HashMap<String, String>()
            hd["User-Agent"] = uaNow
            if (h.referer.startsWith("http")) {
                hd["Referer"] = h.referer
                val p = Uri.parse(h.referer)
                hd["Origin"] = "${p.scheme}://${p.host}"
            }
            val ck = try { CookieManager.getInstance().getCookie(u) } catch (e: Exception) { null }
            if (!ck.isNullOrEmpty()) hd["Cookie"] = ck
            val r = Probe.check(u, hd)
            ui.post {
                h.checked = true
                h.ok = r.ok
                if (r.durMs > 0 && h.durMs == 0L) h.durMs = r.durMs
                h.master = r.master
                fab.text = "🔗 ${visible().size}"
                refresh()
            }
        }
    }

    /** Lo que se muestra: sin sospechosos (a menos que se pida todo) y, si hay lista maestra HLS, sin sus calidades sueltas */
    private fun visible(): List<Hit> {
        var l = hits.values.toList()
        if (!showAll) l = l.filter { !it.maybe || it.kind == "SUB" }
        val hasMaster = l.any { it.kind == "HLS" && it.checked && it.master }
        if (!showAll && hasMaster) l = l.filter { !(it.kind == "HLS" && it.checked && !it.master) }
        return l.sortedWith(compareBy<Hit> { it.kind == "SUB" }.thenByDescending { it.durMs })
    }

    private fun best(): Hit? = visible().firstOrNull { it.kind != "SUB" && (it.ok || !it.checked) }

    private fun fmt(ms: Long, estimated: Boolean): String {
        if (ms <= 0) return ""
        val s = ms / 1000
        val t = if (s >= 3600) "${s / 3600} h ${(s % 3600) / 60} min" else "${s / 60} min ${s % 60} s"
        return t
    }

    private fun copy(u: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("enlace", u))
        toast("Enlace copiado ✓ Pégalo en MiFlix")
    }

    private fun share(u: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, u), "Compartir enlace"))
    }

    private fun showList() {
        dialog?.dismiss()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(px(14), px(14), px(14), px(6))
        val sv = ScrollView(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        sv.addView(box)
        listBox = box
        val head = TextView(this)
        head.text = "Enlaces encontrados"
        head.setTextColor(Color.WHITE)
        head.textSize = 18f
        head.typeface = Typeface.DEFAULT_BOLD
        col.addView(head)
        val tip = TextView(this)
        tip.text = "Dale play al video en la página para que aparezca. Toca un enlace para copiarlo."
        tip.setTextColor(0xFFAAAAAA.toInt())
        tip.textSize = 12f
        tip.setPadding(0, px(2), 0, px(8))
        col.addView(tip)
        val bestBtn = Button(this)
        bestBtn.text = "Copiar el principal"
        bestBtn.setOnClickListener { val b = best(); if (b == null) toast("Aún no hay enlaces") else copy(b.url) }
        col.addView(bestBtn)
        val cb = CheckBox(this)
        cb.text = "Mostrar todos (incluye tráilers y avances)"
        cb.setTextColor(0xFFDDDDDD.toInt())
        cb.textSize = 13f
        cb.isChecked = showAll
        cb.setOnCheckedChangeListener { _, v -> showAll = v; fab.text = "🔗 ${visible().size}"; refresh() }
        col.addView(cb)
        col.addView(sv, LinearLayout.LayoutParams(-1, px(300)))
        dialog = AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setView(col)
            .setNeutralButton("Limpiar") { _, _ -> clearHits() }
            .setPositiveButton("Cerrar", null)
            .create()
        dialog?.setOnDismissListener { listBox = null }
        dialog?.show()
        refresh()
    }

    private fun refresh() {
        val box = listBox ?: return
        box.removeAllViews()
        val l = visible()
        if (l.isEmpty()) {
            val e = TextView(this)
            e.text = "Todavía no se detecta ningún video.\nDale play en la página y espera unos segundos."
            e.setTextColor(0xFF999999.toInt())
            e.setPadding(0, px(16), 0, px(16))
            box.addView(e)
            return
        }
        val b = best()
        for (h in l) box.addView(row(h, h === b))
    }

    private fun row(h: Hit, isBest: Boolean): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(px(10), px(8), px(10), px(8))
        val bg = GradientDrawable()
        bg.setColor(if (isBest) 0xFF3A2224.toInt() else 0xFF2A2A2A.toInt())
        bg.cornerRadius = px(8).toFloat()
        r.background = bg
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 0, 0, px(8))
        r.layoutParams = lp

        val line1 = TextView(this)
        val st = when {
            !h.checked && h.kind != "SUB" -> "comprobando…"
            h.ok -> "✓ responde"
            h.kind == "SUB" -> ""
            else -> "sin verificar"
        }
        val dur = fmt(h.durMs, false)
        line1.text = (if (isBest) "★ " else "") + h.kind + (if (dur.isNotEmpty()) " · $dur" else "") + (if (st.isNotEmpty()) " · $st" else "")
        line1.setTextColor(if (isBest) 0xFFFF6B6B.toInt() else 0xFF9CDCFE.toInt())
        line1.textSize = 13f
        line1.typeface = Typeface.DEFAULT_BOLD
        r.addView(line1)
        val line2 = TextView(this)
        line2.text = h.url
        line2.setTextColor(Color.WHITE)
        line2.textSize = 12f
        line2.maxLines = 3
        line2.ellipsize = TextUtils.TruncateAt.END
        r.addView(line2)
        val acts = LinearLayout(this)
        acts.orientation = LinearLayout.HORIZONTAL
        acts.addView(smallBtn("Copiar") { copy(h.url) })
        acts.addView(smallBtn("Compartir") { share(h.url) })
        r.addView(acts)
        r.setOnClickListener { copy(h.url) }
        return r
    }

    private fun showHelp() {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("MiFlix Extractor")
            .setMessage(
                "1. Pega el enlace de la página donde ves el video (o compártelo desde tu navegador a esta app).\n\n" +
                    "2. Dale play al video. Los enlaces aparecen en el botón rojo 🔗.\n\n" +
                    "3. Ábrelo, toca el enlace principal ★ para copiarlo y pégalo en MiFlix al agregar la película.\n\n" +
                    "Si no aparece nada, prueba el modo escritorio 🖥 o abre «Mostrar todos»."
            )
            .setPositiveButton("Entendido", null)
            .show()
    }
}
