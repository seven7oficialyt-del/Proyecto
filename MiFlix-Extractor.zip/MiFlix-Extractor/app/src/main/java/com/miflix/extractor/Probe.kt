package com.miflix.extractor

import android.media.MediaMetadataRetriever
import android.net.Uri
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicLong

/** Comprueba un enlace: ¿responde?, ¿cuánto dura?, ¿es la lista maestra (.m3u8 con calidades)? */
object Probe {
    class Res(val ok: Boolean, val durMs: Long, val master: Boolean, val type: String? = null)

    fun check(url: String, headers: Map<String, String>, kind: String = ""): Res {
        val path = (Uri.parse(url).path ?: "").lowercase()
        val low = url.lowercase()
        return try {
            when {
                low.contains(".m3u8") || kind == "HLS" -> hls(url, headers, 0)
                path.endsWith(".mpd") || low.contains(".mpd?") || kind == "DASH" -> dash(url, headers)
                kind == "VIDEO" -> unknown(url, headers)
                else -> file(url, headers)
            }
        } catch (e: Throwable) {
            Res(false, 0, false)
        }
    }

    private fun open(url: String, headers: Map<String, String>): HttpURLConnection {
        val cn = URL(url).openConnection() as HttpURLConnection
        cn.connectTimeout = 5000
        cn.readTimeout = 5000
        cn.instanceFollowRedirects = true
        headers.forEach { (k, v) -> cn.setRequestProperty(k, v) }
        return cn
    }

    private fun text(url: String, headers: Map<String, String>): String? {
        val cn = open(url, headers)
        return try {
            if (cn.responseCode !in 200..299) null
            else cn.inputStream.bufferedReader(Charsets.UTF_8).use {
                val buf = CharArray(1_500_000)
                val n = it.read(buf)
                if (n > 0) String(buf, 0, n) else null
            }
        } finally {
            cn.disconnect()
        }
    }

    /** Enlace sin extensión: mira el tipo de contenido y los primeros bytes para saber qué es */
    private fun unknown(url: String, headers: Map<String, String>): Res {
        var how = ""
        val cn = open(url, headers)
        try {
            if (cn.responseCode in 200..299) {
                val ct = (cn.contentType ?: "").lowercase()
                how = when {
                    ct.contains("mpegurl") -> "hls"
                    ct.contains("dash+xml") -> "dash"
                    ct.startsWith("video/") || ct.startsWith("audio/") -> "file"
                    ct.startsWith("text/html") || ct.startsWith("image/") || ct.contains("javascript") || ct.contains("css") -> ""
                    else -> {
                        val b = ByteArray(2048)
                        val n = cn.inputStream.read(b)
                        val s = if (n > 0) String(b, 0, n, Charsets.ISO_8859_1) else ""
                        when {
                            s.contains("#EXTM3U") -> "hls"
                            s.contains("<MPD") -> "dash"
                            ct.isEmpty() || ct.contains("octet-stream") -> "file"
                            else -> ""
                        }
                    }
                }
            }
        } finally {
            cn.disconnect()
        }
        return when (how) {
            "hls" -> hls(url, headers, 0).let { Res(it.ok, it.durMs, it.master, "HLS") }
            "dash" -> dash(url, headers).let { Res(it.ok, it.durMs, it.master, "DASH") }
            "file" -> file(url, headers)
            else -> Res(false, 0, false)
        }
    }

    private fun hls(url: String, headers: Map<String, String>, depth: Int): Res {
        val t = text(url, headers) ?: return Res(false, 0, false)
        if (!t.contains("#EXTM3U")) return Res(false, 0, false)
        if (t.contains("#EXT-X-STREAM-INF")) {
            if (depth > 1) return Res(true, 0, true)
            val lines = t.lines()
            val i = lines.indexOfFirst { it.startsWith("#EXT-X-STREAM-INF") }
            val next = lines.drop(i + 1).firstOrNull { it.isNotBlank() && !it.startsWith("#") }?.trim()
                ?: return Res(true, 0, true)
            val sub = hls(URL(URL(url), next).toString(), headers, depth + 1)
            return Res(true, sub.durMs, true)
        }
        var sum = 0.0
        Regex("#EXTINF:([0-9]+(?:\\.[0-9]+)?)").findAll(t).forEach { sum += it.groupValues[1].toDouble() }
        return Res(true, (sum * 1000).toLong(), false)
    }

    private fun dash(url: String, headers: Map<String, String>): Res {
        val t = text(url, headers) ?: return Res(false, 0, false)
        val m = Regex("mediaPresentationDuration=\"PT(?:([0-9.]+)H)?(?:([0-9.]+)M)?(?:([0-9.]+)S)?\"").find(t)
            ?: return Res(true, 0, true)
        val h = m.groupValues[1].toDoubleOrNull() ?: 0.0
        val mi = m.groupValues[2].toDoubleOrNull() ?: 0.0
        val s = m.groupValues[3].toDoubleOrNull() ?: 0.0
        return Res(true, ((h * 3600 + mi * 60 + s) * 1000).toLong(), true)
    }

    private fun file(url: String, headers: Map<String, String>): Res {
        val d = AtomicLong(0)
        val t = Thread {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(url, HashMap(headers))
                d.set(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L)
                r.release()
            } catch (e: Throwable) {
            }
        }
        t.start()
        t.join(5500)
        if (d.get() > 0) return Res(true, d.get(), true)
        val len = size(url, headers)
        return if (len > 0) Res(true, len / 300, true) else Res(false, 0, true)   // sin duración real: se estima por el peso solo para ordenar
    }

    private fun size(url: String, headers: Map<String, String>): Long {
        val cn = open(url, headers)
        return try {
            cn.setRequestProperty("Range", "bytes=0-0")
            val range = cn.getHeaderField("Content-Range")
            if (range != null && range.contains('/')) range.substringAfter('/').trim().toLongOrNull() ?: 0L
            else cn.contentLengthLong.coerceAtLeast(0L)
        } catch (e: Exception) {
            0L
        } finally {
            cn.disconnect()
        }
    }
}
