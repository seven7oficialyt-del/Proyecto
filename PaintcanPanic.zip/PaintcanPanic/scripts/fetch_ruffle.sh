#!/usr/bin/env bash
# Descarga el emulador Ruffle (versión self-hosted) y lo copia a los assets de la app.
set -e
cd "$(dirname "$0")/.."
T=$(mktemp -d)
( cd "$T" && npm pack @ruffle-rs/ruffle --silent && tar xzf ./*.tgz )
D=app/src/main/assets/www/ruffle
rm -rf "$D"; mkdir -p "$D"
cp -r "$T"/package/* "$D"/
ls "$D"
