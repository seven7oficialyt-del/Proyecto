# Paintcan Panic – APK para Android (v1.1)
Ejecuta el SWF con Ruffle en un WebView: pantalla completa horizontal, botones temáticos y menú ☰ con
resolución (0.5x–2x), estirar pantalla, sonido, controles y reinicio. Ajustes guardados en el dispositivo.
Compilar: bash scripts/fetch_ruffle.sh && gradle assembleDebug
