# Paintcan Panic – APK para Android
Ejecuta el SWF original con Ruffle dentro de un WebView (pantalla completa horizontal, controles táctiles, menú ☰).
Es un juego de un solo archivo: no necesita archivos extra.
Compilar: sube el zip a un repositorio de GitHub nuevo con el workflow (ver instrucciones del chat).
Local: bash scripts/fetch_ruffle.sh && gradle assembleDebug
