package com.paintcan.panic;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final String[] REQUIRED = {};
    static final int REQ_IMPORT = 42;

    private WebView web;
    private FrameLayout root, pad;
    private LinearLayout menu;
    private boolean muted, dialogOpen;
    private long lastAsk;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        web = buildWebView();
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        buildPad();
        buildMenu();
        setContentView(root);
        hideSystemUi();
        web.loadUrl("https://" + HOST + "/www/index.html");
        root.postDelayed(this::checkMissing, 1500);
    }

    // ---------- WebView + servidor local de archivos ----------
    private WebView buildWebView() {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true); // guarda fichas/progreso (SharedObject -> localStorage)
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        w.setBackgroundColor(Color.BLACK);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        w.setLongClickable(false);
        w.setOnLongClickListener(v -> true);
        w.setHapticFeedbackEnabled(false);
        w.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return handle(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost()) && "/www/index.html".equals(u.getPath())) return false;
                handleNav(u);
                return true; // nunca salir del juego
            }
        });
        return w;
    }

    private WebResourceResponse handle(Uri u) {
        String scheme = u.getScheme();
        if (!HOST.equals(u.getHost())) {
            // Bloquea servidores externos (tracker.swf de cartoonnetwork.com, etc.)
            if ("http".equals(scheme) || "https".equals(scheme)) return notFound();
            return null;
        }
        String p = u.getPath() == null ? "" : u.getPath();
        if (p.contains("..")) return notFound();
        try {
            if (p.startsWith("/www/")) {
                String rel = p.substring(5);
                return resp(mime(rel), getAssets().open("www/" + rel));
            }
            if (p.startsWith("/game/")) {
                String rel = p.substring(6);
                File f = new File(getFilesDir(), "game/" + rel);
                if (f.isFile()) return resp(mime(rel), new FileInputStream(f));
                try {
                    return resp(mime(rel), getAssets().open("game/" + rel));
                } catch (IOException e) {
                    if (rel.matches("sb0\\d_.*\\.swf")) askMissing(rel);
                    return notFound();
                }
            }
        } catch (IOException e) { /* cae a 404 */ }
        return notFound();
    }

    /** Descargas de la tienda (getURL a store/*.zip): se guardan en la carpeta Download de la app. */
    private void handleNav(Uri u) {
        if (!HOST.equals(u.getHost()) || u.getPath() == null || !u.getPath().startsWith("/game/store/")) return;
        final String rel = u.getPath().substring(6);
        final File src = new File(getFilesDir(), "game/" + rel);
        runOnUiThread(() -> {
            if (!src.isFile()) {
                toast("Falta " + src.getName() + ". Impórtalo desde el menú (☰).");
                return;
            }
            try {
                File dst = new File(getExternalFilesDir("Download"), src.getName());
                copy(new FileInputStream(src), new FileOutputStream(dst));
                toast("Archivo guardado en: " + dst.getAbsolutePath());
            } catch (IOException e) {
                toast("No se pudo guardar el premio");
            }
        });
    }

    private WebResourceResponse resp(String mime, InputStream in) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-cache");
        return new WebResourceResponse(mime, null, 200, "OK", h, in);
    }

    private WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private String mime(String n) {
        n = n.toLowerCase();
        if (n.endsWith(".html")) return "text/html";
        if (n.endsWith(".js")) return "text/javascript";
        if (n.endsWith(".wasm")) return "application/wasm";
        if (n.endsWith(".swf")) return "application/x-shockwave-flash";
        if (n.endsWith(".zip")) return "application/zip";
        if (n.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    // ---------- Archivos que faltan / importación ----------
    private boolean exists(String rel) {
        if (new File(getFilesDir(), "game/" + rel).isFile()) return true;
        try { getAssets().open("game/" + rel).close(); return true; } catch (IOException e) { return false; }
    }

    private void checkMissing() {
        List<String> miss = new ArrayList<>();
        for (String n : REQUIRED) if (!exists(n)) miss.add(n);
        if (miss.isEmpty()) return;
        showMissing("Faltan los minijuegos:\n• " + String.join("\n• ", miss)
                + "\n\nPuedes importarlos ahora (elige los .swf) o continuar y usar solo el menú.");
    }

    private void askMissing(final String rel) {
        runOnUiThread(() -> {
            if (System.currentTimeMillis() - lastAsk < 5000) return;
            lastAsk = System.currentTimeMillis();
            showMissing("El juego necesita " + rel + " y no está instalado.\n\n¿Quieres importarlo?");
        });
    }

    private void showMissing(String msg) {
        if (dialogOpen) return;
        dialogOpen = true;
        new AlertDialog.Builder(this)
                .setTitle("Archivos extra")
                .setMessage(msg)
                .setPositiveButton("Importar", (d, w) -> pickFiles())
                .setNegativeButton("Continuar sin ellos", null)
                .setOnDismissListener(d -> dialogOpen = false)
                .show();
    }

    private void pickFiles() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_IMPORT || res != RESULT_OK || data == null) return;
        final List<Uri> uris = new ArrayList<>();
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++)
                uris.add(data.getClipData().getItemAt(i).getUri());
        } else if (data.getData() != null) uris.add(data.getData());
        new Thread(() -> {
            int ok = 0;
            for (Uri u : uris) if (copyIn(u)) ok++;
            final int n = ok;
            runOnUiThread(() -> toast(n > 0 ? n + " archivo(s) importado(s). Ya puedes jugar."
                    : "No se importó nada (solo .swf o .zip)"));
        }).start();
    }

    private boolean copyIn(Uri u) {
        String name = null;
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst())
                name = c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME));
        } catch (Exception e) { /* ignora */ }
        if (name == null) name = u.getLastPathSegment();
        if (name == null) return false;
        name = name.substring(name.lastIndexOf('/') + 1).replaceAll("[^A-Za-z0-9._-]", "_");
        String l = name.toLowerCase();
        File dir;
        if (l.endsWith(".swf")) dir = new File(getFilesDir(), "game");
        else if (l.endsWith(".zip")) dir = new File(getFilesDir(), "game/store");
        else return false;
        dir.mkdirs();
        try {
            copy(getContentResolver().openInputStream(u), new FileOutputStream(new File(dir, name)));
            return true;
        } catch (Exception e) { return false; }
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        try (InputStream i = in; OutputStream o = out) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
        }
    }

    // ---------- Controles en pantalla ----------
    private void buildPad() {
        pad = new FrameLayout(this);
        int cell = dp(58);
        FrameLayout dpad = new FrameLayout(this);
        addKey(dpad, "▲", "ArrowUp", cell, 0, cell);
        addKey(dpad, "◀", "ArrowLeft", 0, cell, cell);
        addKey(dpad, "▶", "ArrowRight", cell * 2, cell, cell);
        addKey(dpad, "▼", "ArrowDown", cell, cell * 2, cell);
        FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(cell * 3, cell * 3, Gravity.BOTTOM | Gravity.START);
        dl.setMargins(dp(14), 0, 0, dp(14));
        pad.addView(dpad, dl);

        LinearLayout act = new LinearLayout(this);
        act.setOrientation(LinearLayout.HORIZONTAL);
        act.addView(key("B", "Enter", dp(64)));
        act.addView(key("A", "Space", dp(64)));
        FrameLayout.LayoutParams al = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        al.setMargins(0, 0, dp(14), dp(18));
        pad.addView(act, al);
        root.addView(pad, new FrameLayout.LayoutParams(-1, -1));
    }

    private void addKey(FrameLayout parent, String label, String code, int x, int y, int cell) {
        int size = cell - dp(4);
        View k = key(label, code, size);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size, Gravity.TOP | Gravity.START);
        lp.leftMargin = x;
        lp.topMargin = y;
        parent.addView(k, lp);
    }

    private View key(String label, final String code, int size) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(Color.WHITE);
        b.setTextSize(20);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0x66000000);
        g.setStroke(dp(2), 0x99FFFFFF);
        b.setBackground(g);
        b.setLayoutParams(new LinearLayout.LayoutParams(size, size));
        b.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    js("window.sendKey&&window.sendKey('" + code + "',true)");
                    v.setAlpha(0.5f);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    js("window.sendKey&&window.sendKey('" + code + "',false)");
                    v.setAlpha(1f);
                    break;
                default:
                    break;
            }
            return true;
        });
        return b;
    }

    private void buildMenu() {
        menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setVisibility(View.GONE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF0222222);
        bg.setCornerRadius(dp(14));
        menu.setBackground(bg);
        menu.setPadding(dp(6), dp(6), dp(6), dp(6));
        menu.addView(item("🔄  Reiniciar", v -> { toggleMenu(); web.reload(); }));
        menu.addView(item("🔇  Silenciar / sonido", v -> {
            muted = !muted;
            js("window.player&&(window.player.volume=" + (muted ? 0 : 1) + ")");
        }));
        menu.addView(item("🎮  Mostrar / ocultar controles", v ->
                pad.setVisibility(pad.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE)));
        menu.addView(item("✖  Salir", v -> finish()));
        FrameLayout.LayoutParams ml = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        ml.setMargins(0, dp(62), dp(10), 0);
        root.addView(menu, ml);

        TextView gear = new TextView(this);
        gear.setText("☰");
        gear.setGravity(Gravity.CENTER);
        gear.setTextColor(Color.WHITE);
        gear.setTextSize(22);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0x66000000);
        gear.setBackground(g);
        gear.setOnClickListener(v -> toggleMenu());
        FrameLayout.LayoutParams gl = new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP | Gravity.END);
        gl.setMargins(0, dp(8), dp(10), 0);
        root.addView(gear, gl);
    }

    private TextView item(String t, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(t);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setPadding(dp(14), dp(12), dp(14), dp(12));
        b.setOnClickListener(l);
        return b;
    }

    private void toggleMenu() {
        menu.setVisibility(menu.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    // ---------- Utilidades ----------
    private void js(String s) { web.evaluateJavascript(s, null); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hideSystemUi(); }
    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override public void onBackPressed() { toggleMenu(); } // evita salir sin querer
    @Override protected void onDestroy() { root.removeAllViews(); web.destroy(); super.onDestroy(); }
}
