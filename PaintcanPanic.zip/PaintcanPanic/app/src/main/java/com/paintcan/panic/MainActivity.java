package com.paintcan.panic;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    // Paleta de campamento: pintura morada, madera y crema
    static final int PURPLE = 0xE0A06CD5, PURPLE_DARK = 0xFF5B2C8A, CREAM = 0xFFF5EFD6;
    static final int WOOD_LIGHT = 0xFF9A6630, WOOD_DARK = 0xFF6B4220, WOOD_EDGE = 0xFF3E250F;

    private WebView web;
    private FrameLayout root, pad;
    private LinearLayout menu;
    private TextView resItem, stretchItem, soundItem;
    private boolean muted;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        web = buildWebView();
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        buildPad();
        buildMenu();
        setContentView(root);
        hideSystemUi();
        web.loadUrl("https://" + HOST + "/www/index.html");
    }

    // ---------- WebView + servidor local de archivos ----------
    private WebView buildWebView() {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        w.setBackgroundColor(Color.BLACK);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        w.setLongClickable(false);
        w.setOnLongClickListener(v -> true);
        w.setHapticFeedbackEnabled(false);
        w.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return handle(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                return !(HOST.equals(u.getHost()) && "/www/index.html".equals(u.getPath()));
            }
        });
        return w;
    }

    private WebResourceResponse handle(Uri u) {
        String scheme = u.getScheme();
        if (!HOST.equals(u.getHost())) {
            // Bloquea servidores externos (tracker.swf, etc.)
            if ("http".equals(scheme) || "https".equals(scheme)) return notFound();
            return null;
        }
        String p = u.getPath() == null ? "" : u.getPath();
        if (p.contains("..")) return notFound();
        try {
            if (p.startsWith("/www/")) {
                String rel = p.substring(5);
                return resp(mime(rel), getAssets().open("www/" + rel));
            }
            if (p.startsWith("/game/")) {
                String rel = p.substring(6);
                return resp(mime(rel), getAssets().open("game/" + rel));
            }
        } catch (IOException e) { /* cae a 404 */ }
        return notFound();
    }

    private WebResourceResponse resp(String mime, InputStream in) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-cache");
        return new WebResourceResponse(mime, null, 200, "OK", h, in);
    }

    private WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private String mime(String n) {
        n = n.toLowerCase();
        if (n.endsWith(".html")) return "text/html";
        if (n.endsWith(".js")) return "text/javascript";
        if (n.endsWith(".wasm")) return "application/wasm";
        if (n.endsWith(".swf")) return "application/x-shockwave-flash";
        if (n.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    // ---------- Dibujos temáticos (formas propias, sin personajes) ----------
    /** Salpicadura de pintura morada con gotas alrededor. */
    static class Splat extends Drawable {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint shine = new Paint(Paint.ANTI_ALIAS_FLAG);
        private static final float[] ANG = {20, 75, 130, 195, 250, 310};
        private static final float[] RAD = {0.17f, 0.12f, 0.15f, 0.11f, 0.17f, 0.13f};

        Splat() {
            fill.setColor(PURPLE);
            edge.setColor(PURPLE_DARK);
            edge.setStyle(Paint.Style.STROKE);
            shine.setColor(0x66FFFFFF);
        }

        @Override
        public void draw(Canvas c) {
            Rect r = getBounds();
            float cx = r.exactCenterX(), cy = r.exactCenterY();
            float R = Math.min(r.width(), r.height()) / 2f;
            float body = R * 0.66f;
            for (int i = 0; i < ANG.length; i++) {
                double a = Math.toRadians(ANG[i]);
                float x = (float) (cx + Math.cos(a) * R * 0.76f);
                float y = (float) (cy + Math.sin(a) * R * 0.76f);
                c.drawCircle(x, y, R * RAD[i], fill);
            }
            c.drawCircle(cx, cy, body, fill);
            edge.setStrokeWidth(R * 0.06f);
            c.drawCircle(cx, cy, body, edge);
            c.drawCircle(cx - body * 0.35f, cy - body * 0.4f, body * 0.17f, shine);
        }

        @Override public void setAlpha(int a) { fill.setAlpha(a); }
        @Override public void setColorFilter(ColorFilter f) { fill.setColorFilter(f); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Tabla de madera de campamento. */
    private Drawable wood(float radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{WOOD_LIGHT, WOOD_DARK});
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(2), WOOD_EDGE);
        return g;
    }

    // ---------- Controles en pantalla ----------
    private void buildPad() {
        pad = new FrameLayout(this);
        int cell = dp(60);
        FrameLayout dpad = new FrameLayout(this);
        addKey(dpad, "▲", "ArrowUp", cell, 0, cell);
        addKey(dpad, "◀", "ArrowLeft", 0, cell, cell);
        addKey(dpad, "▶", "ArrowRight", cell * 2, cell, cell);
        addKey(dpad, "▼", "ArrowDown", cell, cell * 2, cell);
        FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(cell * 3, cell * 3, Gravity.BOTTOM | Gravity.START);
        dl.setMargins(dp(12), 0, 0, dp(12));
        pad.addView(dpad, dl);

        LinearLayout act = new LinearLayout(this);
        act.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ab = new LinearLayout.LayoutParams(dp(64), dp(64));
        ab.setMargins(dp(6), 0, dp(6), 0);
        act.addView(key("B", "Enter", false), ab);
        act.addView(key("A", "Space", false), new LinearLayout.LayoutParams(ab));
        FrameLayout.LayoutParams al = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        al.setMargins(0, 0, dp(12), dp(20));
        pad.addView(act, al);
        root.addView(pad, new FrameLayout.LayoutParams(-1, -1));
    }

    private void addKey(FrameLayout parent, String label, String code, int x, int y, int cell) {
        View k = key(label, code, true);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(cell, cell, Gravity.TOP | Gravity.START);
        lp.leftMargin = x;
        lp.topMargin = y;
        parent.addView(k, lp);
    }

    private View key(String label, final String code, boolean arrow) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setGravity(Gravity.CENTER);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(CREAM);
        b.setTextSize(arrow ? 22 : 22);
        b.setBackground(arrow ? new Splat() : wood(16));
        b.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    js("window.sendKey&&window.sendKey('" + code + "',true)", null);
                    v.setAlpha(0.55f);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    js("window.sendKey&&window.sendKey('" + code + "',false)", null);
                    v.setAlpha(1f);
                    break;
                default:
                    break;
            }
            return true;
        });
        return b;
    }

    // ---------- Menú ----------
    private void buildMenu() {
        menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setVisibility(View.GONE);
        menu.setBackground(wood(14));
        menu.setPadding(dp(6), dp(6), dp(6), dp(6));

        resItem = item("📐  Resolución: 1x", v -> js("window.cycleRes()",
                r -> resItem.setText("📐  Resolución: " + clean(r) + "x")));
        stretchItem = item("↔  Estirar pantalla: No", v -> js("window.toggleStretch()",
                r -> stretchItem.setText("↔  Estirar pantalla: " + yesNo(r))));
        soundItem = item("🔊  Sonido: Sí", v -> {
            muted = !muted;
            js("window.player&&(window.player.volume=" + (muted ? 0 : 1) + ")", null);
            soundItem.setText("🔊  Sonido: " + (muted ? "No" : "Sí"));
        });
        menu.addView(resItem);
        menu.addView(stretchItem);
        menu.addView(soundItem);
        menu.addView(item("🎮  Mostrar / ocultar controles", v ->
                pad.setVisibility(pad.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE)));
        menu.addView(item("🔄  Reiniciar juego", v -> { toggleMenu(); web.reload(); }));
        menu.addView(item("✖  Salir", v -> finish()));
        FrameLayout.LayoutParams ml = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        ml.setMargins(0, dp(62), dp(10), 0);
        root.addView(menu, ml);

        TextView gear = new TextView(this);
        gear.setText("☰");
        gear.setGravity(Gravity.CENTER);
        gear.setTypeface(Typeface.DEFAULT_BOLD);
        gear.setTextColor(CREAM);
        gear.setTextSize(22);
        gear.setBackground(wood(12));
        gear.setOnClickListener(v -> toggleMenu());
        FrameLayout.LayoutParams gl = new FrameLayout.LayoutParams(dp(48), dp(44), Gravity.TOP | Gravity.END);
        gl.setMargins(0, dp(8), dp(10), 0);
        root.addView(gear, gl);
    }

    private TextView item(String t, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(t);
        b.setTextColor(CREAM);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(16);
        b.setPadding(dp(14), dp(12), dp(14), dp(12));
        b.setOnClickListener(l);
        return b;
    }

    private void toggleMenu() {
        boolean open = menu.getVisibility() != View.VISIBLE;
        menu.setVisibility(open ? View.VISIBLE : View.GONE);
        if (open) refreshLabels();
    }

    private void refreshLabels() {
        js("window.getRes&&window.getRes()", r -> resItem.setText("📐  Resolución: " + clean(r) + "x"));
        js("window.getStretch&&window.getStretch()", r -> stretchItem.setText("↔  Estirar pantalla: " + yesNo(r)));
    }

    // ---------- Utilidades ----------
    private void js(String s, ValueCallback<String> cb) { web.evaluateJavascript(s, cb); }
    private String clean(String v) { return (v == null || v.equals("null")) ? "1" : v.replace("\"", ""); }
    private String yesNo(String v) { return "true".equals(clean(v)) ? "Sí" : "No"; }
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hideSystemUi(); }
    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override public void onBackPressed() { toggleMenu(); }
    @Override protected void onDestroy() { root.removeAllViews(); web.destroy(); super.onDestroy(); }
}
