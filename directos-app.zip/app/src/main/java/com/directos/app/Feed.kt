package com.directos.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale

const val BASE = "https://jo.jeinzmacias.cx"
const val FEED = "$BASE/feeds/posts/default?alt=json&max-results=150"

class Post(val id: String, val title: String, val link: String, val label: String, val time: Long)
class Result(val posts: List<Post>, val fresh: List<Post>)

object Feed {
    fun fetch(): List<Post> {
        val c = URL(FEED).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "DirectosApp/1.0")
        try {
            val txt = c.inputStream.bufferedReader().use { it.readText() }
            val entries = JSONObject(txt).getJSONObject("feed").optJSONArray("entry") ?: return emptyList()
            val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US)
            val out = mutableListOf<Post>()
            for (i in 0 until entries.length()) {
                val e = entries.getJSONObject(i)
                val title = e.getJSONObject("title").optString("\$t")
                val id = e.getJSONObject("id").optString("\$t")
                var link = ""
                val ls = e.optJSONArray("link")
                if (ls != null) for (j in 0 until ls.length()) {
                    val l = ls.getJSONObject(j)
                    if (l.optString("rel") == "alternate") link = l.optString("href")
                }
                val cats = e.optJSONArray("category")
                val label = if (cats != null && cats.length() > 0) cats.getJSONObject(0).optString("term") else "Otros"
                val t = try { fmt.parse(e.getJSONObject("published").optString("\$t"))?.time ?: 0L } catch (x: Exception) { 0L }
                if (link.isNotEmpty()) out.add(Post(id, title, link, label, t))
            }
            return out
        } finally {
            c.disconnect()
        }
    }

    private fun prefs(c: Context) = c.getSharedPreferences("directos", Context.MODE_PRIVATE)
    private fun getSet(c: Context, k: String): Set<String> = prefs(c).getStringSet(k, emptySet()) ?: emptySet()
    private fun addAll(c: Context, k: String, ids: Collection<String>) {
        val s = HashSet(getSet(c, k)); s.addAll(ids)
        prefs(c).edit().putStringSet(k, s).apply()
    }

    fun isSeen(c: Context, id: String) = id in getSet(c, "seen")
    fun markSeen(c: Context, id: String) = addAll(c, "seen", listOf(id))

    // Descarga el feed, detecta lo nuevo y lo recuerda. La primera vez no avisa de nada.
    @Synchronized
    fun check(c: Context): Result {
        val posts = fetch()
        val first = !prefs(c).contains("known")
        val old = getSet(c, "known")
        val fresh = if (first) emptyList() else posts.filter { it.id !in old }
        addAll(c, "known", posts.map { it.id })
        if (first) addAll(c, "seen", posts.map { it.id })
        return Result(posts, fresh)
    }
}

object Notifier {
    private const val CH = "nuevos"

    fun show(c: Context, fresh: List<Post>) {
        if (fresh.isEmpty()) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "Nuevos directos", NotificationManager.IMPORTANCE_HIGH))
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        for (p in fresh.take(5)) {
            val open = PendingIntent.getActivity(c, p.id.hashCode(), Intent(c, PlayerActivity::class.java).putExtra("url", p.link), flags)
            nm.notify(p.id.hashCode(), builder(c).setContentTitle("Nuevo: " + p.label).setContentText(p.title)
                .setContentIntent(open).setAutoCancel(true).build())
        }
        if (fresh.size > 5) {
            val app = PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java), flags)
            nm.notify(1, builder(c).setContentTitle("Más directos nuevos").setContentText("Hay " + (fresh.size - 5) + " más en la app")
                .setContentIntent(app).setAutoCancel(true).build())
        }
    }

    private fun builder(c: Context): Notification.Builder {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CH) else Notification.Builder(c)
        return b.setSmallIcon(android.R.drawable.ic_dialog_info)
    }
}

class CheckJob : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            try {
                val r = Feed.check(applicationContext)
                Notifier.show(applicationContext, r.fresh)
            } catch (e: Exception) {
            }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true
}

object Sched {
    fun start(c: Context) {
        val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        if (js.getPendingJob(1) != null) return
        val info = JobInfo.Builder(1, ComponentName(c, CheckJob::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPeriodic(15 * 60 * 1000L)
            .setPersisted(true)
            .build()
        js.schedule(info)
    }
}
