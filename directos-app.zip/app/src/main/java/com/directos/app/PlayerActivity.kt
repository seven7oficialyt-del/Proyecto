package com.directos.app

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

// Abre la entrada dentro de la app (sin Chrome).
class PlayerActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var frame: FrameLayout
    private var custom: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val url = intent.getStringExtra("url")
        if (url == null) { finish(); return }
        val host = Uri.parse(url).host
        frame = FrameLayout(this)
        frame.setBackgroundColor(Color.BLACK)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.webViewClient = object : WebViewClient() {
            // Mantiene la navegación dentro de tu blog; bloquea redirecciones a otros sitios.
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = r.url.host != host
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(v: View, cb: CustomViewCallback) {
                custom = v; customCb = cb
                frame.addView(v, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                web.visibility = View.GONE
            }
            override fun onHideCustomView() {
                custom?.let { frame.removeView(it) }
                custom = null
                customCb?.onCustomViewHidden()
                web.visibility = View.VISIBLE
            }
        }
        frame.addView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(frame)
        web.loadUrl(url)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (custom != null) web.webChromeClient?.onHideCustomView()
        else if (web.canGoBack()) web.goBack()
        else finish()
    }

    override fun onPause() { super.onPause(); web.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
