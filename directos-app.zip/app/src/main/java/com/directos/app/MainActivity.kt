package com.directos.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private var all = listOf<Post>()
    private val shown = mutableListOf<Post>()
    private var filter = "Todos"
    private lateinit var status: TextView
    private lateinit var chips: LinearLayout
    private lateinit var list: ListView
    private val h = Handler(Looper.getMainLooper())
    private val auto = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 60000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // Si la app falla, guarda el error y lo muestra en pantalla la próxima vez.
    private fun showCrash(trace: String) {
        val t = TextView(this).apply {
            text = "La app tuvo un error. Mándale una captura de esta pantalla a Claude:\n\n" + trace
            textSize = 11f; setTextColor(Color.WHITE); setTextIsSelectable(true); setPadding(dp(12), dp(40), dp(12), dp(12))
        }
        setContentView(android.widget.ScrollView(this).apply { setBackgroundColor(Color.parseColor("#14161A")); addView(t) })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("crash", MODE_PRIVATE)
        val old = sp.getString("trace", null)
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try { sp.edit().putString("trace", android.util.Log.getStackTraceString(e)).commit() } catch (x: Throwable) { }
            android.os.Process.killProcess(android.os.Process.myPid())
        }
        if (old != null) {
            sp.edit().remove("trace").commit()
            showCrash(old)
            return
        }
        try {
            build()
        } catch (e: Throwable) {
            showCrash(android.util.Log.getStackTraceString(e))
            return
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        } catch (e: Throwable) { }
        try { Sched.start(this) } catch (e: Throwable) { }
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#14161A"))
            setPadding(dp(16), dp(36), dp(16), 0)
        }
        root.addView(TextView(this).apply {
            text = "Directos"; textSize = 26f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE)
        })
        status = TextView(this).apply { text = "Cargando…"; textSize = 13f; setTextColor(Color.parseColor("#8A9099")); setPadding(0, dp(2), 0, dp(8)) }
        root.addView(status)
        chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) })
        list = ListView(this).apply {
            divider = null
            adapter = Adapter()
            setOnItemClickListener { _, _, pos, _ -> openPost(shown[pos]) }
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(8) })
        setContentView(root)
        built = true
    }

    private var built = false

    override fun onResume() { super.onResume(); if (built) h.post(auto) }
    override fun onPause() { super.onPause(); h.removeCallbacks(auto) }

    private fun openPost(p: Post) {
        Feed.markSeen(this, p.id)
        (list.adapter as BaseAdapter).notifyDataSetChanged()
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(p.link)))
    }

    private fun refresh() {
        Thread {
            try {
                val r = Feed.check(this)
                runOnUiThread {
                    all = r.posts
                    buildChips()
                    applyFilter()
                    status.text = "Actualizado " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + " · " + all.size + " enlaces"
                }
            } catch (e: Throwable) {
                runOnUiThread { try { status.text = "Sin conexión. Reintentando…" } catch (x: Throwable) { } }
            }
        }.start()
    }

    private fun applyFilter() {
        shown.clear()
        shown.addAll(if (filter == "Todos") all else all.filter { it.label == filter })
        (list.adapter as BaseAdapter).notifyDataSetChanged()
    }

    private fun buildChips() {
        chips.removeAllViews()
        val labels = listOf("Todos") + all.map { it.label }.distinct()
        if (filter !in labels) filter = "Todos"
        for (l in labels) {
            val on = l == filter
            chips.addView(TextView(this).apply {
                text = l; textSize = 14f
                setTextColor(if (on) Color.WHITE else Color.parseColor("#C5CAD3"))
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = GradientDrawable().apply {
                    cornerRadius = dp(20).toFloat()
                    setColor(Color.parseColor(if (on) "#2D6A4F" else "#262A31"))
                }
                setOnClickListener { filter = l; buildChips(); applyFilter() }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
        }
    }

    private fun ago(t: Long): String {
        if (t == 0L) return ""
        val m = (System.currentTimeMillis() - t) / 60000
        return if (m < 1) "ahora" else if (m < 60) "hace $m min" else if (m < 1440) "hace ${m / 60} h" else "hace ${m / 1440} d"
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int) = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, parent: ViewGroup?): View {
            val p = shown[i]
            val fresh = !Feed.isSeen(this@MainActivity, p.id)
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.parseColor("#1E2127")) }
            }
            val top = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            if (fresh) top.addView(TextView(this@MainActivity).apply {
                text = "NUEVO"; textSize = 10f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE)
                setPadding(dp(6), dp(2), dp(6), dp(2))
                background = GradientDrawable().apply { cornerRadius = dp(6).toFloat(); setColor(Color.parseColor("#E5533D")) }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
            top.addView(TextView(this@MainActivity).apply {
                text = p.title; textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(top)
            row.addView(TextView(this@MainActivity).apply {
                text = p.label + "  ·  " + ago(p.time); textSize = 13f; setTextColor(Color.parseColor("#8A9099")); setPadding(0, dp(4), 0, 0)
            })
            // separación entre tarjetas
            val wrap = LinearLayout(this@MainActivity).apply { setPadding(0, 0, 0, dp(8)) }
            wrap.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return wrap
        }
    }
}
