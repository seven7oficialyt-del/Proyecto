package com.nocheraptor.game;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/** Progreso y opciones guardadas en el teléfono. */
public class Settings {
    public static final int NIGHTS = 7;
    /** Posición por defecto de los 3 botones (0 = LUZ, 1 = trampilla del techo, 2 = trampilla derecha). */
    private static final float[] DEF_X = {0.92f, 0.80f, 0.80f};
    private static final float[] DEF_Y = {0.80f, 0.88f, 0.66f};

    private final SharedPreferences sp;

    public int unlocked = 1;      // noche más alta desbloqueada
    public int current = 1;       // noche donde te quedaste (para "Continuar")
    public int difficulty = 1;    // 0 fácil, 1 normal, 2 difícil, 3 extremo
    public int lang = 0;          // 0 español, 1 inglés
    public float musicVol = 0.6f;
    public float sfxVol = 1.0f;
    public int coins = 0;         // monedas acumuladas
    /** Posición (fracción de la pantalla) y escala de cada botón. */
    public final float[] cx = new float[3];
    public final float[] cy = new float[3];
    public final float[] cs = new float[3];

    public Settings(Context ctx) {
        sp = ctx.getSharedPreferences("jurassic_experience", Context.MODE_PRIVATE);
        unlocked = clampI(sp.getInt("unlocked", 1), 1, NIGHTS);
        current = clampI(sp.getInt("current", 1), 1, unlocked);
        difficulty = clampI(sp.getInt("difficulty", 1), 0, 3);
        boolean en = "en".equals(Locale.getDefault().getLanguage());
        lang = clampI(sp.getInt("lang", en ? 1 : 0), 0, 1);
        musicVol = clampF(sp.getFloat("musicVol", 0.6f), 0f, 1f);
        sfxVol = clampF(sp.getFloat("sfxVol", 1.0f), 0f, 1f);
        coins = Math.max(0, sp.getInt("coins", 0));
        for (int i = 0; i < 3; i++) {
            cx[i] = clampF(sp.getFloat("cx" + i, DEF_X[i]), 0.04f, 0.96f);
            cy[i] = clampF(sp.getFloat("cy" + i, DEF_Y[i]), 0.04f, 0.96f);
            cs[i] = clampF(sp.getFloat("cs" + i, 1f), 0.5f, 1.8f);
        }
    }

    public void resetLayout() {
        for (int i = 0; i < 3; i++) {
            cx[i] = DEF_X[i];
            cy[i] = DEF_Y[i];
            cs[i] = 1f;
        }
        save();
    }

    public void save() {
        SharedPreferences.Editor e = sp.edit();
        e.putInt("unlocked", unlocked);
        e.putInt("current", current);
        e.putInt("difficulty", difficulty);
        e.putInt("lang", lang);
        e.putFloat("musicVol", musicVol);
        e.putFloat("sfxVol", sfxVol);
        e.putInt("coins", coins);
        for (int i = 0; i < 3; i++) {
            e.putFloat("cx" + i, cx[i]);
            e.putFloat("cy" + i, cy[i]);
            e.putFloat("cs" + i, cs[i]);
        }
        e.apply();
    }

    private static int clampI(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static float clampF(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
