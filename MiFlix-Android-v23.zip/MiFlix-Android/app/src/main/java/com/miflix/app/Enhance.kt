package com.miflix.app

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * "Mejorar imagen": afinado de nitidez (unsharp mask) en la GPU sobre cada fotograma, en tiempo real.
 * No inventa detalle (no es IA), pero hace que 480p/720p se vean más definidos.
 */
class SharpenEffect(private val strength: Float, private val upscale: Boolean = false) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        SharpenProgram(useHdr, strength, upscale)
}

/**
 * Con upscale = true el fotograma se reescala (hasta ×2, sin pasar de ~1080 px de alto) con filtro
 * Catmull-Rom (bicúbico, como los filtros de escalado de los emuladores pero para video) y después se afila.
 */
private class SharpenProgram(useHdr: Boolean, private val strength: Float, private val upscale: Boolean) : BaseGlShaderProgram(useHdr, 1) {
    private val gl: GlProgram
    private var w = 1
    private var h = 1

    init {
        try {
            gl = GlProgram(VERTEX, FRAGMENT)
            gl.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e)
        }
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        w = inputWidth.coerceAtLeast(1)
        h = inputHeight.coerceAtLeast(1)
        if (!upscale) return Size(w, h)
        var f = minOf(2f, 1080f / minOf(w, h))
        if (f < 1.1f) f = 1f
        return Size(Math.round(w * f), Math.round(h * f))
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            gl.use()
            gl.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            gl.setFloatsUniform("uSrc", floatArrayOf(w.toFloat(), h.toFloat()))
            gl.setFloatsUniform("uTexel", floatArrayOf(1f / w, 1f / h))
            gl.setFloatUniform("uUp", if (upscale) 1f else 0f)
            gl.setFloatUniform("uStrength", strength)
            gl.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try { gl.delete() } catch (e: Exception) { throw VideoFrameProcessingException(e) }
    }

    companion object {
        private const val VERTEX = """
attribute vec4 aFramePosition;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = aFramePosition;
  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""
        private const val FRAGMENT = """
precision highp float;
uniform sampler2D uTexSampler;
uniform vec2 uSrc;
uniform vec2 uTexel;
uniform float uStrength;
uniform float uUp;
varying vec2 vTexSamplingCoord;

vec3 tx(vec2 p) { return texture2D(uTexSampler, p).rgb; }

// Catmull-Rom con 9 lecturas (aprovecha el filtro lineal de la GPU)
vec3 bicubic(vec2 uv) {
  vec2 sp = uv * uSrc;
  vec2 t1 = floor(sp - 0.5) + 0.5;
  vec2 f = sp - t1;
  vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
  vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
  vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
  vec2 w3 = f * f * (-0.5 + 0.5 * f);
  vec2 w12 = w1 + w2;
  vec2 o12 = w2 / w12;
  vec2 t0 = (t1 - 1.0) * uTexel;
  vec2 t3 = (t1 + 2.0) * uTexel;
  vec2 t12 = (t1 + o12) * uTexel;
  vec3 r = tx(vec2(t0.x, t0.y)) * w0.x * w0.y
         + tx(vec2(t12.x, t0.y)) * w12.x * w0.y
         + tx(vec2(t3.x, t0.y)) * w3.x * w0.y
         + tx(vec2(t0.x, t12.y)) * w0.x * w12.y
         + tx(vec2(t12.x, t12.y)) * w12.x * w12.y
         + tx(vec2(t3.x, t12.y)) * w3.x * w12.y
         + tx(vec2(t0.x, t3.y)) * w0.x * w3.y
         + tx(vec2(t12.x, t3.y)) * w12.x * w3.y
         + tx(vec2(t3.x, t3.y)) * w3.x * w3.y;
  return r;
}

void main() {
  vec2 uv = vTexSamplingCoord;
  vec3 c = uUp > 0.5 ? clamp(bicubic(uv), 0.0, 1.0) : tx(uv);
  vec2 d = uTexel * (uUp > 0.5 ? 0.5 : 1.0);
  vec3 n = tx(uv + vec2(d.x, 0.0)) + tx(uv - vec2(d.x, 0.0))
         + tx(uv + vec2(0.0, d.y)) + tx(uv - vec2(0.0, d.y));
  vec3 o = c + (c - n * 0.25) * uStrength;
  gl_FragColor = vec4(clamp(o, 0.0, 1.0), 1.0);
}
"""
    }
}
