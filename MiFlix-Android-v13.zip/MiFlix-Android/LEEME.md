# MiFlix para Android

## 1. Crear el proyecto de Firebase (gratis)
1. Entra a https://console.firebase.google.com y crea un proyecto.
2. Build > Authentication > Comenzar > activa **Correo electrónico/contraseña**.
3. Build > Firestore Database > Crear base de datos (modo producción).
4. En la pestaña **Reglas** de Firestore pega el contenido de `firestore.rules` y publica.
5. Configuración del proyecto > Tus apps > Web (</>) > registra la app y copia `firebaseConfig`.
6. Pega esos valores en `app/src/main/assets/index.html` (zona "PEGA AQUÍ").

## 2. Compilar el APK
- GitHub: sube el ZIP a la raíz del repositorio; tu flujo "Crear APK" lo descomprime y compila solo.
- Android Studio: abre la carpeta y elige Build > Build APK(s).

## 3. Ser administrador
1. Abre la app y crea tu cuenta (usuario y contraseña).
2. En Firebase > Authentication > Usuarios copia tu **UID**.
3. En Firestore crea la colección `admins` con un documento cuyo ID sea ese UID (agrega cualquier campo, p. ej. `ok: true`).
4. Cierra sesión y vuelve a entrar: verás "+ Agregar", Editar y Eliminar. Los demás usuarios solo ven y califican.

## 5. Perfiles de usuario
- Cada usuario tiene perfil: toca tu foto (arriba a la derecha) para subir, cambiar o quitar tu imagen.
- Todos pueden ver los perfiles desde la fila **Comunidad** o tocando a quien calificó un título.
- Las fotos se guardan (reducidas a 256×256) en Firestore, colección `users`; no necesitas Firebase Storage.
- **Importante:** vuelve a pegar `firestore.rules` en Firebase > Firestore > Reglas y publica, o las fotos no se podrán guardar.

## 6. Ver juntos
- En un título (o en un capítulo, botón 👥) toca **Ver juntos**: se crea una sala con un código de 5 letras.
- Invita a un amigo desde la sala o desde su perfil (Comunidad), o dale el código: él lo escribe en el botón 🎬 de arriba.
- Cada uno usa su reproductor nativo; play, pausa y saltos se sincronizan entre los dos.
- **Importante:** vuelve a publicar `firestore.rules` (ahora incluye `rooms`).

## 7. Amigos, chat y voz
- Agrega amigos desde su perfil (Comunidad) o desde el botón de chat del encabezado. El otro acepta la solicitud.
- Chat privado: botón de chat > toca a tu amigo.
- Mientras ven algo juntos, en el reproductor aparecen **Chat** (pestañas Sala / Privado / Voz) y **Voz** (micrófono en vivo).
- **Importante:** vuelve a publicar `firestore.rules` (incluye `friendships`, `chats` y subcolecciones de `rooms`).

## 8. Novedades (chat flotante, likes, cifrado, recuperación)
**IMPORTANTE: vuelve a publicar `firestore.rules`** (nuevas colecciones `likes`, `imgs`, `secrets`, `recovery` y mensajes privados cifrados).

- **Chat al ver juntos (horizontal):** el botón *Chat* abre una mini ventana flotante con avatar + mensaje. Con el chat cerrado, cada mensaje nuevo aparece arriba a la derecha (avatar, nombre y mensaje en una línea; si es largo termina en "…" y tocándolo se abre el chat).
- **Vertical:** al girar el teléfono el video queda arriba y el chat se abre solo debajo (con Sala / Privado / Voz). Al volver a horizontal vuelve el video completo.
- **Likes:** botón ♡ en cada título. El perfil muestra las portadas de lo que le diste like.
- **Imágenes originales:** las portadas y fotos de perfil se suben sin reducir (máx. 15 MB) y se guardan por partes en Firestore (`imgs`). En listas se usa una miniatura para que cargue rápido; al abrir el título o el perfil se carga la original (toca la imagen para ampliarla).
- **Chats privados cifrados de extremo a extremo** (ECDH P-256 + AES-GCM). La clave privada vive en tu teléfono y una copia protegida con tu contraseña en `secrets/{tu uid}`; los mensajes antiguos sin cifrar se siguen viendo. Ambos amigos deben abrir la app actualizada una vez para activarlo.
- **Edad + pregunta de seguridad** al crear cuenta (*¿Quién es tu persona o mascota favorita?*). Los usuarios ya existentes verán un aviso para completarlo.
- **Código de recuperación único** (20 caracteres): se muestra una sola vez al crear la cuenta. En el login, *¿Perdiste el acceso?* → usuario + código + respuesta (+ nueva contraseña opcional). Todo se verifica en el teléfono: la contraseña se guarda cifrada con (código + respuesta), así nadie —ni tú como administrador— puede leerla.

## 9. Imágenes optimizadas y caché local
**Vuelve a publicar `firestore.rules`** (nueva colección `meta`).

- **Imágenes:** se convierten a WebP al 85 % con lado mayor máximo de 1600 px (1024 px en fotos de perfil). Casi no se nota la diferencia y pesan 5 a 10 veces menos. Las miniaturas de las listas son de 400 px (256 px en avatares). GIF y fotos ya pequeñas (<300 KB) se suben tal cual.
- **Caché en el teléfono (IndexedDB):** la primera vez se descarga el catálogo y, en segundo plano, las imágenes originales. Las siguientes veces la app abre al instante desde el teléfono y solo pide lo **nuevo o editado** (`updatedAt`) y los títulos eliminados (`meta/catalog`).
- Los títulos que ya existían se descargan completos una vez; al editarlos reciben `updatedAt` y entran en la sincronización incremental.
- Si borras los datos de la app, se vuelve a descargar todo una vez.

## 10. Subtítulos
**No necesitas republicar nada para esto**, pero sí vuelve a compilar el APK (se agregó la librería de traducción de Google ML Kit).

- **Elegir idioma:** al abrir un título aparece el cuadro *Subtítulos* con dos opciones: el idioma de los subtítulos (o *Desactivados*) y el **idioma original del audio**. Se guardan en el teléfono y se usan en todo lo que reproduzcas (también en *Ver juntos*: cada persona usa su propio idioma).
- **Detección desde el enlace**, en este orden:
  1. Subtítulos incluidos en el video (HLS `.m3u8` o archivos `.mp4`/`.mkv` con pistas).
  2. Subtítulos que la página del enlace declare (`<track>`) o descargue (`.vtt`, `.srt`, `.ass`, `.ttml`).
  3. Archivos "hermanos" junto al video: `pelicula.mp4` → `pelicula.vtt` / `pelicula.srt` (también `pelicula.es.vtt`).
  Si hay uno en el idioma elegido se activa solo.
- **Si no hay subtítulos en tu idioma** se crean automáticamente (beta): la app toma el audio que suena, lo reconoce con el reconocimiento de voz del teléfono (en el idioma original que elegiste) y lo traduce en el teléfono al idioma de los subtítulos. Requisitos: **Android 13 o superior**, internet, y aceptar el permiso de micrófono la primera vez (solo se usa para el reconocimiento; no se graba nada). La primera vez de cada par de idiomas descarga el modelo de traducción (~30 MB).
- **Botón CC** en el reproductor (arriba, junto a *Calidad*): apaga los subtítulos, elige otra pista o fuerza los automáticos. Muestra ✓ cuando hay subtítulos activos.
- Los subtítulos automáticos salen unos instantes después de lo que se dice y no son perfectos; es normal en esta versión.

## 11. Reportes de bugs y sugerencias
**IMPORTANTE: vuelve a publicar `firestore.rules`** (nueva colección `feedback`).

- Todos los usuarios ven al final de la pantalla principal el botón **💡 Bug o sugerencia**: eligen tipo, escriben el mensaje y lo envían. También ven el estado de sus envíos (Pendiente / Resuelto).
- Cada reporte guarda usuario, tipo, texto, fecha y datos del dispositivo (para poder reproducir el bug).
- **El administrador** ve además el botón **📥 Reportes (n)** con todos los envíos, filtros (Pendientes / Resueltos / Todos), y puede marcarlos como resueltos, reabrirlos o eliminarlos. Los demás usuarios solo ven los suyos.

## 12. Salas: quién está, públicas, YouTube y video más largo
**IMPORTANTE: vuelve a publicar `firestore.rules`** (nueva subcolección `rooms/{código}/presence` y el campo `public` de las salas) y vuelve a compilar el APK.

- **Chat:** ya no se ve gigante al entrar (el chat nace con su tamaño final y se ignora el tamaño de letra del sistema). Los mensajes nuevos salen **abajo**: en vertical el campo de escribir queda abajo; en la ventanita horizontal se queda arriba para que el teclado no lo tape.
- **Quién está en la sala:** barra *👥 N personas en la sala* arriba del chat (tócala para ver la lista). Cuando alguien entra o sale aparece una línea en el chat y un aviso. Si alguien cierra la app de golpe, se marca como salido en ~1 minuto.
- **Salas públicas:** al crear una sala marca *Sala pública*. En el botón de salas (🎬) aparece la lista de salas públicas abiertas, con *Entrar* sin código ni invitación.
- **YouTube juntos:** en el botón de salas → *Elegir video de YouTube* (navegas YouTube y tocas *Ver juntos este video*) o pegas un enlace. Desde la versión 13 se reproduce con el **reproductor oficial incrustado de YouTube** (como Rave), ya no con enlaces extraídos, y se sincroniza play, pausa y saltos. Hay chat, voz y lista de personas igual que antes (en horizontal el chat queda a un lado).
  - Algunos videos no permiten reproducirse fuera de YouTube (el dueño bloqueó la incrustación, errores 101/150/152/153). Rave tiene la misma limitación; la app avisa y hay que elegir otro video.
- **Video más largo:** si la página del enlace tiene varios videos (tráilers, avances, recomendados), la app junta los que aparecen durante unos 2 a 6 segundos, mide cuánto dura cada uno y reproduce el más largo. Si solo hay uno, se abre igual (tarda ~2 s más que antes).


## 13. Comentarios, idioma de la app, versiones y cierre de salas
**IMPORTANTE: vuelve a publicar `firestore.rules`** (comentarios en `titles/{id}/comments`, campos `alive` y `closed` en las salas) y vuelve a compilar el APK.

- **Comentarios:** al abrir una película o serie, abajo hay una sección *Comentarios*. Cada quien puede borrar los suyos; el administrador puede borrar cualquiera. Máximo 500 caracteres.
- **Idioma de la app:** botón ⚙ (arriba, junto a salir) → *Español / English*. Traduce la interfaz y los avisos del reproductor. El contenido que subes (títulos, sinopsis) no se traduce. Al cambiar, la pantalla se recarga.
- **Versiones por idioma / subtítulos (administrador):** al agregar o editar una película o un capítulo, escribe un nombre para el enlace principal (ej. *Latino*) y usa **+ Versión** para añadir más enlaces (ej. *Inglés + sub ES*). Si hay más de una versión, al tocar ▶ aparece *Elige una versión*. En *Ver juntos*, **cada persona elige la suya** al entrar a la sala (el anfitrión al pulsar *Empezar a ver*); la sincronización es por tiempo, así que las versiones deben durar lo mismo.
- **Salas que se cierran solas (sin latidos, gasto mínimo de Firestore):** no se envía ninguna señal mientras hay gente. Solo cuando **la última persona sale**, la app manda **una sola señal** (`emptyAt`, junto con borrar su presencia) y la sala se borra a los **10 segundos** si nadie vuelve a entrar. Si alguien entra dentro de esos 10 s, la señal se cancela. El anfitrión que cierra la pantalla de invitación sin empezar también cuenta como sala vacía. Una sala cerrada desaparece de la lista pública y al intentar entrar dice *Esa sala ya se cerró*.
  - Gasto por persona y sesión: ~2 escrituras al entrar (presencia + registro en la sala, y este último solo si es la primera vez) y 1 al salir. Antes había una escritura cada 3 s por persona.
  - También se redujo: la presencia ya no se renueva cada 20 s, la voz ya no se renueva cada 30 s, el anfitrión ya no reenvía la posición cada 15 s (ahora cada 2 min y solo reproduciendo; en YouTube, nunca), y los saltos o pausas seguidos se agrupan en una sola escritura.
  - Limitación: si la app se cierra a la fuerza (sin pasar por el cierre normal), no puede avisar que salió. Esa sala se limpia sola a las 6 horas, o antes si alguien que sí salió normalmente era el último.

## 14. Géneros y botón de opciones
- **Botón ⚙ de opciones:** ahora es un botón flotante en la esquina inferior derecha. La cabecera ya no se sale de la pantalla (se acabó el desplazamiento lateral).
- **Géneros (administrador):** al agregar o editar contenido aparece *Géneros*: toca los que apliquen (se pueden varios). Vienen Acción, Aventura, Comedia, Drama, Terror, Suspenso, Romance, Ciencia ficción, Fantasía, Animación, Misterio, Crimen, Documental, Familiar, Marvel y DC. Para crear uno nuevo, escríbelo en *Nuevo género…* y pulsa *Agregar*: queda guardado para futuros títulos (documento `meta/genres`, no requiere cambiar las reglas).
- **Menú de categorías:** en el inicio hay una barra con *Todos* y los géneros que tengan al menos un título. Al tocar uno se ven todos los títulos de ese género (películas, series, anime…). La ficha de cada título muestra sus géneros.
- Los títulos ya subidos no tienen género: edítalos y marca los que correspondan.

## 15. Quitar géneros y fila de videos en YouTube juntos
**Vuelve a publicar `firestore.rules`** (la sala ahora guarda `queue` y `qi`).

- **Quitar géneros (administrador):** en el formulario de contenido, junto a *Géneros* pulsa **Editar lista**. Cada género aparece con ✕; tócalo y confírmalo pulsando otra vez. Se quita de la lista (incluso los que vienen de fábrica) y de todos los títulos que lo tengan. Pulsa **Listo** para volver a elegir géneros. Lo demás que añadas mal ya se podía quitar: episodios (✕), temporadas (*Quitar*), versiones (✕), títulos (*Eliminar*) y comentarios (*Borrar*).
- **Fila en YouTube juntos:** en una sala de YouTube aparece la pestaña **Fila**. Ahí cualquiera de la sala puede:
  - **🔍 Buscar en YouTube:** abre YouTube; entra a un video y pulsa *Agregar a la fila*. Se queda abierto para agregar varios; cierra con ✕ o atrás.
  - **Pegar un enlace** y pulsar *Agregar*.
  - **Saltar** tocando un video de la lista, o con ⏮ / ⏭. Todos cambian al mismo video.
  - **Quitar** un video con ✕ (siempre queda al menos uno).
  - Al terminar un video pasa solo al siguiente; si uno no se puede reproducir fuera de YouTube, lo salta.
- Gasto: agregar, saltar o quitar es 1 escritura. Además se evitan escrituras repetidas cuando el estado de reproducción no cambió.

## 16. Búsqueda, recuperar cuenta visible y ver el código de recuperación
**Vuelve a publicar `firestore.rules`** (la colección `secrets` ahora acepta `rcw`).

- **Búsqueda:** botón 🔍 en la esquina inferior derecha, encima de ⚙. Busca por título, género o tipo (sin importar mayúsculas ni acentos); al tocar un resultado se abre su ficha.
- **Recuperar cuenta:** en la pantalla de entrada y de crear cuenta hay un botón **Recuperar cuenta** siempre visible. Si el usuario o la contraseña fallan al entrar, aparece además un aviso que lo señala.
- **Ver el código otra vez:** ⚙ Opciones → *Código de recuperación* → escribe tu contraseña → *Ver mi código*. El código se guarda cifrado con tu contraseña (campo `rcw` en `secrets/{uid}`), nunca en claro.
  - Las cuentas creadas **antes** de esta versión no tienen el código guardado (antes no se almacenaba). Para ellas, la misma pantalla ofrece **Generar código nuevo** (pide la respuesta a la pregunta de seguridad); el código anterior deja de servir.
  - Si alguien recupera su cuenta con su código, ese código también queda guardado para poder verlo después.
