package com.miflix.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

/**
 * YouTube juntos con el reproductor OFICIAL incrustado de YouTube (IFrame API), como hace Rave.
 * Ya no se extraen enlaces del video: YouTube lo reproduce él mismo y MiFlix solo sincroniza play, pausa y saltos
 * por la sala (room.html se encarga del chat, la voz y la presencia).
 */
class YouTubeRoomActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var frame: FrameLayout
    private lateinit var yt: WebView
    private var roomWeb: RoomWebView? = null
    private var room: String? = null
    private var vid = ""
    private var isHost = false
    private var synced = false
    private val h = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        vid = (intent.getStringExtra("yt") ?: "").filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(11)
        room = intent.getStringExtra("room")?.takeIf { it.isNotBlank() }
        val d = resources.displayMetrics.density

        root = LinearLayout(this)
        root.setBackgroundColor(Color.BLACK)
        frame = FrameLayout(this)
        yt = WebView(this)
        yt.setBackgroundColor(Color.BLACK)
        yt.settings.javaScriptEnabled = true
        yt.settings.domStorageEnabled = true
        yt.settings.mediaPlaybackRequiresUserGesture = false
        yt.settings.textZoom = 100
        yt.webChromeClient = WebChromeClient()
        yt.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                val host = (request.url.host ?: "").lowercase()
                return !(host.endsWith("youtube.com") || host.endsWith("google.com"))
            }
        }
        yt.addJavascriptInterface(object {
            @JavascriptInterface
            fun event(type: String, json: String) {
                runOnUiThread { onYt(type, json) }
            }
        }, "NativeYT")
        frame.addView(yt, FrameLayout.LayoutParams(-1, -1))

        val close = TextView(this)
        close.text = "✕"
        close.setTextColor(Color.WHITE)
        close.textSize = 18f
        close.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.setColor(0x99000000.toInt())
        bg.cornerRadius = 20 * d
        close.background = bg
        close.setOnClickListener { finish() }
        val lp = FrameLayout.LayoutParams((40 * d).toInt(), (40 * d).toInt(), Gravity.TOP or Gravity.START)
        lp.setMargins((8 * d).toInt(), (8 * d).toInt(), 0, 0)
        frame.addView(close, lp)
        root.addView(frame)

        if (room != null) setupRoom()
        setContentView(root)
        applyLayout()

        val html = assets.open("yt.html").bufferedReader().use { it.readText() }.replace("__VID__", vid)
        yt.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupRoom() {
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        val w = RoomWebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.settings.textZoom = 100
        w.setBackgroundColor(0xFF141414.toInt())
        w.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val ok = request.origin.host == "appassets.androidplatform.net" &&
                        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (ok) request.grant(request.resources) else request.deny()
                }
            }
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                loader.shouldInterceptRequest(request.url)
        }
        w.addJavascriptInterface(object {
            @JavascriptInterface
            fun event(type: String, json: String) {
                runOnUiThread { onRoomEvent(type, json) }
            }
        }, "NativeRoom")
        root.addView(w)
        roomWeb = w
        w.loadUrl("https://appassets.androidplatform.net/assets/room.html?code=$room")
    }

    @Suppress("DEPRECATION")
    private fun applyLayout() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val rw = roomWeb
        if (land) {
            goFullscreen()
            root.orientation = LinearLayout.HORIZONTAL
            frame.layoutParams = if (rw == null) LinearLayout.LayoutParams(-1, -1) else LinearLayout.LayoutParams(0, -1, 1.8f)
            rw?.layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
        } else {
            window.decorView.systemUiVisibility = 0
            root.orientation = LinearLayout.VERTICAL
            val w = resources.displayMetrics.widthPixels
            frame.layoutParams = if (rw == null) LinearLayout.LayoutParams(-1, -1) else LinearLayout.LayoutParams(-1, w * 9 / 16)
            rw?.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        rw?.evaluateJavascript("setMode('${if (land) "mini" else "full"}')", null)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayout()
    }

    // ---------- eventos del reproductor de YouTube ----------
    private fun onYt(type: String, json: String) {
        try {
            when (type) {
                "ready" -> if (room == null) yt.evaluateJavascript("solo()", null)
                "local" -> {
                    if (room == null || !synced) return
                    val o = JSONObject(json)
                    roomWeb?.evaluateJavascript("pushState(${o.optBoolean("playing")},${o.optLong("pos")})", null)
                }
                "error" -> {
                    val code = JSONObject(json).optInt("code")
                    val msg = when (code) {
                        101, 150, 152, 153 -> L.t(
                            "El dueño de este video no permite reproducirlo fuera de YouTube. Prueba con otro video.",
                            "The owner of this video doesn't allow playback outside YouTube. Try another video."
                        )
                        100 -> L.t("Este video no existe o es privado.", "This video doesn't exist or is private.")
                        else -> L.t("No se pudo reproducir el video (error $code).", "Couldn't play the video (error $code).")
                    }
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
        }
    }

    // ---------- eventos de la sala (chat, presencia, estado) ----------
    private fun onRoomEvent(type: String, json: String) {
        try {
            when (type) {
                "ready" -> {
                    isHost = JSONObject(json).optBoolean("host")
                    if (isHost) synced = true
                    applyLayout()
                }
                "state" -> {
                    val o = JSONObject(json)
                    synced = true
                    yt.evaluateJavascript(
                        "applyRemote(${o.optBoolean("playing")},${o.optLong("pos")},${o.optLong("at")})", null
                    )
                }
                "needmic" -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        roomWeb?.evaluateJavascript("startVoice()", null)
                    } else {
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
                    }
                }
                "toast" -> Toast.makeText(this, JSONObject(json).optString("m"), Toast.LENGTH_SHORT).show()
                "joined" -> Toast.makeText(this, JSONObject(json).optString("name") + L.t(" entró a la sala", " joined the room"), Toast.LENGTH_SHORT).show()
                "left" -> Toast.makeText(this, JSONObject(json).optString("name") + L.t(" salió de la sala", " left the room"), Toast.LENGTH_SHORT).show()
                "missing" -> {
                    Toast.makeText(this, L.t("Esa sala ya no existe", "That room no longer exists"), Toast.LENGTH_LONG).show()
                    finish()
                }
                "error" -> Toast.makeText(this, L.t("No se pudo conectar con la sala", "Couldn't connect to the room"), Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            roomWeb?.evaluateJavascript("startVoice()", null)
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        // Avisa a la sala que me fui y da un momento para que se envíe antes de cerrar el WebView
        val rw = roomWeb
        roomWeb = null
        rw?.evaluateJavascript("leaveVoice();leaveRoom()", null)
        if (rw != null) {
            (rw.parent as? ViewGroup)?.removeView(rw)
            Handler(Looper.getMainLooper()).postDelayed({
                try { rw.destroy() } catch (e: Exception) {}
            }, 5000)
        }
        (yt.parent as? ViewGroup)?.removeView(yt)
        yt.destroy()
        super.onDestroy()
    }
}
