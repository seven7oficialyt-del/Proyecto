package com.directos.app.firebase

import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Replica la lectura de "canales" de la app antigua (Futbol Gigante, com.futbol.gigante).
 *
 * En la app antigua, MainActivity.readChannelList() escucha el documento:
 *   db.collection("fix_channel").document("channel")
 *
 * Ese documento tiene un campo String por cada canal (el valor es la URL del stream / enlace):
 *   azteca, cn, raid, telefe, telemundo, tn
 *
 * (Nombres de campo confirmados leyendo la tabla de campos de ChannelList.class dentro
 * del classes.dex de la app antigua — no son una suposición.)
 */
data class ChannelLinks(
    val azteca: String = "",
    val cn: String = "",
    val raid: String = "",
    val telefe: String = "",
    val telemundo: String = "",
    val tn: String = ""
)

object FirebaseChannels {
    private val db by lazy { FirebaseFirestore.getInstance() }

    /**
     * Escucha en tiempo real el documento de canales (igual que hacía la app antigua).
     * Devuelve el ListenerRegistration para poder quitarlo en onDestroy/onPause.
     */
    fun listen(onUpdate: (ChannelLinks) -> Unit, onError: (Exception) -> Unit = {}): ListenerRegistration {
        return db.collection("fix_channel").document("channel")
            .addSnapshotListener { snap, error ->
                if (error != null) { onError(error); return@addSnapshotListener }
                if (snap == null || !snap.exists()) return@addSnapshotListener
                val links = ChannelLinks(
                    azteca = snap.getString("azteca").orEmpty(),
                    cn = snap.getString("cn").orEmpty(),
                    raid = snap.getString("raid").orEmpty(),
                    telefe = snap.getString("telefe").orEmpty(),
                    telemundo = snap.getString("telemundo").orEmpty(),
                    tn = snap.getString("tn").orEmpty()
                )
                onUpdate(links)
            }
    }

    /** Lectura puntual (sin listener en vivo), por si no necesitas tiempo real. */
    suspend fun fetchOnce(): ChannelLinks {
        val snap: DocumentSnapshot = suspendCancellableCoroutine { cont ->
            db.collection("fix_channel").document("channel").get()
                .addOnSuccessListener { cont.resume(it) }
                .addOnFailureListener { cont.resumeWithException(it) }
        }
        return ChannelLinks(
            azteca = snap.getString("azteca").orEmpty(),
            cn = snap.getString("cn").orEmpty(),
            raid = snap.getString("raid").orEmpty(),
            telefe = snap.getString("telefe").orEmpty(),
            telemundo = snap.getString("telemundo").orEmpty(),
            tn = snap.getString("tn").orEmpty()
        )
    }
}
