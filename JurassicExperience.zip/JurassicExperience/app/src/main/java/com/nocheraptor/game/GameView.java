package com.nocheraptor.game;

import android.app.Activity;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * JURASSIC EXPERIENCE
 *  - 7 noches, dificultad creciente + 4 niveles de dificultad (opciones).
 *  - Energía: la luz y las trampillas cerradas gastan batería. Sin energía, el raptor te encuentra.
 *  - Trampillas (techo y pared derecha): se abren/cierran cuando quieras con su botón o tocando la rejilla.
 *    Cuando el raptor se acerca por una trampilla se ve una luz brillante entre las rendijas.
 *  - Puerta (izquierda): mantén LUZ sobre el raptor para echarlo.
 *  - Menú: continuar, nueva partida, elegir noche, opciones (dificultad, sonido, botones, idioma) y salir.
 */
public class GameView extends View {

    // ===================== AJUSTES (fáciles de cambiar) =====================
    /** Tamaño de room.png con el que se midieron las zonas de abajo. */
    private static final float REF_W = 1672f, REF_H = 941f;
    private static final float ZOOM = 1.6f;              // cuánto se acerca la cámara a la sala
    private static final float HOUR_SECONDS = 45f;       // duración de cada "hora" de la noche
    private static final float STEPS_TIME = 2.6f;        // pasos antes de que aparezca en la puerta
    private static final float LIGHT_NEEDED = 1.2f;      // segundos de luz para echarlo
    private static final float CARD_TIME = 2.8f;         // duración de la tarjeta "NOCHE N"
    /** Posición del ojo dentro de dino.png (fracción del ancho/alto). */
    private static final float EYE_FX = 0.790f, EYE_FY = 0.072f;

    /** Noches 1-3: el dinosaurio da unos segundos extra para echarlo. */
    private static final int EASY_NIGHTS = 3;
    private static final float EASY_DOOR_BONUS = 3f;     // segundos extra en la puerta
    private static final float EASY_VENT_BONUS = 2f;     // segundos extra para cerrar una trampilla

    /** Energía: % que se gasta por segundo (estilo FNAF: base de la noche + cada cosa encendida). */
    private static final float[] BASE_DRAIN = {0.115f, 0.125f, 0.135f, 0.150f, 0.165f, 0.180f, 0.200f};
    private static final float HATCH_DRAIN = 0.09f;     // por cada trampilla cerrada
    private static final float LIGHT_DRAIN = 0.11f;     // mientras mantienes la luz

    /** Dificultad: fácil, normal, difícil, extremo. */
    private static final float[] D_IDLE = {1.30f, 1.00f, 0.80f, 0.60f};   // tiempo entre ataques
    private static final float[] D_PAT = {1.25f, 1.00f, 0.85f, 0.70f};    // paciencia en la puerta
    private static final float[] D_VENT = {1.20f, 1.00f, 0.90f, 0.80f};   // tiempo de aviso en trampillas
    private static final float[] D_DRAIN = {0.80f, 1.00f, 1.15f, 1.35f};  // gasto de energía
    private static final float[] D_LIGHT = {0.90f, 1.00f, 1.10f, 1.25f};  // luz necesaria

    // estados del juego
    private static final int S_MENU = 0, S_CARD = 1, S_PLAY = 2, S_JUMPSCARE = 3, S_OVER = 4, S_WIN = 5;
    // pantallas del menú
    private static final int SC_MAIN = 0, SC_SELECT = 1, SC_OPTIONS = 2, SC_SOUND = 3, SC_LAYOUT = 4;
    // estados del raptor
    private static final int R_IDLE = 0, R_DOOR_STEPS = 1, R_DOOR_PRESENT = 2, R_DOOR_LEAVE = 3, R_VENT = 4;
    // entradas
    private static final int E_DOOR = 0, E_CEIL = 1, E_RIGHT = 2;
    // ids de botones de interfaz
    private static final int B_CONTINUE = 1, B_NEW = 2, B_SELECT = 3, B_OPTIONS = 4, B_EXIT = 5, B_BACK = 6;
    private static final int B_SOUND = 7, B_LAYOUT = 8, B_YES = 9, B_NO = 10, B_RETRY = 11, B_MENU = 12;
    private static final int B_L_MINUS = 13, B_L_PLUS = 14, B_L_RESET = 15, B_L_DONE = 16;
    private static final int B_SL_MUSIC = 17, B_SL_SFX = 18;
    private static final int B_NIGHT = 100, B_DIFF = 120, B_LANG = 130;

    private static final String[] HOURS = {"12 AM", "1 AM", "2 AM", "3 AM", "4 AM", "5 AM"};

    private final Random rnd = new Random();
    private final float density;
    private final Settings cfg;

    // ---- imágenes ----
    private Bitmap room, dinoFull, dinoDoor;
    private float worldW = REF_W, worldH = REF_H;
    private int dinoW = 1, dinoH = 1;

    // ---- pantalla y cámara ----
    private int sw = 1, sh = 1;
    private float scale = 1f, visW = 1f, visH = 1f;
    private float camX, camY, velX, velY;

    // ---- zonas (coordenadas del mundo = píxeles de room.png) ----
    private final RectF doorRect = new RectF();
    private final RectF dinoRect = new RectF();
    private final RectF ceilTap = new RectF();
    private final RectF rightTap = new RectF();
    private final RectF tmpRect = new RectF();
    private final RectF btnRect = new RectF();
    private final RectF jumpRect = new RectF();
    private final Path ceilPath = new Path();
    private final Path rightPath = new Path();
    private float aimWX, aimWY;     // punto de la cabeza del raptor en la puerta

    // ---- pinceles ----
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint dinoPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shutterFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shutterLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint slatPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint eyePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint beamPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vignettePaint = new Paint();
    private final ColorMatrix cm = new ColorMatrix();
    private ColorMatrixColorFilter menuFilter;
    private float eyeR = 46f;
    private float beamR = 600f;

    // ---- entrada táctil (juego) ----
    private int panPointer = -1, lightPointer = -1;
    private float lastX, lastY, moved;
    private long lastT, downT;
    private boolean lightOn;

    // ---- interfaz (menús) ----
    private final RectF[] uiR = new RectF[48];
    private final int[] uiId = new int[48];
    private int uiN;
    private int pressedId, sliderId, dragCtl = -1, selCtl;
    private float dragDX, dragDY;
    private int screen = SC_MAIN;
    private boolean confirmNew;

    // ---- juego ----
    private int state = S_MENU;
    private float stateTime;
    private int night = 1;
    private float nightTime, hintTime;
    private float power = 100f;
    private boolean powerOut, blackSteps;
    private float blackTimer;
    private final boolean[] hatchClosed = new boolean[2];
    private final float[] hatchAnim = new float[2];
    private float beamX, beamY;
    private boolean beamOnDoor;
    private float litLevel;

    // ---- raptor ----
    private int rs = R_IDLE;
    private float rTime, idleTimer, doorPatience, ventTime, lightAccum, lightNeed, doorAlpha;
    private boolean firstEvent = true;
    private int curEntrance = E_DOOR, lastEntrance = -1, sameCount;

    // ---- audio ----
    private SoundPool pool;
    private MediaPlayer ambient;
    private final Set<Integer> loaded = Collections.synchronizedSet(new HashSet<Integer>());
    private int sndSteps, sndVent, sndGrowl, sndScreech, sndClank, sndClick;
    private int ventStream;
    private float ventBaseL, ventBaseR;

    // ---- bucle ----
    private long lastNanos;
    private boolean paused;

    public GameView(Context ctx) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;
        cfg = new Settings(ctx);
        for (int i = 0; i < uiR.length; i++) uiR[i] = new RectF();
        room = loadAsset("img/room.png");
        dinoFull = loadAsset("img/dino.png");
        if (room != null) {
            worldW = room.getWidth();
            worldH = room.getHeight();
        }
        if (dinoFull != null) {
            dinoW = dinoFull.getWidth();
            dinoH = dinoFull.getHeight();
        }
        initPaints();
        layoutWorld();
        initAudio();
        resetGame();
        state = S_MENU;
        screen = SC_MAIN;
    }

    /** Texto según el idioma elegido. */
    private String tr(String es, String en) {
        return cfg.lang == 1 ? en : es;
    }

    // =====================================================================
    //  Carga e inicialización
    // =====================================================================
    private Bitmap loadAsset(String name) {
        try (InputStream in = getContext().getAssets().open(name)) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            return BitmapFactory.decodeStream(in, null, o);
        } catch (IOException e) {
            return null;
        }
    }

    private void initPaints() {
        textPaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        shutterFill.setStyle(Paint.Style.FILL);
        shutterFill.setColor(0xFF1E2226);
        shutterLine.setStyle(Paint.Style.STROKE);
        shutterLine.setColor(0xFF0A0C0E);
        slatPaint.setStyle(Paint.Style.STROKE);
        slatPaint.setColor(0xFF060708);
        strokePaint.setStyle(Paint.Style.STROKE);
        cm.setScale(0.55f, 0.6f, 0.55f, 1f);
        menuFilter = new ColorMatrixColorFilter(cm);
        // luz brillante de las trampillas (radio 1; se escala al dibujar)
        glowPaint.setShader(new RadialGradient(0f, 0f, 1f,
                new int[]{0xFFFFF8D0, 0xFFFFC840, 0x00FF9A00},
                new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
    }

    /** Convierte una coordenada de la imagen de referencia al mundo real. */
    private float wx(float refX) {
        return refX / REF_W * worldW;
    }

    private float wy(float refY) {
        return refY / REF_H * worldH;
    }

    private void layoutWorld() {
        // Puerta de la izquierda
        doorRect.set(wx(140f), wy(160f), wx(285f), wy(690f));

        // El raptor aparece de pie dentro de la puerta
        float dhWorld = wy(400f);
        float dwWorld = dhWorld * dinoW / dinoH;
        float left = doorRect.centerX() - dwWorld * 0.45f;
        float bottom = wy(700f);
        dinoRect.set(left, bottom - dhWorld, left + dwWorld, bottom);
        aimWX = dinoRect.left + EYE_FX * dinoRect.width();
        aimWY = dinoRect.top + EYE_FY * dinoRect.height();
        eyeR = wy(46f);

        // Rejilla del techo (trapecio)
        ceilPath.reset();
        ceilPath.moveTo(wx(640f), wy(25f));
        ceilPath.lineTo(wx(1025f), wy(25f));
        ceilPath.lineTo(wx(985f), wy(135f));
        ceilPath.lineTo(wx(685f), wy(135f));
        ceilPath.close();
        ceilTap.set(wx(600f), 0f, wx(1070f), wy(190f));

        // Rejilla de la pared derecha
        rightPath.reset();
        rightPath.addRect(wx(1398f), wy(172f), wx(1562f), wy(456f), Path.Direction.CW);
        rightTap.set(wx(1340f), wy(120f), wx(1620f), wy(520f));

        shutterLine.setStrokeWidth(wy(5f));
        slatPaint.setStrokeWidth(wy(7f));

        // Resplandor del ojo
        eyePaint.setShader(new RadialGradient(0f, 0f, eyeR,
                new int[]{0xFFFFE070, 0x88FFC030, 0x00FFB000},
                new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
    }

    private void initAudio() {
        try {
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            pool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(aa).build();
            pool.setOnLoadCompleteListener((sp, id, status) -> {
                if (status == 0) loaded.add(id);
            });
            sndSteps = loadSnd("sounds/steps.wav");
            sndVent = loadSnd("sounds/vent_scratch.wav");
            sndGrowl = loadSnd("sounds/growl.wav");
            sndScreech = loadSnd("sounds/screech.wav");
            sndClank = loadSnd("sounds/clank.wav");
            sndClick = loadSnd("sounds/click.wav");
        } catch (Exception e) {
            pool = null;
        }
        try {
            AssetFileDescriptor afd = getContext().getAssets().openFd("sounds/ambient.wav");
            ambient = new MediaPlayer();
            ambient.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            ambient.setLooping(true);
            ambient.prepare();
        } catch (Exception e) {
            ambient = null;
        }
        applyVolumes();
    }

    private void applyVolumes() {
        if (ambient == null) return;
        try {
            float v = 0.5f * cfg.musicVol;
            ambient.setVolume(v, v);
        } catch (Exception ignored) {
        }
    }

    private int loadSnd(String path) {
        if (pool == null) return 0;
        try (AssetFileDescriptor afd = getContext().getAssets().openFd(path)) {
            return pool.load(afd, 1);
        } catch (IOException e) {
            return 0;
        }
    }

    private int play(int id, float l, float r, int loop, float rate) {
        if (pool == null || id == 0 || !loaded.contains(id) || cfg.sfxVol <= 0.001f) return 0;
        float v = cfg.sfxVol;
        return pool.play(id, Math.min(1f, l * v), Math.min(1f, r * v), 1, loop, rate);
    }

    private void stopVent() {
        if (ventStream != 0 && pool != null) pool.stop(ventStream);
        ventStream = 0;
    }

    // ---- ciclo de vida (lo llama MainActivity) ----
    public void onHostResume() {
        paused = false;
        lastNanos = 0;
        if (pool != null) pool.autoResume();
        if (ambient != null) {
            try {
                ambient.start();
            } catch (Exception ignored) {
            }
        }
        postInvalidateOnAnimation();
    }

    public void onHostPause() {
        paused = true;
        panPointer = -1;
        lightPointer = -1;
        lightOn = false;
        pressedId = 0;
        sliderId = 0;
        if (dragCtl >= 0) {
            dragCtl = -1;
            cfg.save();
        }
        if (pool != null) pool.autoPause();
        if (ambient != null) {
            try {
                ambient.pause();
            } catch (Exception ignored) {
            }
        }
    }

    public void release() {
        try {
            if (pool != null) pool.release();
        } catch (Exception ignored) {
        }
        pool = null;
        try {
            if (ambient != null) ambient.release();
        } catch (Exception ignored) {
        }
        ambient = null;
    }

    /** Botón "atrás" del teléfono. Devuelve true si el juego lo gestionó. */
    public boolean onBack() {
        if (state != S_MENU) {
            showMenu(SC_MAIN);
            return true;
        }
        if (confirmNew) {
            confirmNew = false;
            return true;
        }
        switch (screen) {
            case SC_LAYOUT:
                cfg.save();
                screen = SC_OPTIONS;
                return true;
            case SC_SOUND:
                cfg.save();
                screen = SC_OPTIONS;
                return true;
            case SC_SELECT:
            case SC_OPTIONS:
                screen = SC_MAIN;
                return true;
            default:
                return false;
        }
    }

    // =====================================================================
    //  Tamaño de pantalla y cámara
    // =====================================================================
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        sw = Math.max(1, w);
        sh = Math.max(1, h);
        scale = ZOOM * Math.max(sw / worldW, sh / worldH);
        visW = sw / scale;
        visH = sh / scale;

        beamR = sh * 0.62f;
        beamX = sw / 2f;
        beamY = sh / 2f;

        beamPaint.setShader(new RadialGradient(0f, 0f, beamR,
                new int[]{0x70FFF3CC, 0x38FFF3CC, 0x00FFF3CC},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        vignettePaint.setShader(new RadialGradient(sw / 2f, sh / 2f,
                (float) Math.hypot(sw, sh) / 2f,
                new int[]{0x00000000, 0x00000000, 0xB8000000},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));

        // Raptor de la puerta a la medida exacta en pantalla (se ve nítido)
        if (dinoFull != null) {
            int pw = Math.max(1, Math.round(dinoRect.width() * scale));
            int ph = Math.max(1, Math.round(dinoRect.height() * scale));
            dinoDoor = Bitmap.createScaledBitmap(dinoFull, pw, ph, true);
        }
        clampCam();
    }

    private float camLeft() {
        return camX - visW / 2f;
    }

    private float camTop() {
        return camY - visH / 2f;
    }

    private void clampCam() {
        float minX = visW / 2f, maxX = worldW - visW / 2f;
        float minY = visH / 2f, maxY = worldH - visH / 2f;
        if (camX < minX) {
            camX = minX;
            velX = 0f;
        }
        if (camX > maxX) {
            camX = maxX;
            velX = 0f;
        }
        if (camY < minY) {
            camY = minY;
            velY = 0f;
        }
        if (camY > maxY) {
            camY = maxY;
            velY = 0f;
        }
    }

    // =====================================================================
    //  Botones en pantalla (posición y tamaño configurables)
    // =====================================================================
    private float ctlPx(int i) {
        return cfg.cx[i] * sw;
    }

    private float ctlPy(int i) {
        return cfg.cy[i] * sh;
    }

    private float ctlR(int i) {
        return sh * (i == 0 ? 0.11f : 0.085f) * cfg.cs[i];
    }

    /** Devuelve qué botón de juego está bajo el dedo (0 luz, 1 techo, 2 pared) o -1. */
    private int ctlHit(float x, float y) {
        for (int i = 2; i >= 0; i--) {
            if (Math.hypot(x - ctlPx(i), y - ctlPy(i)) <= ctlR(i) * 1.25f) return i;
        }
        return -1;
    }

    // =====================================================================
    //  Entrada táctil
    // =====================================================================
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (state) {
            case S_PLAY:
                return touchPlay(e);
            case S_MENU:
            case S_OVER:
                return touchUi(e);
            case S_WIN:
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN && stateTime > 1f) afterWin();
                return true;
            default:
                return true;
        }
    }

    private boolean touchPlay(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();

        if (action == MotionEvent.ACTION_CANCEL) {
            panPointer = -1;
            lightPointer = -1;
            setLight(false);
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int id = e.getPointerId(idx);
                float x = e.getX(idx), y = e.getY(idx);
                int ci = ctlHit(x, y);
                if (ci == 0) {
                    if (lightPointer == -1) {
                        lightPointer = id;
                        setLight(true);
                    }
                } else if (ci > 0) {
                    toggleHatch(ci - 1);
                } else if (panPointer == -1) {
                    panPointer = id;
                    lastX = x;
                    lastY = y;
                    moved = 0f;
                    downT = e.getEventTime();
                    lastT = downT;
                    velX = 0f;
                    velY = 0f;
                }
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                if (panPointer != -1) {
                    int pi = e.findPointerIndex(panPointer);
                    if (pi >= 0) {
                        float x = e.getX(pi), y = e.getY(pi);
                        float dx = x - lastX, dy = y - lastY;
                        moved += (float) Math.hypot(dx, dy);
                        camX -= dx / scale;
                        camY -= dy / scale;
                        long t = e.getEventTime();
                        float dt = Math.max(1L, t - lastT) / 1000f;
                        velX = velX * 0.6f + 0.4f * (-dx / scale / dt);
                        velY = velY * 0.6f + 0.4f * (-dy / scale / dt);
                        lastT = t;
                        lastX = x;
                        lastY = y;
                        clampCam();
                    }
                }
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                int id = e.getPointerId(idx);
                if (id == lightPointer) {
                    lightPointer = -1;
                    setLight(false);
                }
                if (id == panPointer) {
                    panPointer = -1;
                    float x = e.getX(idx), y = e.getY(idx);
                    boolean isTap = moved < 14f * density && (e.getEventTime() - downT) < 400;
                    if (isTap) handleTap(x, y);
                }
                break;
            }
            default:
                break;
        }
        return true;
    }

    private void setLight(boolean on) {
        if (state != S_PLAY || powerOut) on = false;
        if (on && !lightOn) play(sndClick, 0.7f, 0.7f, 0, 1f);
        lightOn = on;
    }

    /** Toque corto en el mundo: si cae sobre una rejilla, abre/cierra su trampilla. */
    private void handleTap(float x, float y) {
        float wxp = camLeft() + x / scale;
        float wyp = camTop() + y / scale;
        if (ceilTap.contains(wxp, wyp)) toggleHatch(0);
        else if (rightTap.contains(wxp, wyp)) toggleHatch(1);
    }

    private void toggleHatch(int h) {
        if (state != S_PLAY || powerOut) return;
        hatchClosed[h] = !hatchClosed[h];
        float rate = hatchClosed[h] ? 0.85f : 1.15f;
        if (h == 0) play(sndClank, 0.8f, 0.8f, 0, rate);
        else play(sndClank, 0.35f, 0.9f, 0, rate);
    }

    // ---- menús ----
    private void ui(int id, float l, float t, float r, float b) {
        if (uiN >= uiId.length) return;
        uiR[uiN].set(l, t, r, b);
        uiId[uiN] = id;
        uiN++;
    }

    private int uiHit(float x, float y) {
        for (int i = uiN - 1; i >= 0; i--) {
            if (uiR[i].contains(x, y)) return uiId[i];
        }
        return 0;
    }

    private float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private float trackL() {
        return sw * 0.38f;
    }

    private float trackR() {
        return sw * 0.84f;
    }

    private void setSlider(int id, float x) {
        float v = clamp((x - trackL()) / (trackR() - trackL()), 0f, 1f);
        if (id == B_SL_MUSIC) {
            cfg.musicVol = v;
            applyVolumes();
        } else {
            cfg.sfxVol = v;
        }
    }

    private boolean touchUi(MotionEvent e) {
        int a = e.getActionMasked();
        float x = e.getX(), y = e.getY();
        boolean layout = state == S_MENU && screen == SC_LAYOUT;
        switch (a) {
            case MotionEvent.ACTION_DOWN:
                pressedId = uiHit(x, y);
                sliderId = 0;
                dragCtl = -1;
                if (pressedId == B_SL_MUSIC || pressedId == B_SL_SFX) {
                    sliderId = pressedId;
                    setSlider(sliderId, x);
                } else if (pressedId == 0 && layout) {
                    for (int i = 2; i >= 0; i--) {
                        if (Math.hypot(x - ctlPx(i), y - ctlPy(i)) <= ctlR(i) * 1.1f) {
                            selCtl = i;
                            dragCtl = i;
                            dragDX = x - ctlPx(i);
                            dragDY = y - ctlPy(i);
                            break;
                        }
                    }
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (sliderId != 0) {
                    setSlider(sliderId, x);
                } else if (dragCtl >= 0) {
                    cfg.cx[dragCtl] = clamp((x - dragDX) / sw, 0.04f, 0.96f);
                    cfg.cy[dragCtl] = clamp((y - dragDY) / sh, 0.04f, 0.96f);
                }
                break;
            case MotionEvent.ACTION_UP:
                if (sliderId != 0) {
                    cfg.save();
                    if (sliderId == B_SL_SFX) play(sndClick, 0.8f, 0.8f, 0, 1f);
                } else if (dragCtl >= 0) {
                    cfg.save();
                } else if (pressedId != 0 && uiHit(x, y) == pressedId) {
                    play(sndClick, 0.6f, 0.6f, 0, 1f);
                    onUi(pressedId);
                }
                pressedId = 0;
                sliderId = 0;
                dragCtl = -1;
                break;
            case MotionEvent.ACTION_CANCEL:
                pressedId = 0;
                sliderId = 0;
                dragCtl = -1;
                break;
            default:
                break;
        }
        return true;
    }

    private void onUi(int id) {
        if (id > B_NIGHT && id <= B_NIGHT + Settings.NIGHTS) {
            int n = id - B_NIGHT;
            if (n <= cfg.unlocked) startNight(n);
            return;
        }
        if (id >= B_DIFF && id < B_DIFF + 4) {
            cfg.difficulty = id - B_DIFF;
            cfg.save();
            return;
        }
        if (id >= B_LANG && id < B_LANG + 2) {
            cfg.lang = id - B_LANG;
            cfg.save();
            return;
        }
        switch (id) {
            case B_CONTINUE:
                startNight(cfg.current);
                break;
            case B_NEW:
                if (cfg.unlocked > 1 || cfg.current > 1) confirmNew = true;
                else newGame();
                break;
            case B_YES:
                confirmNew = false;
                newGame();
                break;
            case B_NO:
                confirmNew = false;
                break;
            case B_SELECT:
                screen = SC_SELECT;
                break;
            case B_OPTIONS:
                screen = SC_OPTIONS;
                break;
            case B_EXIT:
                if (getContext() instanceof Activity) ((Activity) getContext()).finish();
                break;
            case B_BACK:
                screen = (screen == SC_SOUND) ? SC_OPTIONS : SC_MAIN;
                cfg.save();
                break;
            case B_SOUND:
                screen = SC_SOUND;
                break;
            case B_LAYOUT:
                screen = SC_LAYOUT;
                selCtl = 0;
                break;
            case B_L_MINUS:
                cfg.cs[selCtl] = clamp(cfg.cs[selCtl] - 0.1f, 0.5f, 1.8f);
                cfg.save();
                break;
            case B_L_PLUS:
                cfg.cs[selCtl] = clamp(cfg.cs[selCtl] + 0.1f, 0.5f, 1.8f);
                cfg.save();
                break;
            case B_L_RESET:
                cfg.resetLayout();
                break;
            case B_L_DONE:
                cfg.save();
                screen = SC_OPTIONS;
                break;
            case B_RETRY:
                startNight(night);
                break;
            case B_MENU:
                showMenu(SC_MAIN);
                break;
            default:
                break;
        }
    }

    private void showMenu(int sc) {
        stopVent();
        lightOn = false;
        panPointer = -1;
        lightPointer = -1;
        state = S_MENU;
        screen = sc;
        confirmNew = false;
        stateTime = 0f;
    }

    private void newGame() {
        cfg.unlocked = 1;
        cfg.current = 1;
        cfg.save();
        startNight(1);
    }

    private void startNight(int n) {
        night = Math.max(1, Math.min(Settings.NIGHTS, n));
        cfg.current = night;
        cfg.save();
        resetGame();
        state = S_CARD;
        stateTime = 0f;
    }

    private void afterWin() {
        if (night < Settings.NIGHTS) startNight(night + 1);
        else showMenu(SC_MAIN);
    }

    // =====================================================================
    //  Lógica
    // =====================================================================
    private void resetGame() {
        nightTime = 0f;
        hintTime = 0f;
        power = 100f;
        powerOut = false;
        blackSteps = false;
        blackTimer = 0f;
        rs = R_IDLE;
        rTime = 0f;
        float first = Math.max(5f, 10f - 0.7f * (night - 1));
        idleTimer = first * D_IDLE[cfg.difficulty];
        firstEvent = true;
        sameCount = 0;
        lastEntrance = -1;
        hatchClosed[0] = false;
        hatchClosed[1] = false;
        hatchAnim[0] = 0f;
        hatchAnim[1] = 0f;
        lightOn = false;
        lightAccum = 0f;
        litLevel = 0f;
        doorAlpha = 0f;
        panPointer = -1;
        lightPointer = -1;
        velX = 0f;
        velY = 0f;
        camX = worldW * 0.5f;
        camY = worldH * 0.5f;
        stopVent();
        clampCam();
    }

    private void update(float dt) {
        stateTime += dt;
        switch (state) {
            case S_PLAY:
                updatePlay(dt);
                break;
            case S_CARD:
                if (stateTime >= CARD_TIME) {
                    state = S_PLAY;
                    stateTime = 0f;
                    hintTime = 0f;
                }
                break;
            case S_JUMPSCARE:
                if (stateTime >= 1.8f) {
                    state = S_OVER;
                    stateTime = 0f;
                }
                break;
            default:
                break;
        }
    }

    private void updatePlay(float dt) {
        nightTime += dt;
        hintTime += dt;
        if (nightTime >= 6f * HOUR_SECONDS) {
            winNight();
            return;
        }

        // Cámara con inercia
        if (panPointer == -1) {
            camX += velX * dt;
            camY += velY * dt;
            float damp = (float) Math.exp(-5.0 * dt);
            velX *= damp;
            velY *= damp;
            if (Math.abs(velX) < 2f) velX = 0f;
            if (Math.abs(velY) < 2f) velY = 0f;
        }
        clampCam();

        // Animación de las trampillas
        for (int i = 0; i < 2; i++) {
            if (hatchClosed[i]) hatchAnim[i] = Math.min(1f, hatchAnim[i] + dt * 8f);
            else hatchAnim[i] = Math.max(0f, hatchAnim[i] - dt * 5f);
        }

        // Energía
        if (!powerOut) {
            float rate = BASE_DRAIN[night - 1]
                    + (hatchClosed[0] ? HATCH_DRAIN : 0f)
                    + (hatchClosed[1] ? HATCH_DRAIN : 0f)
                    + (lightOn ? LIGHT_DRAIN : 0f);
            power -= rate * D_DRAIN[cfg.difficulty] * dt;
            if (power <= 0f) {
                power = 0f;
                startBlackout();
            }
        }

        // Linterna: ¿la cabeza del raptor está en pantalla? Entonces el haz va hacia ella.
        float aimSx = (aimWX - camLeft()) * scale;
        float aimSy = (aimWY - camTop()) * scale;
        boolean aimInView = aimSx > sw * 0.08f && aimSx < sw * 0.75f
                && aimSy > sh * 0.10f && aimSy < sh * 0.90f;
        float tx = aimInView ? aimSx : sw / 2f;
        float ty = aimInView ? aimSy : sh / 2f;
        float k = Math.min(1f, dt * 10f);
        beamX += (tx - beamX) * k;
        beamY += (ty - beamY) * k;
        beamOnDoor = lightOn && aimInView;
        if (beamOnDoor) litLevel = Math.min(1f, litLevel + dt * 6f);
        else litLevel = Math.max(0f, litLevel - dt * 3f);

        if (powerOut) updateBlackout(dt);
        else updateRaptor(dt);
    }

    private int hourNow() {
        return Math.min(5, (int) (nightTime / HOUR_SECONDS));
    }

    /** Nivel de dificultad interno: sube con cada noche y con cada hora. */
    private float level() {
        return (night - 1) + 0.4f * hourNow();
    }

    private void startBlackout() {
        powerOut = true;
        lightOn = false;
        lightPointer = -1;
        hatchClosed[0] = false;
        hatchClosed[1] = false;
        stopVent();
        rs = R_IDLE;
        rTime = 0f;
        blackSteps = false;
        blackTimer = 7f + rnd.nextFloat() * 4f;
        play(sndClank, 0.8f, 0.8f, 0, 0.6f);
        play(sndGrowl, 0.5f, 0.5f, 0, 0.7f);
    }

    private void updateBlackout(float dt) {
        rTime += dt;
        doorAlpha = Math.min(1f, doorAlpha + dt * 0.5f);
        if (!blackSteps && rTime > 2.5f) {
            blackSteps = true;
            play(sndSteps, 0.9f, 0.35f, 0, 0.9f);
        }
        blackTimer -= dt;
        if (blackTimer <= 0f) startJumpscare();
    }

    private void updateRaptor(float dt) {
        int hour = hourNow();
        rTime += dt;

        switch (rs) {
            case R_IDLE:
                idleTimer -= dt;
                if (idleTimer <= 0f) startApproach(chooseEntrance(), hour);
                break;

            case R_DOOR_STEPS:
                if (rTime >= STEPS_TIME) {
                    rs = R_DOOR_PRESENT;
                    rTime = 0f;
                    lightAccum = 0f;
                }
                break;

            case R_DOOR_PRESENT:
                doorAlpha = Math.min(1f, doorAlpha + dt * 2.5f);
                if (beamOnDoor) lightAccum += dt;
                else lightAccum = Math.max(0f, lightAccum - 0.6f * dt);
                if (lightAccum >= lightNeed) {
                    rs = R_DOOR_LEAVE;
                    rTime = 0f;
                    play(sndGrowl, 0.9f, 0.4f, 0, 1f);
                } else if (rTime >= doorPatience) {
                    startJumpscare();
                }
                break;

            case R_DOOR_LEAVE:
                doorAlpha = Math.max(0f, doorAlpha - dt * 2.2f);
                if (rTime >= 0.9f) goIdle();
                break;

            case R_VENT: {
                float p = Math.min(1f, rTime / ventTime);
                float vol = 0.25f + 0.75f * p;
                if (ventStream != 0 && pool != null) {
                    pool.setVolume(ventStream,
                            Math.min(1f, ventBaseL * vol * cfg.sfxVol),
                            Math.min(1f, ventBaseR * vol * cfg.sfxVol));
                }
                if (rTime >= ventTime) arriveAtVent();
                break;
            }
            default:
                break;
        }
    }

    private int chooseEntrance() {
        if (firstEvent) {
            firstEvent = false;
            lastEntrance = E_DOOR;
            sameCount = 1;
            return E_DOOR;
        }
        float r = rnd.nextFloat();
        int e = r < 0.40f ? E_DOOR : (r < 0.70f ? E_CEIL : E_RIGHT);
        if (e == lastEntrance && sameCount >= 2) e = (e + 1 + rnd.nextInt(2)) % 3;
        if (e == lastEntrance) sameCount++;
        else sameCount = 1;
        lastEntrance = e;
        return e;
    }

    private void startApproach(int e, int hour) {
        curEntrance = e;
        rTime = 0f;
        float lvl = level();
        int d = cfg.difficulty;
        boolean easy = night <= EASY_NIGHTS;
        if (e == E_DOOR) {
            rs = R_DOOR_STEPS;
            doorAlpha = 0f;
            doorPatience = Math.max(2.2f, Math.max(2.6f, 7.5f - 0.45f * lvl) * D_PAT[d])
                    + (easy ? EASY_DOOR_BONUS : 0f);
            lightNeed = LIGHT_NEEDED * D_LIGHT[d];
            play(sndSteps, 0.9f, 0.35f, 0, 1f);
        } else {
            rs = R_VENT;
            ventTime = Math.max(3.5f, Math.max(3.5f, 9f - 0.55f * lvl) * D_VENT[d])
                    + (easy ? EASY_VENT_BONUS : 0f);
            float rate;
            if (e == E_RIGHT) {
                ventBaseL = 0.30f;
                ventBaseR = 1.00f;
                rate = 1.0f;
            } else {
                ventBaseL = 0.85f;
                ventBaseR = 0.85f;
                rate = 0.7f;
            }
            stopVent();
            ventStream = play(sndVent, ventBaseL * 0.25f, ventBaseR * 0.25f, -1, rate);
        }
    }

    private void arriveAtVent() {
        stopVent();
        int h = (curEntrance == E_CEIL) ? 0 : 1;
        if (hatchClosed[h]) {
            // La trampilla estaba cerrada: golpea y se va
            float l = (h == 0) ? 0.8f : 0.35f;
            float r = (h == 0) ? 0.8f : 0.95f;
            play(sndClank, l, r, 0, 1f);
            play(sndGrowl, l, r, 0, 0.85f);
            goIdle();
        } else {
            startJumpscare();
        }
    }

    private void goIdle() {
        rs = R_IDLE;
        rTime = 0f;
        doorAlpha = 0f;
        float base = Math.max(3f, 11f - 0.75f * level());
        idleTimer = Math.max(2f, base * D_IDLE[cfg.difficulty] * (0.7f + rnd.nextFloat() * 0.6f));
    }

    private void startJumpscare() {
        stopVent();
        lightOn = false;
        panPointer = -1;
        lightPointer = -1;
        rs = R_IDLE;
        state = S_JUMPSCARE;
        stateTime = 0f;
        play(sndScreech, 1f, 1f, 0, 1f);
        vibrate(400);
    }

    private void winNight() {
        stopVent();
        lightOn = false;
        panPointer = -1;
        lightPointer = -1;
        int next = Math.min(Settings.NIGHTS, night + 1);
        cfg.unlocked = Math.max(cfg.unlocked, next);
        cfg.current = next;
        cfg.save();
        state = S_WIN;
        stateTime = 0f;
    }

    @SuppressWarnings("deprecation")
    private void vibrate(int ms) {
        try {
            Vibrator v = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(ms);
            }
        } catch (Exception ignored) {
        }
    }

    // =====================================================================
    //  Dibujo
    // =====================================================================
    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 0f : (now - lastNanos) / 1e9f;
        lastNanos = now;
        if (dt > 0.05f) dt = 0.05f;
        if (!paused) update(dt);
        render(c);
        if (!paused) postInvalidateOnAnimation();
    }

    private void render(Canvas c) {
        uiN = 0;
        c.drawColor(Color.BLACK);
        if (room == null) {
            textPaint.setTextAlign(Paint.Align.CENTER);
            drawCentered(c, "Falta assets/img/room.png", sw / 2f, sh / 2f, sh * 0.05f, Color.WHITE);
            return;
        }

        if (state == S_MENU) {
            renderMenu(c);
            c.drawRect(0f, 0f, sw, sh, vignettePaint);
            return;
        }
        if (state == S_CARD) {
            drawNightCard(c);
            return;
        }

        float shakeX = 0f, shakeY = 0f;
        if (state == S_JUMPSCARE) {
            float k = Math.max(0f, 1f - stateTime / 1.6f);
            shakeX = (rnd.nextFloat() - 0.5f) * 2f * sh * 0.03f * k;
            shakeY = (rnd.nextFloat() - 0.5f) * 2f * sh * 0.03f * k;
        }

        c.save();
        c.translate(shakeX, shakeY);

        // --- mundo ---
        c.save();
        c.scale(scale, scale);
        c.translate(-camLeft(), -camTop());
        c.drawBitmap(room, 0f, 0f, bmpPaint);
        drawVentGlow(c, ceilPath, 0);
        drawVentGlow(c, rightPath, 1);
        drawHatch(c, ceilPath, hatchAnim[0]);
        drawHatch(c, rightPath, hatchAnim[1]);
        if (powerOut) {
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(0xCC000000);
            c.drawRect(0f, 0f, worldW, worldH, fillPaint);
        }
        drawDoorRaptor(c);
        c.restore();

        // --- linterna ---
        if (lightOn && state == S_PLAY) {
            beamPaint.setAlpha((int) (255 * (0.80f + 0.20f * rnd.nextFloat())));
            c.save();
            c.translate(beamX, beamY);
            c.drawCircle(0f, 0f, beamR, beamPaint);
            c.restore();
        }

        // --- susto ---
        if (state == S_JUMPSCARE && dinoFull != null) drawJumpscare(c);

        c.restore();

        // viñeta
        c.drawRect(0f, 0f, sw, sh, vignettePaint);

        if (state == S_PLAY) drawHud(c);
        else if (state == S_OVER) drawGameOver(c);
        else if (state == S_WIN) drawWin(c);
    }

    private void drawHatch(Canvas c, Path p, float a) {
        if (a <= 0.01f) return;
        int al = (int) (235 * a);
        shutterFill.setAlpha(al);
        c.drawPath(p, shutterFill);
        c.save();
        c.clipPath(p);
        p.computeBounds(tmpRect, true);
        shutterLine.setAlpha(al);
        float step = tmpRect.height() / 6f;
        for (float y = tmpRect.top + step * 0.5f; y < tmpRect.bottom; y += step) {
            c.drawLine(tmpRect.left, y, tmpRect.right, y, shutterLine);
        }
        c.restore();
    }

    /** Luz brillante entre las rendijas cuando el raptor se acerca por una trampilla. */
    private void drawVentGlow(Canvas c, Path p, int h) {
        int ent = (h == 0) ? E_CEIL : E_RIGHT;
        if (rs != R_VENT || curEntrance != ent) return;
        float prog = Math.min(1f, rTime / ventTime);
        float flick = 0.78f + 0.22f * (float) Math.sin(nightTime * 14f + h * 2f)
                - 0.12f * rnd.nextFloat();
        float inten = Math.max(0.15f, Math.min(1f, (0.35f + 0.65f * prog) * flick));
        p.computeBounds(tmpRect, true);
        float cx = tmpRect.centerX(), cy = tmpRect.centerY();
        float w = tmpRect.width(), hh = tmpRect.height();
        float r = Math.max(w, hh) * (0.40f + 0.25f * prog);

        // resplandor suave que se escapa por fuera de la rejilla
        glowPaint.setAlpha((int) (255 * inten * 0.30f * (1f - 0.7f * hatchAnim[h])));
        c.save();
        c.translate(cx, cy);
        c.scale(r * 1.7f, r * 1.7f);
        c.drawCircle(0f, 0f, 1f, glowPaint);
        c.restore();

        // luz brillante dentro de la rejilla, con las rendijas oscuras por delante
        c.save();
        c.clipPath(p);
        glowPaint.setAlpha((int) (255 * inten));
        c.save();
        c.translate(cx, cy);
        c.scale(r, r);
        c.drawCircle(0f, 0f, 1f, glowPaint);
        c.restore();
        float step = hh / 6f;
        for (float y = tmpRect.top + step * 0.5f; y < tmpRect.bottom; y += step) {
            c.drawLine(tmpRect.left, y, tmpRect.right, y, slatPaint);
        }
        c.restore();
    }

    private void drawDoorRaptor(Canvas c) {
        if (doorAlpha <= 0.01f || dinoDoor == null) return;

        // Sin luz: casi negro. Con luz: se ve completo.
        float bright = 0.10f + 0.90f * litLevel;
        cm.setScale(bright, bright, bright, 1f);
        dinoPaint.setColorFilter(new ColorMatrixColorFilter(cm));
        dinoPaint.setAlpha((int) (255 * doorAlpha));
        c.drawBitmap(dinoDoor, null, dinoRect, dinoPaint);

        // Ojo brillante en la oscuridad
        float pulse = 0.75f + 0.25f * (float) Math.sin(nightTime * 9f);
        float a = doorAlpha * pulse * (1f - 0.65f * litLevel);
        eyePaint.setAlpha((int) (255 * Math.max(0f, Math.min(1f, a))));
        c.save();
        c.translate(aimWX, aimWY);
        c.drawCircle(0f, 0f, eyeR, eyePaint);
        c.restore();
    }

    private void drawJumpscare(Canvas c) {
        c.drawColor(0xB0000000);
        float k = Math.min(1f, stateTime / 0.16f);
        float dh = sh * (0.7f + 0.8f * k);
        float dw = dh * dinoW / dinoH;
        float jx = (rnd.nextFloat() - 0.5f) * sh * 0.03f;
        float jy = (rnd.nextFloat() - 0.5f) * sh * 0.03f;
        // Colocamos el ojo cerca del centro de la pantalla
        float left = sw * 0.52f - EYE_FX * dw + jx;
        float top = sh * 0.32f - EYE_FY * dh + jy;
        jumpRect.set(left, top, left + dw, top + dh);
        c.drawBitmap(dinoFull, null, jumpRect, bmpPaint);
        if (((int) (stateTime * 18f)) % 2 == 0) c.drawColor(0x40FF0000);
    }

    // ---------------------------------------------------------------------
    //  HUD
    // ---------------------------------------------------------------------
    private void drawHud(Canvas c) {
        drawClock(c);
        drawBattery(c, (int) Math.ceil(power));
        drawControls(c, false);

        // Pistas de los primeros segundos
        if (hintTime < 9f) {
            float alpha = hintTime < 7f ? 1f : (9f - hintTime) / 2f;
            textPaint.setShadowLayer(8f, 0f, 0f, Color.BLACK);
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTextSize(sh * 0.04f);
            textPaint.setColor(0xFFFFFFFF);
            textPaint.setAlpha((int) (255 * alpha));
            c.drawText(tr("Arrastra para mirar alrededor", "Drag to look around"),
                    sw / 2f, sh * 0.88f, textPaint);
            textPaint.setTextSize(sh * 0.030f);
            c.drawText(tr("Mantén LUZ para alumbrar  ·  Cierra las trampillas (gastan energía)",
                            "Hold LIGHT to shine  ·  Close the hatches (they use power)"),
                    sw / 2f, sh * 0.94f, textPaint);
            textPaint.setAlpha(255);
        }
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
    }

    private void drawClock(Canvas c) {
        float pad = sh * 0.05f;
        textPaint.setTextAlign(Paint.Align.RIGHT);
        textPaint.setShadowLayer(8f, 0f, 0f, Color.BLACK);
        textPaint.setTextSize(sh * 0.075f);
        textPaint.setColor(0xFFE8E8E8);
        c.drawText(HOURS[hourNow()], sw - pad, pad + sh * 0.075f, textPaint);
        textPaint.setTextSize(sh * 0.035f);
        textPaint.setColor(0xFF9AA0A6);
        c.drawText(tr("NOCHE ", "NIGHT ") + night, sw - pad, pad + sh * 0.075f + sh * 0.05f, textPaint);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
    }

    /** Porcentaje de batería en la esquina inferior izquierda, con las barras de consumo. */
    private void drawBattery(Canvas c, int pct) {
        float pad = sh * 0.05f;
        int col;
        if (pct > 40) col = 0xFFE8E8E8;
        else if (pct > 20) col = 0xFFEED17A;
        else col = (((int) (nightTime * 4f)) % 2 == 0) ? 0xFFE03030 : 0xFFFF8080;

        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setShadowLayer(8f, 0f, 0f, Color.BLACK);
        textPaint.setTextSize(sh * 0.032f);
        textPaint.setColor(0xFF9AA0A6);
        c.drawText(tr("ENERGÍA", "POWER"), pad, sh * 0.835f, textPaint);
        textPaint.setTextSize(sh * 0.075f);
        textPaint.setColor(col);
        c.drawText(pct + "%", pad, sh * 0.905f, textPaint);

        // consumo actual: 1 barra base + 1 por cada cosa activa
        int usage = 1 + (hatchClosed[0] ? 1 : 0) + (hatchClosed[1] ? 1 : 0) + (lightOn ? 1 : 0);
        float bw = sh * 0.035f, bh = sh * 0.028f, gap = sh * 0.008f, by = sh * 0.925f;
        fillPaint.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 4; i++) {
            int bc = i >= usage ? 0x44FFFFFF : (i < 2 ? 0xFF7FB86B : (i == 2 ? 0xFFEED17A : 0xFFE03030));
            fillPaint.setColor(bc);
            float x = pad + i * (bw + gap);
            c.drawRect(x, by, x + bw, by + bh, fillPaint);
        }
        textPaint.setTextSize(sh * 0.026f);
        textPaint.setColor(0xFF9AA0A6);
        c.drawText(tr("USO", "USE"), pad + 4 * (bw + gap) + gap * 2f, by + bh, textPaint);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
    }

    /** Dibuja los 3 botones: luz y las dos trampillas. */
    private void drawControls(Canvas c, boolean editing) {
        for (int i = 0; i < 3; i++) {
            float cx = ctlPx(i), cy = ctlPy(i), r = ctlR(i);
            boolean on = i == 0 ? lightOn : hatchClosed[i - 1];
            if (editing) on = false;
            int fill;
            if (i == 0) fill = on ? 0xEEEED17A : 0x88000000;
            else fill = on ? 0xEE7FB86B : 0x88000000;
            if (editing) fill = 0xAA101214;
            if (powerOut && !editing) fill = 0x44000000;
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(fill);
            c.drawCircle(cx, cy, r, fillPaint);
            boolean sel = editing && i == selCtl;
            strokePaint.setStrokeWidth(sh * (sel ? 0.010f : 0.006f));
            strokePaint.setColor(sel ? 0xFFEED17A : 0xCCFFFFFF);
            c.drawCircle(cx, cy, r, strokePaint);

            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setShadowLayer(0f, 0f, 0f, 0);
            int tc = on ? 0xFF222222 : 0xFFFFFFFF;
            if (i == 0) {
                drawFit(c, tr("LUZ", "LIGHT"), cx, cy + r * 0.16f, r * 0.45f, r * 1.7f, tc);
            } else {
                String name = i == 1 ? tr("TECHO", "CEIL") : tr("PARED", "WALL");
                drawFit(c, name, cx, cy - r * 0.02f, r * 0.34f, r * 1.7f, tc);
                String st = hatchClosed[i - 1] ? tr("CERRADA", "CLOSED") : tr("ABIERTA", "OPEN");
                drawFit(c, st, cx, cy + r * 0.40f, r * 0.22f, r * 1.7f, on ? 0xFF222222 : 0xFFB0B0B0);
            }
        }
    }

    private void drawFit(Canvas c, String s, float cx, float baseY, float size, float maxW, int color) {
        textPaint.setTextSize(size);
        float tw = textPaint.measureText(s);
        if (tw > maxW) {
            size *= maxW / tw;
            textPaint.setTextSize(size);
        }
        textPaint.setColor(color);
        textPaint.setTextAlign(Paint.Align.CENTER);
        c.drawText(s, cx, baseY, textPaint);
    }

    // ---------------------------------------------------------------------
    //  Tarjeta de noche, game over, victoria
    // ---------------------------------------------------------------------
    private void drawNightCard(Canvas c) {
        c.drawColor(Color.BLACK);
        float a = Math.min(1f, Math.min(stateTime / 0.6f, (CARD_TIME - stateTime) / 0.6f));
        a = Math.max(0f, a);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setAlpha(255);
        int al = (int) (255 * a) << 24;
        drawCentered(c, tr("NOCHE ", "NIGHT ") + night, sw / 2f, sh * 0.48f, sh * 0.14f,
                (0xFFDDE8C0 & 0x00FFFFFF) | al);
        drawCentered(c, "12 AM", sw / 2f, sh * 0.62f, sh * 0.06f, (0xFFB0B0B0 & 0x00FFFFFF) | al);
        String[] dn = {tr("FÁCIL", "EASY"), "NORMAL", tr("DIFÍCIL", "HARD"), tr("EXTREMO", "EXTREME")};
        drawCentered(c, dn[cfg.difficulty], sw / 2f, sh * 0.72f, sh * 0.035f, (0xFF8A9A7A & 0x00FFFFFF) | al);
    }

    private void drawGameOver(Canvas c) {
        c.drawColor(0xCC200000);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
        textPaint.setTextAlign(Paint.Align.CENTER);
        drawCentered(c, tr("TE ATRAPARON", "YOU WERE CAUGHT"), sw / 2f, sh * 0.40f, sh * 0.12f, 0xFFE03030);
        boolean ok = stateTime > 1f;
        float w = sh * 0.75f, h = sh * 0.115f;
        drawBtn(c, B_RETRY, tr("REINTENTAR", "RETRY"), sw / 2f, sh * 0.62f, w, h, false, ok);
        drawBtn(c, B_MENU, tr("MENÚ", "MENU"), sw / 2f, sh * 0.78f, w, h, false, ok);
    }

    private void drawWin(Canvas c) {
        c.drawColor(0xCC000000);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
        textPaint.setTextAlign(Paint.Align.CENTER);
        drawCentered(c, "6 AM", sw / 2f, sh * 0.42f, sh * 0.18f, 0xFFEED17A);
        if (night >= Settings.NIGHTS) {
            drawCentered(c, tr("¡Sobreviviste las 7 noches!", "You survived all 7 nights!"),
                    sw / 2f, sh * 0.58f, sh * 0.055f, Color.WHITE);
            drawCentered(c, "JURASSIC EXPERIENCE", sw / 2f, sh * 0.67f, sh * 0.04f, 0xFFDDE8C0);
        } else {
            drawCentered(c, tr("¡Sobreviviste la noche ", "You survived night ") + night + "!",
                    sw / 2f, sh * 0.58f, sh * 0.06f, Color.WHITE);
        }
        if (stateTime > 1f) {
            String s = night >= Settings.NIGHTS ? tr("Toca para volver al menú", "Tap to return to the menu")
                    : tr("Toca para la noche ", "Tap for night ") + (night + 1);
            drawCentered(c, s, sw / 2f, sh * 0.80f, sh * 0.04f, 0xFFB0B0B0);
        }
    }

    private void drawCentered(Canvas c, String s, float cx, float cy, float size, int color) {
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(size);
        textPaint.setColor(color);
        c.drawText(s, cx, cy, textPaint);
    }

    // =====================================================================
    //  Menús
    // =====================================================================
    private void drawBtn(Canvas c, int id, String label, float cx, float cy, float w, float h,
                         boolean sel, boolean enabled) {
        btnRect.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f);
        if (enabled) ui(id, btnRect.left, btnRect.top, btnRect.right, btnRect.bottom);
        boolean pressed = enabled && id == pressedId;
        fillPaint.setStyle(Paint.Style.FILL);
        int bg = !enabled ? 0x55202020 : sel ? 0xEE5E7A3C : pressed ? 0xEE3A4A2A : 0xCC15181A;
        fillPaint.setColor(bg);
        c.drawRoundRect(btnRect, h * 0.22f, h * 0.22f, fillPaint);
        strokePaint.setStrokeWidth(sh * 0.004f);
        strokePaint.setColor(!enabled ? 0x44666666 : sel ? 0xFFDDE8C0 : 0xAA9AA68A);
        c.drawRoundRect(btnRect, h * 0.22f, h * 0.22f, strokePaint);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
        drawFit(c, label, cx, cy + h * 0.15f, h * 0.42f, w * 0.9f, enabled ? 0xFFFFFFFF : 0x88AAAAAA);
    }

    private void drawLock(Canvas c, float cx, float cy, float s) {
        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setColor(0xFFB0B0B0);
        btnRect.set(cx - s * 0.5f, cy, cx + s * 0.5f, cy + s * 0.75f);
        c.drawRoundRect(btnRect, s * 0.1f, s * 0.1f, fillPaint);
        strokePaint.setStrokeWidth(s * 0.13f);
        strokePaint.setColor(0xFFB0B0B0);
        btnRect.set(cx - s * 0.3f, cy - s * 0.55f, cx + s * 0.3f, cy + s * 0.25f);
        c.drawArc(btnRect, 180f, 180f, false, strokePaint);
    }

    private void drawLeft(Canvas c, String s, float x, float y, float size, int color) {
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTextSize(size);
        textPaint.setColor(color);
        c.drawText(s, x, y, textPaint);
    }

    private void drawScreenTitle(Canvas c, String s) {
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
        drawCentered(c, s, sw / 2f, sh * 0.15f, sh * 0.09f, 0xFFDDE8C0);
    }

    private void renderMenu(Canvas c) {
        // Fondo: la sala, con una cámara que se mueve despacio
        camX = worldW * 0.5f + (float) Math.sin(stateTime * 0.2f) * worldW * 0.12f;
        camY = worldH * 0.5f;
        clampCam();
        c.save();
        c.scale(scale, scale);
        c.translate(-camLeft(), -camTop());
        c.drawBitmap(room, 0f, 0f, bmpPaint);
        c.restore();
        c.drawColor(screen == SC_LAYOUT ? 0x99000000 : 0xCC000000);

        switch (screen) {
            case SC_SELECT:
                drawSelectScreen(c);
                break;
            case SC_OPTIONS:
                drawOptionsScreen(c);
                break;
            case SC_SOUND:
                drawSoundScreen(c);
                break;
            case SC_LAYOUT:
                drawLayoutScreen(c);
                break;
            default:
                drawMainScreen(c);
                break;
        }
    }

    private void drawMainScreen(Canvas c) {
        // Raptor a la derecha
        if (dinoFull != null) {
            float dh = sh * 0.98f;
            float dw = dh * dinoW / dinoH;
            float left = sw - dw - sw * 0.02f;
            float top = sh * 0.02f;
            btnRect.set(left, top, left + dw, top + dh);
            dinoPaint.setColorFilter(menuFilter);
            dinoPaint.setAlpha(255);
            c.drawBitmap(dinoFull, null, btnRect, dinoPaint);
            float pulse = 0.7f + 0.3f * (float) Math.sin(stateTime * 3f);
            eyePaint.setAlpha((int) (255 * pulse));
            c.save();
            c.translate(left + EYE_FX * dw, top + EYE_FY * dh);
            float k = sh * 0.08f / eyeR;
            c.scale(k, k);
            c.drawCircle(0f, 0f, eyeR, eyePaint);
            c.restore();
        }

        float cx = sw * 0.30f;
        textPaint.setShadowLayer(10f, 0f, 0f, Color.BLACK);
        drawCentered(c, "JURASSIC", cx, sh * 0.16f, sh * 0.11f, 0xFFDDE8C0);
        drawCentered(c, "EXPERIENCE", cx, sh * 0.255f, sh * 0.075f, 0xFFB7C99A);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);

        boolean en = !confirmNew;
        float w = sh * 0.80f, h = sh * 0.105f, y0 = sh * 0.38f, step = sh * 0.125f;
        drawBtn(c, B_CONTINUE, tr("CONTINUAR (NOCHE ", "CONTINUE (NIGHT ") + cfg.current + ")",
                cx, y0, w, h, false, en);
        drawBtn(c, B_NEW, tr("NUEVA PARTIDA", "NEW GAME"), cx, y0 + step, w, h, false, en);
        drawBtn(c, B_SELECT, tr("SELECCIONAR NOCHE", "SELECT NIGHT"), cx, y0 + 2 * step, w, h, false, en);
        drawBtn(c, B_OPTIONS, tr("OPCIONES", "OPTIONS"), cx, y0 + 3 * step, w, h, false, en);
        drawBtn(c, B_EXIT, tr("SALIR", "EXIT"), cx, y0 + 4 * step, w, h, false, en);

        if (confirmNew) {
            c.drawColor(0xAA000000);
            float pw = sh * 1.5f, ph = sh * 0.56f;
            btnRect.set(sw / 2f - pw / 2f, sh / 2f - ph / 2f, sw / 2f + pw / 2f, sh / 2f + ph / 2f);
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(0xFF15181A);
            c.drawRoundRect(btnRect, sh * 0.03f, sh * 0.03f, fillPaint);
            strokePaint.setStrokeWidth(sh * 0.005f);
            strokePaint.setColor(0xFFDDE8C0);
            c.drawRoundRect(btnRect, sh * 0.03f, sh * 0.03f, strokePaint);
            drawFit(c, tr("¿Empezar una nueva partida?", "Start a new game?"),
                    sw / 2f, sh * 0.42f, sh * 0.05f, pw * 0.9f, Color.WHITE);
            drawFit(c, tr("Se borrará tu progreso de noches.", "Your night progress will be erased."),
                    sw / 2f, sh * 0.50f, sh * 0.035f, pw * 0.9f, 0xFFB0B0B0);
            drawBtn(c, B_YES, tr("SÍ", "YES"), sw / 2f - sh * 0.30f, sh * 0.62f, sh * 0.5f, sh * 0.11f, false, true);
            drawBtn(c, B_NO, "NO", sw / 2f + sh * 0.30f, sh * 0.62f, sh * 0.5f, sh * 0.11f, true, true);
        }
    }

    private void drawSelectScreen(Canvas c) {
        drawScreenTitle(c, tr("SELECCIONAR NOCHE", "SELECT NIGHT"));
        float w = sw * 0.17f, h = sh * 0.15f;
        for (int n = 1; n <= Settings.NIGHTS; n++) {
            int row = n <= 4 ? 0 : 1;
            int col = row == 0 ? n - 1 : n - 5;
            float off = row == 0 ? col - 1.5f : col - 1f;
            float cx = sw * (0.5f + off * 0.20f);
            float cy = sh * (row == 0 ? 0.38f : 0.60f);
            boolean unlocked = n <= cfg.unlocked;
            drawBtn(c, B_NIGHT + n, tr("NOCHE ", "NIGHT ") + n, cx, cy, w, h, n == cfg.current, unlocked);
            if (!unlocked) drawLock(c, cx + w * 0.5f - h * 0.30f, cy - h * 0.12f, h * 0.30f);
        }
        drawBtn(c, B_BACK, tr("ATRÁS", "BACK"), sw / 2f, sh * 0.85f, sh * 0.6f, sh * 0.105f, false, true);
    }

    private void drawOptionsScreen(Canvas c) {
        drawScreenTitle(c, tr("OPCIONES", "OPTIONS"));
        float lx = sw * 0.07f;
        float bw = sw * 0.145f, gap = sw * 0.008f, bh = sh * 0.10f;
        float bx0 = sw * 0.34f;

        // Dificultad
        float y = sh * 0.32f;
        drawLeft(c, tr("Dificultad", "Difficulty"), lx, y + sh * 0.015f, sh * 0.045f, Color.WHITE);
        String[] dn = {tr("FÁCIL", "EASY"), "NORMAL", tr("DIFÍCIL", "HARD"), tr("EXTREMO", "EXTREME")};
        for (int i = 0; i < 4; i++) {
            drawBtn(c, B_DIFF + i, dn[i], bx0 + bw / 2f + i * (bw + gap), y, bw, bh,
                    cfg.difficulty == i, true);
        }

        // Idioma
        y = sh * 0.48f;
        drawLeft(c, tr("Idioma", "Language"), lx, y + sh * 0.015f, sh * 0.045f, Color.WHITE);
        drawBtn(c, B_LANG, "ESPAÑOL", bx0 + bw / 2f, y, bw, bh, cfg.lang == 0, true);
        drawBtn(c, B_LANG + 1, "ENGLISH", bx0 + bw / 2f + (bw + gap), y, bw, bh, cfg.lang == 1, true);

        // Sonido y botones
        y = sh * 0.66f;
        drawBtn(c, B_SOUND, tr("SONIDO", "SOUND"), sw * 0.32f, y, sw * 0.28f, bh, false, true);
        drawBtn(c, B_LAYOUT, tr("BOTONES", "BUTTONS"), sw * 0.68f, y, sw * 0.28f, bh, false, true);

        drawBtn(c, B_BACK, tr("ATRÁS", "BACK"), sw / 2f, sh * 0.85f, sh * 0.6f, sh * 0.105f, false, true);
    }

    private void drawSlider(Canvas c, int id, String label, float value, float y) {
        float l = trackL(), r = trackR();
        drawLeft(c, label, sw * 0.07f, y + sh * 0.015f, sh * 0.042f, Color.WHITE);
        float th = sh * 0.014f;
        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setColor(0x66FFFFFF);
        btnRect.set(l, y - th / 2f, r, y + th / 2f);
        c.drawRoundRect(btnRect, th / 2f, th / 2f, fillPaint);
        float tx = l + (r - l) * value;
        fillPaint.setColor(0xFF7FB86B);
        btnRect.set(l, y - th / 2f, tx, y + th / 2f);
        c.drawRoundRect(btnRect, th / 2f, th / 2f, fillPaint);
        fillPaint.setColor(id == sliderId ? 0xFFEED17A : 0xFFDDE8C0);
        c.drawCircle(tx, y, sh * 0.032f, fillPaint);
        drawLeft(c, Math.round(value * 100f) + "%", r + sh * 0.06f, y + sh * 0.015f, sh * 0.04f, 0xFFB0B0B0);
        ui(id, l - sh * 0.04f, y - sh * 0.07f, r + sh * 0.04f, y + sh * 0.07f);
    }

    private void drawSoundScreen(Canvas c) {
        drawScreenTitle(c, tr("SONIDO", "SOUND"));
        drawSlider(c, B_SL_MUSIC, tr("Música / ambiente", "Music / ambience"), cfg.musicVol, sh * 0.38f);
        drawSlider(c, B_SL_SFX, tr("Efectos", "Effects"), cfg.sfxVol, sh * 0.56f);
        drawBtn(c, B_BACK, tr("ATRÁS", "BACK"), sw / 2f, sh * 0.85f, sh * 0.6f, sh * 0.105f, false, true);
    }

    private void drawLayoutScreen(Canvas c) {
        drawClock(c);
        drawBattery(c, 100);
        drawControls(c, true);

        textPaint.setShadowLayer(6f, 0f, 0f, Color.BLACK);
        drawCentered(c, tr("Arrastra los botones para moverlos", "Drag the buttons to move them"),
                sw / 2f, sh * 0.09f, sh * 0.04f, Color.WHITE);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);

        // Tamaño del botón seleccionado
        String[] names = {tr("LUZ", "LIGHT"), tr("TECHO", "CEIL"), tr("PARED", "WALL")};
        float rowY = sh * 0.20f, bs = sh * 0.10f;
        drawBtn(c, B_L_MINUS, "-", sw / 2f - sh * 0.36f, rowY, bs, bs, false, true);
        drawBtn(c, B_L_PLUS, "+", sw / 2f + sh * 0.36f, rowY, bs, bs, false, true);
        textPaint.setShadowLayer(6f, 0f, 0f, Color.BLACK);
        drawFit(c, tr("Tamaño ", "Size ") + names[selCtl] + ": " + Math.round(cfg.cs[selCtl] * 100f) + "%",
                sw / 2f, rowY + sh * 0.015f, sh * 0.04f, sh * 0.55f, 0xFFEED17A);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);

        drawBtn(c, B_L_RESET, tr("RESTABLECER", "RESET"), sw / 2f - sh * 0.30f, sh * 0.34f, sh * 0.54f, sh * 0.10f, false, true);
        drawBtn(c, B_L_DONE, tr("LISTO", "DONE"), sw / 2f + sh * 0.30f, sh * 0.34f, sh * 0.54f, sh * 0.10f, true, true);
    }
}
