# Jurassic Experience – v0.2
Juego nativo Android (Java + Canvas). Sin internet, sin WebView.
(El paquete sigue siendo `com.nocheraptor.game` y la clave `keystore.jks` es la misma, así que se instala encima de la versión anterior.)

## Cómo se juega
- Arrastra para mover la cámara. Mantén **LUZ** sobre el raptor de la puerta (izquierda) para echarlo.
- **Trampillas** (techo y pared derecha): se abren/cierran cuando quieras con sus botones (TECHO / PARED) o tocando la rejilla.
  Cuando el raptor se acerca por una trampilla se oyen rasguños y se ve una **luz brillante entre las rendijas**.
  Si llega con la trampilla abierta, te atrapa; si está cerrada, golpea y se va.
- **Energía** (esquina inferior izquierda): la luz y cada trampilla cerrada gastan batería, además de un gasto base que sube cada noche.
  Si llega a 0% se va la luz, las trampillas se abren y el raptor viene a por ti.
- **7 noches**. Cada noche y cada hora es más difícil. En las noches 1-3 el raptor da unos segundos extra (+3 s en la puerta, +2 s en las trampillas).

## Menú
Continuar · Nueva partida · Seleccionar noche (solo las desbloqueadas) · Opciones · Salir.
Opciones: dificultad (fácil / normal / difícil / extremo), idioma (español / English), sonido (música y efectos) y botones (mover y cambiar tamaño).
El progreso (noche desbloqueada, noche actual, opciones y posición de botones) se guarda automáticamente.

## Ajustes rápidos (inicio de GameView.java)
Duración de la hora, gasto de energía (`BASE_DRAIN`, `HATCH_DRAIN`, `LIGHT_DRAIN`), tablas de dificultad (`D_*`), bonus de las primeras noches (`EASY_*`).

## Archivos
- `GameView.java`: juego y menús. `Settings.java`: guardado de progreso y opciones.
- Imágenes en `app/src/main/assets/img`, sonidos en `app/src/main/assets/sounds`.
- Icono: `res/mipmap-*` (adaptativo para Android 8+, a sangre, sin bordes).
