/* MiFlix · utilidades de cifrado (Web Crypto). Compartido por index.html y room.html */
(function(){
const enc=new TextEncoder(),dec=new TextDecoder();
const b64=u8=>{let s='';const c=0x8000;for(let i=0;i<u8.length;i+=c)s+=String.fromCharCode.apply(null,u8.subarray(i,i+c));return btoa(s)};
const unb64=s=>{const b=atob(s),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u};
const rand=n=>crypto.getRandomValues(new Uint8Array(n));
const norm=s=>String(s||'').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ');

/* ---- clave a partir de un secreto (contraseña, o código+respuesta) ---- */
async function derive(secret,salt){
  const k=await crypto.subtle.importKey('raw',enc.encode(secret),'PBKDF2',false,['deriveKey']);
  return crypto.subtle.deriveKey({name:'PBKDF2',salt:salt,iterations:200000,hash:'SHA-256'},k,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
async function encObj(key,obj){
  const iv=rand(12);
  const ct=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:iv},key,enc.encode(JSON.stringify(obj))));
  return {iv:b64(iv),ct:b64(ct)};
}
async function decObj(key,d){
  const pt=await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(d.iv)},key,unb64(d.ct));
  return JSON.parse(dec.decode(pt));
}

/* ---- código de recuperación ---- */
function newCode(){
  const A='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',r=rand(20);
  let s='';for(let i=0;i<20;i++){s+=A[r[i]%32];if(i%4===3&&i<19)s+='-'}
  return s;
}
const codeSecret=(code,ans)=>String(code||'').replace(/[^A-Za-z0-9]/g,'').toUpperCase()+'|'+norm(ans);

/* ---- identidad (par de claves ECDH) para chats privados cifrados ---- */
const PK=u=>'mf_priv_'+u;
function localPriv(u){try{return localStorage.getItem(PK(u))}catch(e){return null}}
function saveLocal(u,jwk){try{localStorage.setItem(PK(u),jwk)}catch(e){}}
async function genIdentity(){
  const kp=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveKey']);
  return {pub:JSON.stringify(await crypto.subtle.exportKey('jwk',kp.publicKey)),
          priv:JSON.stringify(await crypto.subtle.exportKey('jwk',kp.privateKey))};
}
async function wrapBackup(fs,uid,pw,priv){
  const salt=rand(16),w=await encObj(await derive(pw,salt),{priv:priv});
  w.salt=b64(salt);
  await fs.doc('secrets/'+uid).set({pkw:w});
}
/* Deja lista la clave privada en este dispositivo (la recupera de la copia protegida con tu contraseña si hace falta) */
async function ensureIdentity(fs,uid,pw){
  const meRef=fs.doc('users/'+uid),sRef=fs.doc('secrets/'+uid);
  const me=(await meRef.get()).data()||{};
  let priv=localPriv(uid),bk=null;
  try{const s=await sRef.get();if(s.exists)bk=s.data().pkw||null}catch(e){}
  if(!priv&&bk&&pw){
    try{const o=await decObj(await derive(pw,unb64(bk.salt)),bk);priv=o.priv;saveLocal(uid,priv)}catch(e){}
  }
  if(!priv){
    const id=await genIdentity();priv=id.priv;saveLocal(uid,priv);
    await meRef.set({pub:id.pub,updatedAt:Date.now()},{merge:true});
    if(pw)await wrapBackup(fs,uid,pw,priv);
    return priv;
  }
  if(!me.pub){
    const j=JSON.parse(priv);
    await meRef.set({pub:JSON.stringify({kty:j.kty,crv:j.crv,x:j.x,y:j.y,ext:true,key_ops:[]}),updatedAt:Date.now()},{merge:true});
  }
  if(!bk&&pw)await wrapBackup(fs,uid,pw,priv);
  return priv;
}

/* ---- cifrado de mensajes privados (ECDH + AES-GCM, de extremo a extremo) ---- */
const cache={};
async function shared(myUid,theirPub){
  const ck=myUid+'|'+theirPub;if(cache[ck])return cache[ck];
  const priv=localPriv(myUid);if(!priv||!theirPub)throw new Error('nokey');
  const mine=await crypto.subtle.importKey('jwk',JSON.parse(priv),{name:'ECDH',namedCurve:'P-256'},false,['deriveKey']);
  const theirs=await crypto.subtle.importKey('jwk',JSON.parse(theirPub),{name:'ECDH',namedCurve:'P-256'},false,[]);
  return cache[ck]=await crypto.subtle.deriveKey({name:'ECDH',public:theirs},mine,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
async function encText(myUid,theirPub,text){
  const k=await shared(myUid,theirPub),iv=rand(12);
  const ct=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:iv},k,enc.encode(text)));
  return 'e1:'+b64(iv)+':'+b64(ct);
}
const LOCK='🔒 Mensaje cifrado (no se puede leer en este dispositivo)';
async function decText(myUid,theirPub,t){
  if(typeof t!=='string'||t.indexOf('e1:')!==0)return t; // mensajes antiguos sin cifrar
  try{
    const p=t.split(':'),k=await shared(myUid,theirPub);
    return dec.decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(p[1])},k,unb64(p[2])));
  }catch(e){return LOCK}
}

window.MF={b64,unb64,rand,norm,derive,encObj,decObj,newCode,codeSecret,localPriv,saveLocal,genIdentity,wrapBackup,ensureIdentity,encText,decText,LOCK};
})();
