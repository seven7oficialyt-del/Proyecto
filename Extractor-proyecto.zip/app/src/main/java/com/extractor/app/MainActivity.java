package com.extractor.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    static class Item {
        String label, pkg, ver;
        ApplicationInfo ai;
        long size, obb;
        boolean system, splits;
        Drawable icon;
    }

    final List<Item> all = new ArrayList<>();
    final List<Item> shown = new ArrayList<>();
    boolean showSystem = false;
    String query = "";
    TextView status, toggle, banner;
    BaseAdapter adapter;
    float d;

    int dp(int v) { return (int) (v * d + .5f); }

    TextView tv(String t, int color, int sp, boolean bold) {
        TextView x = new TextView(this);
        x.setText(t);
        x.setTextColor(color);
        x.setTextSize(sp);
        if (bold) x.setTypeface(Typeface.DEFAULT_BOLD);
        return x;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#14161A"));
        root.setPadding(dp(16), dp(40), dp(16), dp(8));

        root.addView(tv("Extractor de APK", Color.WHITE, 24, true));
        status = tv("Cargando apps...", Color.parseColor("#8A9099"), 13, false);
        root.addView(status);
        toggle = tv("", Color.parseColor("#7FD1A8"), 12, false);
        toggle.setPadding(0, dp(4), 0, dp(8));
        toggle.setOnClickListener(v -> { showSystem = !showSystem; applyFilter(); });
        root.addView(toggle);

        banner = tv("Falta el permiso de 'Acceso a todos los archivos' para incluir los OBB. Toca aqui para darlo.",
                Color.parseColor("#F4B740"), 12, false);
        banner.setPadding(dp(10), dp(8), dp(10), dp(8));
        banner.setOnClickListener(v -> startActivity(new Intent(
                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:" + getPackageName()))));
        root.addView(banner);

        EditText search = new EditText(this);
        search.setHint("Buscar por nombre o paquete");
        search.setHintTextColor(Color.parseColor("#6B7280"));
        search.setTextColor(Color.WHITE);
        search.setSingleLine(true);
        search.setBackground(bg("#262A31", 10));
        search.setPadding(dp(12), dp(10), dp(12), dp(10));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int e) {}
            public void onTextChanged(CharSequence s, int a, int c, int e) {}
            public void afterTextChanged(Editable s) {
                query = s.toString().trim().toLowerCase(Locale.ROOT);
                applyFilter();
            }
        });
        root.addView(search);

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(dp(8));
        list.setPadding(0, dp(10), 0, 0);
        list.setClipToPadding(false);
        adapter = new BaseAdapter() {
            public int getCount() { return shown.size(); }
            public Object getItem(int i) { return shown.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View cv, ViewGroup p) { return row(shown.get(i)); }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> export(shown.get(pos)));
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        banner.setVisibility(Environment.isExternalStorageManager() ? View.GONE : View.VISIBLE);
        load();
    }

    GradientDrawable bg(String color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(color));
        g.setCornerRadius(dp(radius));
        return g;
    }

    String mb(long n) {
        return n >= 1073741824L
                ? String.format(Locale.US, "%.2f GB", n / 1073741824.0)
                : String.format(Locale.US, "%.1f MB", n / 1048576.0);
    }

    View row(Item it) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(16);
        r.setBackground(bg("#1E2127", 12));
        r.setPadding(dp(12), dp(10), dp(12), dp(10));
        ImageView ic = new ImageView(this);
        ic.setImageDrawable(it.icon);
        r.addView(ic, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), 0, 0, 0);
        col.addView(tv(it.label, Color.WHITE, 15, true));
        col.addView(tv(it.pkg, Color.parseColor("#8A9099"), 11, false));
        String info = mb(it.size) + (it.splits ? "  ·  splits" : "") + (it.system ? "  ·  sistema" : "");
        col.addView(tv(info, Color.parseColor("#7FD1A8"), 11, false));
        if (it.obb > 0) col.addView(tv("+ OBB " + mb(it.obb), Color.parseColor("#F4B740"), 11, true));
        r.addView(col);
        return r;
    }

    void applyFilter() {
        shown.clear();
        for (Item it : all) {
            if (!showSystem && it.system) continue;
            if (!query.isEmpty() && !it.label.toLowerCase(Locale.ROOT).contains(query)
                    && !it.pkg.toLowerCase(Locale.ROOT).contains(query)) continue;
            shown.add(it);
        }
        status.setText(shown.size() + " apps  ·  toca una para guardar su APK en Descargas");
        toggle.setText(showSystem
                ? "Mostrando: todas las apps (toca para ocultar las del sistema)"
                : "Mostrando: apps instaladas por ti (toca para incluir apps del sistema)");
        adapter.notifyDataSetChanged();
    }

    void load() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            List<Item> r = new ArrayList<>();
            for (PackageInfo pi : pm.getInstalledPackages(0)) {
                ApplicationInfo ai = pi.applicationInfo;
                if (ai == null) continue;
                Item it = new Item();
                it.ai = ai;
                it.pkg = pi.packageName;
                it.label = String.valueOf(pm.getApplicationLabel(ai));
                it.ver = pi.versionName == null ? "" : pi.versionName;
                it.system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                        && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                it.size = new File(ai.sourceDir).length();
                it.splits = ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0;
                if (it.splits) for (String s : ai.splitSourceDirs) it.size += new File(s).length();
                File[] fs = obbDir(it.pkg).listFiles();
                if (fs != null) for (File f : fs) if (f.isFile()) it.obb += f.length();
                it.icon = pm.getApplicationIcon(ai);
                r.add(it);
            }
            Collections.sort(r, (a, c) -> a.label.compareToIgnoreCase(c.label));
            runOnUiThread(() -> { all.clear(); all.addAll(r); applyFilter(); });
        }).start();
    }

    File obbDir(String pkg) {
        return new File(Environment.getExternalStorageDirectory(), "Android/obb/" + pkg);
    }

    void export(final Item it) {
        Toast.makeText(this, "Guardando " + it.label + "...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String msg;
            try {
                File[] obbs = obbDir(it.pkg).listFiles();
                List<File> obbFiles = new ArrayList<>();
                if (obbs != null) for (File f : obbs) if (f.isFile()) obbFiles.add(f);

                String ext = !obbFiles.isEmpty() ? ".zip" : (it.splits ? ".apks" : ".apk");
                String mime = ext.equals(".apk") ? "application/vnd.android.package-archive" : "application/zip";
                String name = (it.label + "_" + it.ver).replaceAll("[^A-Za-z0-9._-]+", "_") + ext;

                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/APKs");
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) throw new Exception("No se pudo crear el archivo");
                OutputStream os = getContentResolver().openOutputStream(u);

                if (ext.equals(".apk")) {
                    copy(new File(it.ai.sourceDir), os);
                    os.close();
                } else {
                    ZipOutputStream z = new ZipOutputStream(os);
                    z.setLevel(0);
                    zipAdd(z, new File(it.ai.sourceDir), "base.apk");
                    if (it.splits) for (String s : it.ai.splitSourceDirs) zipAdd(z, new File(s), new File(s).getName());
                    for (File f : obbFiles) zipAdd(z, f, "Android/obb/" + it.pkg + "/" + f.getName());
                    z.close();
                }
                msg = "Guardado en Descargas: APKs/" + name;
                if (obbFiles.isEmpty() && it.obb == 0 && !Environment.isExternalStorageManager())
                    msg += " (sin OBB: falta el permiso de archivos)";
            } catch (Exception e) {
                msg = "Error: " + e.getMessage();
            }
            final String m = msg;
            runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show());
        }).start();
    }

    void copy(File f, OutputStream out) throws Exception {
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    void zipAdd(ZipOutputStream z, File f, String name) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        copy(f, z);
        z.closeEntry();
    }
}
