package com.miflix.app

import android.net.Uri
import androidx.media3.common.MimeTypes
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Obtiene la dirección reproducible de un video de YouTube para el reproductor nativo.
 *
 * Usa la misma API interna que usan las apps oficiales (InnerTube), probando varios "clientes" en orden.
 * OJO: YouTube cambia esto de vez en cuando. Si un día deja de funcionar, lo normal es que solo haya
 * que subir los números de versión de la lista CLIENTS de abajo.
 */
object YouTube {
    class Result(val url: String, val mime: String?, val audioUrl: String?, val ua: String)

    private class Client(
        val name: String,
        val id: String,
        val version: String,
        val ua: String,
        val extra: (JSONObject) -> Unit
    )

    // ---- Versiones de los clientes (actualizar aquí si YouTube las rechaza) ----
    private val CLIENTS = listOf(
        // iPhone: entrega lista HLS (calidad automática) sin necesitar token especial
        Client("IOS", "5", "19.45.4", "com.google.ios.youtube/19.45.4 (iPhone16,2; U; CPU iOS 18_1_0 like Mac OS X;)") {
            it.put("deviceMake", "Apple"); it.put("deviceModel", "iPhone16,2")
            it.put("osName", "iPhone"); it.put("osVersion", "18.1.0.22B83")
        },
        // Realidad virtual: suele dar enlaces directos
        Client(
            "ANDROID_VR", "28", "1.60.19",
            "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
        ) {
            it.put("deviceMake", "Oculus"); it.put("deviceModel", "Quest 3")
            it.put("osName", "Android"); it.put("osVersion", "12L"); it.put("androidSdkVersion", 32)
        },
        Client("ANDROID", "3", "19.44.38", "com.google.android.youtube/19.44.38 (Linux; U; Android 14) gzip") {
            it.put("osName", "Android"); it.put("osVersion", "14"); it.put("androidSdkVersion", 34)
        }
    )

    private val ID_RE = Regex("^[A-Za-z0-9_-]{11}$")

    /** Saca el ID de un enlace de YouTube (watch, youtu.be, shorts, embed, live). null si no es de YouTube */
    fun idOf(u: Uri): String? {
        val host = (u.host ?: "").lowercase().removePrefix("www.").removePrefix("m.")
        val segs = u.pathSegments ?: emptyList()
        val id = when (host) {
            "youtu.be" -> segs.firstOrNull()
            "youtube.com", "music.youtube.com", "youtube-nocookie.com" -> when {
                u.path == "/watch" -> u.getQueryParameter("v")
                segs.firstOrNull() in listOf("shorts", "embed", "live", "v") -> segs.getOrNull(1)
                else -> null
            }
            else -> null
        }
        return id?.takeIf { ID_RE.matches(it) }
    }

    /** Se llama fuera del hilo principal. Devuelve null si ningún cliente pudo dar el video */
    fun resolve(videoId: String): Result? {
        for (c in CLIENTS) {
            try {
                val j = player(c, videoId) ?: continue
                if (j.optJSONObject("playabilityStatus")?.optString("status") != "OK") continue
                val sd = j.optJSONObject("streamingData") ?: continue
                val r = pick(sd, c) ?: continue
                return r
            } catch (e: Exception) {
            }
        }
        return null
    }

    private fun pick(sd: JSONObject, c: Client): Result? {
        // 1) Lista HLS: calidad automática y menú de calidad
        val hls = sd.optString("hlsManifestUrl")
        if (hls.isNotEmpty()) return Result(hls, MimeTypes.APPLICATION_M3U8, null, c.ua)

        // 2) Video con audio incluido (el de más calidad)
        val muxed = list(sd.optJSONArray("formats"))
            .filter { it.optString("url").isNotEmpty() && it.optString("mimeType").startsWith("video/mp4") }
            .maxByOrNull { it.optInt("height") }
        if (muxed != null) return Result(muxed.getString("url"), null, null, c.ua)

        // 3) Video y audio por separado (se unen en el reproductor)
        val ad = list(sd.optJSONArray("adaptiveFormats"))
        val video = ad.filter {
            val mt = it.optString("mimeType")
            it.optString("url").isNotEmpty() && mt.startsWith("video/mp4") && mt.contains("avc1") && it.optInt("height") in 1..1080
        }.maxWithOrNull(compareBy<JSONObject>({ it.optInt("height") }, { it.optInt("bitrate") }))
        val audio = ad.filter {
            it.optString("url").isNotEmpty() && it.optString("mimeType").startsWith("audio/mp4")
        }.maxByOrNull { it.optInt("bitrate") }
        if (video != null && audio != null) return Result(video.getString("url"), null, audio.getString("url"), c.ua)
        return null
    }

    private fun list(a: JSONArray?): List<JSONObject> =
        if (a == null) emptyList() else (0 until a.length()).mapNotNull { a.optJSONObject(it) }

    private fun player(c: Client, videoId: String): JSONObject? {
        val client = JSONObject()
            .put("clientName", c.name).put("clientVersion", c.version)
            .put("hl", "es").put("gl", "US")
        c.extra(client)
        val body = JSONObject()
            .put("videoId", videoId)
            .put("contentCheckOk", true).put("racyCheckOk", true)
            .put("context", JSONObject().put("client", client))
        val cn = URL("https://www.youtube.com/youtubei/v1/player?prettyPrint=false").openConnection() as HttpURLConnection
        try {
            cn.requestMethod = "POST"
            cn.connectTimeout = 8000
            cn.readTimeout = 10000
            cn.doOutput = true
            cn.setRequestProperty("Content-Type", "application/json")
            cn.setRequestProperty("User-Agent", c.ua)
            cn.setRequestProperty("X-YouTube-Client-Name", c.id)
            cn.setRequestProperty("X-YouTube-Client-Version", c.version)
            cn.setRequestProperty("Origin", "https://www.youtube.com")
            cn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (cn.responseCode != 200) return null
            return JSONObject(cn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
        } finally {
            cn.disconnect()
        }
    }
}
