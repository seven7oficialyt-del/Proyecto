package com.miflix.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.webkit.JavascriptInterface
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayInputStream

class PlayerActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var baseSite = ""
    private var pageUrl = ""
    private var found = false
    private var overlay: LinearLayout? = null
    private var pageBtn: Button? = null
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        private val ADS = listOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "popads.net", "popcash.net", "propellerads.com", "adsterra.com", "exoclick.com", "exosrv.com",
            "juicyads.com", "trafficjunky.com", "adnxs.com", "taboola.com", "outbrain.com", "onclickads.net",
            "onclkds.com", "clickadu.com", "hilltopads.net", "mgid.com", "revcontent.com", "adcash.com",
            "a-ads.com", "admaven.com", "ad-maven.com", "adsco.re", "pubfuture.com", "richads.com",
            "trafficstars.com", "adskeeper.com", "yllix.com", "bidvertiser.com", "clickaine.com"
        )
        private val CLEAN = """(function(){try{var s=document.createElement('style');s.textContent='ins.adsbygoogle,[id^="google_ads"],.adsbox,.ad-banner{display:none!important}';(document.head||document.documentElement).appendChild(s)}catch(e){}window.open=function(){return null}})();"""

        /** Busca el <video> de la página, intenta darle play y avisa de su dirección real a la app */
        private val SNIFF = """(function(){if(window.__mf)return;window.__mf=1;function rep(u){try{if(u&&/^https?:/i.test(u))MiFlix.stream(u)}catch(e){}}function scan(){var v=document.querySelectorAll('video');for(var i=0;i<v.length;i++){var x=v[i],s=x.currentSrc||x.src;if(s&&s.indexOf('blob:')!==0){rep(s)}else{try{x.muted=true;var p=x.play();if(p&&p.catch)p.catch(function(){})}catch(e){}}}var b=document.querySelector('.vjs-big-play-button,.jw-icon-display,.plyr__control--overlaid,.play-button,[class*="play-btn"],[class*="PlayButton"]');if(b){try{b.click()}catch(e){}}}setInterval(scan,1000)})();"""

        private val STREAM_EXT = listOf(".m3u8", ".mpd", ".mp4", ".webm", ".mkv", ".m4v", ".mov")
        private val NOT_MAIN = listOf("/ads/", "/ad/", "preroll", "banner", "sprite", "thumb", "preview", "teaser")

        /** true si la petición parece ser el video (o su lista de reproducción) */
        fun isStream(u: Uri): Boolean {
            val full = u.toString().lowercase()
            val path = (u.path ?: "").lowercase()
            if (NOT_MAIN.any { full.contains(it) }) return false
            return STREAM_EXT.any { path.endsWith(it) } || full.contains(".m3u8") || full.contains(".mpd?")
        }

        fun isAd(host: String?): Boolean =
            host != null && ADS.any { host == it || host.endsWith(".$it") }

        fun site(host: String): String {
            val p = host.split(".")
            return if (p.size >= 2) p.takeLast(2).joinToString(".") else host
        }
    }

    private val chrome = object : WebChromeClient() {
        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (customView != null) {
                callback.onCustomViewHidden()
                return
            }
            customView = view
            customCb = callback
            root.addView(view, FrameLayout.LayoutParams(-1, -1))
            web.visibility = View.GONE
            immersive(true)
        }

        override fun onHideCustomView() {
            customView?.let { root.removeView(it) }
            customView = null
            customCb?.onCustomViewHidden()
            customCb = null
            web.visibility = View.VISIBLE
            immersive(false)
        }
    }

    private fun immersive(on: Boolean) { goFullscreen() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        goFullscreen()
        val url = intent.getStringExtra("url")
        if (url == null) {
            finish()
            return
        }
        baseSite = site(Uri.parse(url).host ?: "")
        root = FrameLayout(this)
        root.setBackgroundColor(0xFF000000.toInt())
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        // Pantalla negra con "cargando" que TAPA la página web mientras se busca el video
        val ov = LinearLayout(this)
        ov.orientation = LinearLayout.VERTICAL
        ov.gravity = Gravity.CENTER
        ov.setBackgroundColor(Color.BLACK)
        ov.isClickable = true
        ov.addView(ProgressBar(this))
        val msg = TextView(this)
        msg.text = "Cargando video…"
        msg.setTextColor(Color.WHITE)
        msg.textSize = 15f
        msg.gravity = Gravity.CENTER
        msg.setPadding(0, 32, 0, 0)
        ov.addView(msg)
        val pb = Button(this)
        pb.text = "Ver página"
        pb.visibility = View.GONE
        pb.setOnClickListener { ov.visibility = View.GONE }
        ov.addView(pb)
        root.addView(ov, FrameLayout.LayoutParams(-1, -1))
        overlay = ov
        pageBtn = pb
        // Solo si tarda mucho (p. ej. la página exige un toque) se ofrece mostrar la página
        handler.postDelayed({ if (!found) pageBtn?.visibility = View.VISIBLE }, 12_000)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(false)
        s.userAgentString = s.userAgentString.replace("; wv", "")

        web.addJavascriptInterface(object {
            @JavascriptInterface
            fun stream(u: String) {
                if (!found) onStreamFound(u, null)
            }
        }, "MiFlix")
        web.webChromeClient = chrome
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (isAd(request.url.host))
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                if (!found && isStream(request.url)) onStreamFound(request.url.toString(), request.requestHeaders)
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val h = request.url.host ?: return true
                return isAd(h) || site(h) != baseSite
            }

            override fun onPageStarted(view: WebView, u: String?, favicon: android.graphics.Bitmap?) {
                if (u != null) pageUrl = u
                view.evaluateJavascript(CLEAN, null)
            }

            override fun onPageFinished(view: WebView, u: String?) {
                view.evaluateJavascript(CLEAN, null)
                view.evaluateJavascript(SNIFF, null)
            }
        }
        pageUrl = url
        web.loadUrl(url)
    }

    /** Se llama desde el hilo de red del WebView: abre el reproductor nativo con el link encontrado */
    private fun onStreamFound(streamUrl: String, headers: Map<String, String>?) {
        synchronized(this) {
            if (found) return
            found = true
        }
        val referer = headers?.get("Referer") ?: headers?.get("referer") ?: pageUrl
        val origin = try {
            val r = Uri.parse(referer)
            if (r.scheme != null && r.host != null) "${r.scheme}://${r.host}" else ""
        } catch (e: Exception) { "" }
        runOnUiThread {
            val cookie = CookieManager.getInstance().getCookie(streamUrl) ?: ""
            web.loadUrl("about:blank")
            web.onPause()
            startActivityForResult(
                Intent(this, VideoActivity::class.java)
                    .putExtra("url", streamUrl)
                    .putExtra("referer", referer)
                    .putExtra("origin", origin)
                    .putExtra("cookie", cookie)
                    .putExtra("ua", web.settings.userAgentString), 2
            )
            overridePendingTransition(0, 0)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2) finish() // al cerrar el reproductor, volvemos directo al catálogo
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goFullscreen()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> chrome.onHideCustomView()
            overlay?.visibility == View.VISIBLE -> finish()
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (!found) web.onResume()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }
}
