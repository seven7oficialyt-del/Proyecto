package com.miflix.app

import android.annotation.SuppressLint
import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import java.io.ByteArrayInputStream

class PlayerActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var baseSite = ""

    companion object {
        private val ADS = listOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "popads.net", "popcash.net", "propellerads.com", "adsterra.com", "exoclick.com", "exosrv.com",
            "juicyads.com", "trafficjunky.com", "adnxs.com", "taboola.com", "outbrain.com", "onclickads.net",
            "onclkds.com", "clickadu.com", "hilltopads.net", "mgid.com", "revcontent.com", "adcash.com",
            "a-ads.com", "admaven.com", "ad-maven.com", "adsco.re", "pubfuture.com", "richads.com",
            "trafficstars.com", "adskeeper.com", "yllix.com", "bidvertiser.com", "clickaine.com"
        )
        private val CLEAN = """(function(){try{var s=document.createElement('style');s.textContent='ins.adsbygoogle,[id^="google_ads"],.adsbox,.ad-banner{display:none!important}';(document.head||document.documentElement).appendChild(s)}catch(e){}window.open=function(){return null}})();"""

        fun isAd(host: String?): Boolean =
            host != null && ADS.any { host == it || host.endsWith(".$it") }

        fun site(host: String): String {
            val p = host.split(".")
            return if (p.size >= 2) p.takeLast(2).joinToString(".") else host
        }
    }

    private val chrome = object : WebChromeClient() {
        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (customView != null) {
                callback.onCustomViewHidden()
                return
            }
            customView = view
            customCb = callback
            root.addView(view, FrameLayout.LayoutParams(-1, -1))
            web.visibility = View.GONE
            immersive(true)
        }

        override fun onHideCustomView() {
            customView?.let { root.removeView(it) }
            customView = null
            customCb?.onCustomViewHidden()
            customCb = null
            web.visibility = View.VISIBLE
            immersive(false)
        }
    }

    @Suppress("DEPRECATION")
    private fun immersive(on: Boolean) {
        window.decorView.systemUiVisibility = if (on) {
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        } else {
            View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url")
        if (url == null) {
            finish()
            return
        }
        baseSite = site(Uri.parse(url).host ?: "")
        root = FrameLayout(this)
        root.setBackgroundColor(0xFF000000.toInt())
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(false)
        s.userAgentString = s.userAgentString.replace("; wv", "")

        web.webChromeClient = chrome
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                if (isAd(request.url.host))
                    WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                else null

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val h = request.url.host ?: return true
                return isAd(h) || site(h) != baseSite
            }

            override fun onPageStarted(view: WebView, u: String?, favicon: android.graphics.Bitmap?) {
                view.evaluateJavascript(CLEAN, null)
            }

            override fun onPageFinished(view: WebView, u: String?) {
                view.evaluateJavascript(CLEAN, null)
            }
        }
        web.loadUrl(url)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> chrome.onHideCustomView()
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
