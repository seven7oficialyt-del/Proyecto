package com.miflix.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.GestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

class VideoActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var pv: PlayerView
    private lateinit var fitBtn: TextView
    private var modeIdx = 0

    private val modes = listOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT to "Ajustar",
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Llenar pantalla",
        AspectRatioFrameLayout.RESIZE_MODE_FILL to "Estirar"
    )

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url")
        if (url == null) {
            finish()
            return
        }
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        goFullscreen()

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        pv = PlayerView(this)
        pv.setBackgroundColor(Color.BLACK)
        pv.setShutterBackgroundColor(Color.BLACK)
        pv.setKeepContentOnPlayerReset(false)
        pv.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
        pv.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        root.addView(pv, FrameLayout.LayoutParams(-1, -1))

        // Botón para cambiar cómo se ajusta el video (Ajustar / Llenar / Estirar)
        val d = resources.displayMetrics.density
        fitBtn = TextView(this)
        fitBtn.text = modes[0].second
        fitBtn.setTextColor(Color.WHITE)
        fitBtn.textSize = 13f
        fitBtn.typeface = Typeface.DEFAULT_BOLD
        fitBtn.gravity = Gravity.CENTER
        fitBtn.setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
        fitBtn.background = GradientDrawable().apply {
            setColor(0x99000000.toInt()); cornerRadius = 20 * d
        }
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END)
        lp.setMargins(0, (16 * d).toInt(), (24 * d).toInt(), 0)
        root.addView(fitBtn, lp)
        fitBtn.setOnClickListener {
            modeIdx = (modeIdx + 1) % modes.size
            pv.resizeMode = modes[modeIdx].first
            fitBtn.text = modes[modeIdx].second
            pv.showController()
        }
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            fitBtn.visibility = if (vis == View.VISIBLE) View.VISIBLE else View.GONE
        })
        setContentView(root)

        // Cabeceras que muchos servidores exigen para entregar el video
        val headers = HashMap<String, String>()
        intent.getStringExtra("referer")?.takeIf { it.isNotBlank() }?.let { headers["Referer"] = it }
        intent.getStringExtra("origin")?.takeIf { it.isNotBlank() }?.let { headers["Origin"] = it }
        intent.getStringExtra("cookie")?.takeIf { it.isNotBlank() }?.let { headers["Cookie"] = it }
        val dsf = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(headers)
        intent.getStringExtra("ua")?.takeIf { it.isNotBlank() }?.let { dsf.setUserAgent(it) }

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsf))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        player = p
        pv.player = p
        pv.controllerShowTimeoutMs = 3000
        pv.hideController()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@VideoActivity, "No se pudo reproducir este video", Toast.LENGTH_LONG).show()
                finish()
            }
        })
        val low = url.lowercase()
        val mime = when {
            low.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
            low.contains(".mpd") -> MimeTypes.APPLICATION_MPD
            else -> null
        }
        p.setMediaItem(MediaItem.Builder().setUri(Uri.parse(url)).setMimeType(mime).build())
        p.prepare()
        p.playWhenReady = true

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val pl = player ?: return true
                val delta = if (e.x < pv.width / 2f) -10_000L else 10_000L
                val max = if (pl.duration > 0) pl.duration else Long.MAX_VALUE
                pl.seekTo((pl.currentPosition + delta).coerceIn(0L, max))
                return true
            }
        })
        pv.setOnTouchListener { _, ev -> gd.onTouchEvent(ev) }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goFullscreen()
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
