package com.miflix.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.os.Build
import androidx.media3.common.Format
import androidx.media3.common.Tracks
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.ui.CaptionStyleCompat
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import android.text.TextUtils
import android.util.Base64
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.app.AlertDialog
import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import kotlin.math.abs
import android.view.Gravity
import android.view.MotionEvent
import android.view.GestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import android.view.ViewGroup
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

class VideoActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var pv: PlayerView
    private lateinit var fitBtn: TextView
    private lateinit var btnBar: LinearLayout
    private lateinit var root: FrameLayout
    private var isPortrait = false
    private var notif: LinearLayout? = null
    private val notifHide = Runnable { notif?.visibility = View.GONE }
    private var modeIdx = 0

    // ---- Subtítulos ----
    private lateinit var ccBtn: TextView
    private var subLang = "es"            // idioma elegido al seleccionar el título ("off" = no activar solos)
    private var audLang = "en"            // idioma original del audio (para los automáticos)
    private var extSubs: List<Triple<String, String, String>> = emptyList()   // url, idioma, nombre
    private var mainUrl = ""
    private var mainMime: String? = null
    private var audioUrl: String? = null          // solo YouTube: audio aparte cuando el video no trae audio incluido
    private var ytId: String? = null
    private var dsf: DefaultHttpDataSource.Factory? = null
    private var subsOn = false
    private var autoOn = false
    private var autoWanted = false
    private var decided = false
    private var tap: AudioTap? = null
    private var auto: AutoCaptions? = null
    private var capView: TextView? = null
    private val capHide = Runnable { capView?.visibility = View.GONE }

    // ---- Ver juntos ----
    private var room: String? = null
    private var roomWeb: RoomWebView? = null
    private var pageReady = false
    private var isHost = false
    private var synced = false
    private var ignoreUntil = 0L
    private var panelOpen = false
    private var unread = 0
    private var chatPill: TextView? = null
    private var voicePill: TextView? = null
    private val hbHandler = Handler(Looper.getMainLooper())
    private val heartbeat = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && p.playWhenReady && p.playbackState == Player.STATE_READY) pushLocal(null)
            hbHandler.postDelayed(this, 15_000)
        }
    }

    private val modes = listOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT to "Ajustar",
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Llenar pantalla",
        AspectRatioFrameLayout.RESIZE_MODE_FILL to "Estirar"
    )

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url")
        if (url == null) {
            finish()
            return
        }
        ytId = intent.getStringExtra("yt")?.takeIf { it.isNotBlank() }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        goFullscreen()

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        pv = PlayerView(this)
        pv.setBackgroundColor(Color.BLACK)
        pv.setShutterBackgroundColor(Color.BLACK)
        pv.setKeepContentOnPlayerReset(false)
        pv.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
        pv.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        root.addView(pv, FrameLayout.LayoutParams(-1, -1))

        // Botones arriba a la derecha: Calidad y ajuste de pantalla (visibles junto a los controles)
        val d = resources.displayMetrics.density
        fun pill(label: String): TextView {
            val t = TextView(this)
            t.text = label
            t.setTextColor(Color.WHITE)
            t.textSize = 13f
            t.typeface = Typeface.DEFAULT_BOLD
            t.gravity = Gravity.CENTER
            t.setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            val bg = GradientDrawable()
            bg.setColor(0x99000000.toInt())
            bg.cornerRadius = 20 * d
            t.background = bg
            return t
        }
        btnBar = LinearLayout(this)
        btnBar.orientation = LinearLayout.HORIZONTAL
        room = intent.getStringExtra("room")?.takeIf { it.isNotBlank() }
        subLang = (intent.getStringExtra("sub") ?: "es").lowercase()
        audLang = (intent.getStringExtra("aud") ?: "en").lowercase()
        run {
            val su = intent.getStringArrayExtra("subUrls") ?: emptyArray()
            val sl = intent.getStringArrayExtra("subLangs") ?: emptyArray()
            val sb = intent.getStringArrayExtra("subLabels") ?: emptyArray()
            extSubs = su.mapIndexed { i, u -> Triple(u, sl.getOrNull(i) ?: "", sb.getOrNull(i) ?: "") }
        }
        val qBtn = pill("Calidad")
        ccBtn = pill("CC")
        fitBtn = pill(modes[0].second)
        val gap = LinearLayout.LayoutParams(-2, -2)
        gap.setMargins(0, 0, (8 * d).toInt(), 0)
        if (room != null) {
            btnBar.addView(pill("Sala $room"), gap)
            val cp = pill("Chat")
            cp.setOnClickListener { if (panelOpen) closePanel() else openPanel() }
            val vp = pill("Voz")
            vp.setOnClickListener { roomWeb?.evaluateJavascript("toggleVoice()", null) }
            chatPill = cp
            voicePill = vp
            btnBar.addView(cp, gap)
            btnBar.addView(vp, gap)
        }
        btnBar.addView(ccBtn, gap)
        btnBar.addView(qBtn, gap)
        btnBar.addView(fitBtn)
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END)
        lp.setMargins(0, (16 * d).toInt(), (24 * d).toInt(), 0)
        root.addView(btnBar, lp)
        qBtn.setOnClickListener { showQuality() }
        ccBtn.setOnClickListener { showSubs() }
        fitBtn.setOnClickListener {
            modeIdx = (modeIdx + 1) % modes.size
            pv.resizeMode = modes[modeIdx].first
            fitBtn.text = modes[modeIdx].second
            pv.showController()
        }
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            btnBar.visibility = if (vis == View.VISIBLE) View.VISIBLE else View.GONE
            updateNotifPos()
        })
        setContentView(root)

        // Cabeceras que muchos servidores exigen para entregar el video
        val headers = HashMap<String, String>()
        intent.getStringExtra("referer")?.takeIf { it.isNotBlank() }?.let { headers["Referer"] = it }
        intent.getStringExtra("origin")?.takeIf { it.isNotBlank() }?.let { headers["Origin"] = it }
        intent.getStringExtra("cookie")?.takeIf { it.isNotBlank() }?.let { headers["Cookie"] = it }
        val dsfLocal = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(headers)
        intent.getStringExtra("ua")?.takeIf { it.isNotBlank() }?.let { dsfLocal.setUserAgent(it) }
        dsf = dsfLocal

        // El "espía" de audio deja el sonido igual y nos da una copia para los subtítulos automáticos
        val tapLocal = AudioTap()
        tap = tapLocal
        val rf = object : DefaultRenderersFactory(this@VideoActivity) {
            override fun buildAudioRenderers(
                context: Context,
                extensionRendererMode: Int,
                mediaCodecSelector: MediaCodecSelector,
                enableDecoderFallback: Boolean,
                audioSink: AudioSink,
                eventHandler: Handler,
                eventListener: AudioRendererEventListener,
                out: ArrayList<Renderer>
            ) {
                val sink = DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf<AudioProcessor>(tapLocal))
                    .build()
                super.buildAudioRenderers(
                    context, extensionRendererMode, mediaCodecSelector,
                    enableDecoderFallback, sink, eventHandler, eventListener, out
                )
            }
        }
        val p = ExoPlayer.Builder(this, rf)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsfLocal))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        player = p
        pv.player = p
        pv.controllerShowTimeoutMs = 3000
        pv.hideController()
        p.addListener(object : Player.Listener {
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                pushLocal(null)
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                if (reason == Player.DISCONTINUITY_REASON_SEEK) {
                    auto?.clearQueue()
                    pushLocal(newPosition.positionMs)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) decideSubs()
            }

            override fun onTracksChanged(tracks: Tracks) {
                if (!decided && player?.playbackState == Player.STATE_READY) decideSubs()
            }

            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@VideoActivity, "No se pudo reproducir este video", Toast.LENGTH_LONG).show()
                finish()
            }
        })
        val low = url.lowercase()
        val mime = when {
            low.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
            low.contains(".mpd") -> MimeTypes.APPLICATION_MPD
            else -> null
        }
        mainUrl = url
        mainMime = mime
        // Los subtítulos empiezan apagados; decidimos cuál mostrar cuando el video ya cargó
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
        pv.subtitleView?.setStyle(
            CaptionStyleCompat(
                Color.WHITE, 0x00000000, 0x00000000,
                CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, Typeface.DEFAULT_BOLD
            )
        )
        // Texto de los subtítulos automáticos (encima del video, abajo y centrado)
        val cv = TextView(this)
        cv.setTextColor(Color.WHITE)
        cv.textSize = 17f
        cv.typeface = Typeface.DEFAULT_BOLD
        cv.gravity = Gravity.CENTER
        cv.setShadowLayer(4f * d, 0f, 0f, Color.BLACK)
        cv.setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
        val cbg = GradientDrawable()
        cbg.setColor(0x88000000.toInt())
        cbg.cornerRadius = 8 * d
        cv.background = cbg
        cv.visibility = View.GONE
        val clp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        clp.setMargins((24 * d).toInt(), 0, (24 * d).toInt(), (28 * d).toInt())
        (pv.overlayFrameLayout ?: root).addView(cv, clp)
        capView = cv
        updateCcBtn()
        applyLayout()
        val path = (Uri.parse(url).path ?: "").lowercase()
        val direct = listOf(".mp4", ".m4v", ".webm", ".mkv", ".mov").any { path.endsWith(it) }
        if (ytId != null) {
            // YouTube: se obtiene la dirección del video y se reproduce aquí mismo (sin subtítulos automáticos solos; CC sigue disponible)
            decided = true
            resolveYoutube(ytId!!)
        } else if (extSubs.isEmpty() && direct) {
            // Busca subtítulos "hermanos" del archivo (mismo nombre con .vtt / .srt)
            probeSidecars(url, headers) { found ->
                extSubs = found
                startPlayback()
            }
        } else {
            startPlayback()
        }

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val pl = player ?: return true
                val delta = if (e.x < pv.width / 2f) -10_000L else 10_000L
                val max = if (pl.duration > 0) pl.duration else Long.MAX_VALUE
                pl.seekTo((pl.currentPosition + delta).coerceIn(0L, max))
                return true
            }
        })
        pv.setOnTouchListener { _, ev -> gd.onTouchEvent(ev) }
    }

    /** WebView oculto que habla con Firestore (mismo inicio de sesión que la app) */
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupRoom(root: FrameLayout, code: String) {
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        val w = RoomWebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.setBackgroundColor(0xFF141414.toInt())
        w.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val ok = request.origin.host == "appassets.androidplatform.net" &&
                        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (ok) request.grant(request.resources) else request.deny()
                }
            }
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                loader.shouldInterceptRequest(request.url)
        }
        w.addJavascriptInterface(object {
            @JavascriptInterface
            fun event(type: String, json: String) {
                runOnUiThread { onRoomEvent(type, json) }
            }
        }, "NativeRoom")
        w.settings.textZoom = 100   // ignora el tamaño de letra del sistema (evita el chat gigante)
        root.addView(w, roomParams())
        w.alpha = 1f
        roomWeb = w
        w.loadUrl("https://appassets.androidplatform.net/assets/room.html?code=$code")
    }

    private fun onRoomEvent(type: String, json: String) {
        try {
            when (type) {
                "ready" -> {
                    isHost = JSONObject(json).optBoolean("host")
                    pageReady = true
                    applyLayout()
                    if (isHost) {
                        synced = true
                        pushLocal(null)
                        hbHandler.postDelayed(heartbeat, 15_000)
                    }
                }
                "state" -> applyRemote(JSONObject(json))
                "close" -> closePanel()
                "chat" -> {
                    val o = JSONObject(json)
                    val priv = o.optBoolean("priv")
                    val visible = isPortrait || panelOpen
                    if (!visible && !isPortrait) {
                        unread++
                        chatPill?.text = "Chat ($unread)"
                    }
                    // Chat cerrado (o mensaje privado en vertical): aviso arriba a la derecha
                    if (!visible || (priv && isPortrait)) {
                        showNotif(o.optString("name"), o.optString("text"), o.optString("photo"), priv)
                    }
                }
                "voice" -> {
                    val o = JSONObject(json)
                    voicePill?.text = when {
                        !o.optBoolean("on") -> "Voz"
                        o.optBoolean("muted") -> "Mic silenciado"
                        else -> "Mic activo"
                    }
                }
                "needmic" -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        roomWeb?.evaluateJavascript("startVoice()", null)
                    } else {
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
                    }
                }
                "toast" -> Toast.makeText(this, JSONObject(json).optString("m"), Toast.LENGTH_SHORT).show()
                "joined" -> Toast.makeText(this, "${JSONObject(json).optString("name")} entró a la sala", Toast.LENGTH_SHORT).show()
                "left" -> Toast.makeText(this, "${JSONObject(json).optString("name")} salió de la sala", Toast.LENGTH_SHORT).show()
                "missing" -> Toast.makeText(this, "Esa sala ya no existe", Toast.LENGTH_LONG).show()
                "error" -> Toast.makeText(this, "No se pudo conectar con la sala", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
        }
    }

    private fun openPanel() {
        val w = roomWeb ?: return
        if (isPortrait) return
        panelOpen = true
        unread = 0
        chatPill?.text = "Chat"
        notif?.visibility = View.GONE
        showMini(w)
    }

    private fun closePanel() {
        val w = roomWeb ?: return
        panelOpen = false
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(w.windowToken, 0)
        hideMini(w)
        if (!isPortrait) goFullscreen()
    }

    private fun roundOutline(r: Float) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, r)
        }
    }

    /** Tamaño y lugar de la mini ventana del chat (horizontal) */
    private fun miniParams(): FrameLayout.LayoutParams {
        val d = resources.displayMetrics.density
        val lp = FrameLayout.LayoutParams((300 * d).toInt(), (220 * d).toInt(), Gravity.TOP or Gravity.END)
        lp.setMargins(0, (56 * d).toInt(), (16 * d).toInt(), 0)
        return lp
    }

    /** Vertical: chat debajo del video, a tamaño completo */
    private fun fullParams(): FrameLayout.LayoutParams {
        val vh = resources.displayMetrics.widthPixels * 9 / 16
        val lp = FrameLayout.LayoutParams(-1, -1)
        lp.topMargin = vh
        return lp
    }

    /** El chat nace siempre con su tamaño final (si nace diminuto, la página calcula mal su escala y se ve gigante) */
    private fun roomParams(): FrameLayout.LayoutParams =
        if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) fullParams() else miniParams()

    /** Mini ventana flotante del chat (horizontal). El campo de escribir va arriba, así el teclado no lo tapa */
    private fun showMini(w: RoomWebView) {
        val d = resources.displayMetrics.density
        w.layoutParams = miniParams()
        w.outlineProvider = roundOutline(14 * d)
        w.clipToOutline = true
        w.passThrough = false
        w.alpha = 1f
        w.bringToFront()
        w.requestFocus()
    }

    /** Oculto = casi transparente y sin recibir toques (sigue "vivo" para sincronizar, chat y voz) */
    private fun hideMini(w: RoomWebView) {
        val d = resources.displayMetrics.density
        w.layoutParams = miniParams()
        w.outlineProvider = roundOutline(14 * d)
        w.clipToOutline = true
        w.alpha = 0.01f
        w.passThrough = true
        w.clearFocus()
    }

    /** Vertical: video arriba y chat siempre abajo. Horizontal: video completo y chat en mini ventana */
    @Suppress("DEPRECATION")
    private fun applyLayout() {
        val d = resources.displayMetrics.density
        val portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        isPortrait = portrait
        val blp = btnBar.layoutParams as FrameLayout.LayoutParams
        if (portrait) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            val vh = resources.displayMetrics.widthPixels * 9 / 16
            pv.layoutParams = FrameLayout.LayoutParams(-1, vh, Gravity.TOP)
            blp.setMargins(0, (8 * d).toInt(), (8 * d).toInt(), 0)
            if (room != null) {
                chatPill?.visibility = View.GONE
                fitBtn.visibility = View.GONE
            }
            panelOpen = false
            unread = 0
            chatPill?.text = "Chat"
            notif?.visibility = View.GONE
            roomWeb?.let { w ->
                w.layoutParams = fullParams()
                w.clipToOutline = false
                w.passThrough = false
                w.alpha = 1f
            }
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
            goFullscreen()
            pv.layoutParams = FrameLayout.LayoutParams(-1, -1)
            blp.setMargins(0, (16 * d).toInt(), (24 * d).toInt(), 0)
            chatPill?.visibility = View.VISIBLE
            fitBtn.visibility = View.VISIBLE
            roomWeb?.let { w -> if (panelOpen) showMini(w) else hideMini(w) }
        }
        btnBar.layoutParams = blp
        btnBar.bringToFront()
        notif?.bringToFront()
        updateNotifPos()
        roomWeb?.evaluateJavascript("setMode('${if (portrait) "full" else "mini"}')", null)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayout()
    }

    // ---- Aviso de mensaje nuevo (esquina superior derecha) ----
    private fun notifTop(): Int {
        val d = resources.displayMetrics.density
        val barShown = btnBar.visibility == View.VISIBLE
        return ((if (barShown) (if (isPortrait) 52 else 64) else (if (isPortrait) 8 else 16)) * d).toInt()
    }

    private fun updateNotifPos() {
        val n = notif ?: return
        val lp = n.layoutParams as? FrameLayout.LayoutParams ?: return
        lp.topMargin = notifTop()
        n.layoutParams = lp
    }

    private fun decodePhoto(url: String?): Bitmap? {
        if (url.isNullOrEmpty() || !url.startsWith("data:image")) return null
        return try {
            val b = Base64.decode(url.substringAfter(','), Base64.DEFAULT)
            BitmapFactory.decodeByteArray(b, 0, b.size)
        } catch (e: Exception) {
            null
        }
    }

    private fun avatarView(photo: String?, name: String): View {
        val d = resources.displayMetrics.density
        val bmp = decodePhoto(photo)
        val v: View = if (bmp != null) {
            ImageView(this).apply {
                setImageBitmap(bmp)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
        } else {
            TextView(this).apply {
                text = name.take(1).uppercase()
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                setBackgroundColor(0xFFE50914.toInt())
            }
        }
        v.layoutParams = LinearLayout.LayoutParams((38 * d).toInt(), (38 * d).toInt())
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        v.clipToOutline = true
        return v
    }

    /** Avatar + nombre + mensaje en una línea; si es largo termina en "…" y hay que abrir el chat */
    private fun showNotif(name: String, text: String, photo: String?, priv: Boolean) {
        val d = resources.displayMetrics.density
        notif?.let { root.removeView(it) }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding((10 * d).toInt(), (8 * d).toInt(), (16 * d).toInt(), (8 * d).toInt())
        val bg = GradientDrawable()
        bg.setColor(0xF0222222.toInt())
        bg.cornerRadius = 16 * d
        bg.setStroke((1 * d).toInt().coerceAtLeast(1), 0x66FFFFFF)
        box.background = bg
        box.addView(avatarView(photo, name))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding((10 * d).toInt(), 0, 0, 0)
        val n = TextView(this)
        n.text = (if (priv) "🔒 " else "") + name
        n.setTextColor(0xFFFF6B6B.toInt())
        n.textSize = 12f
        n.typeface = Typeface.DEFAULT_BOLD
        n.maxLines = 1
        n.ellipsize = TextUtils.TruncateAt.END
        n.maxWidth = (190 * d).toInt()
        val t = TextView(this)
        t.text = text.replace('\n', ' ')
        t.setTextColor(Color.WHITE)
        t.textSize = 14f
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.maxWidth = (190 * d).toInt()
        col.addView(n)
        col.addView(t)
        box.addView(col)
        box.setOnClickListener {
            hbHandler.removeCallbacks(notifHide)
            box.visibility = View.GONE
            if (!isPortrait) openPanel()
        }
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END)
        lp.setMargins(0, notifTop(), (24 * d).toInt(), 0)
        root.addView(box, lp)
        notif = box
        hbHandler.removeCallbacks(notifHide)
        hbHandler.postDelayed(notifHide, 5000)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 78) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startAuto(false)
            } else {
                Toast.makeText(this, "Sin permiso de micrófono no se pueden generar subtítulos automáticos", Toast.LENGTH_LONG).show()
            }
        }
        if (requestCode == 77) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                roomWeb?.evaluateJavascript("startVoice()", null)
            } else {
                Toast.makeText(this, "Sin permiso de micrófono no se puede hablar", Toast.LENGTH_LONG).show()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panelOpen && !isPortrait) closePanel() else super.onBackPressed()
    }

    /** Aplica play/pausa/posición que mandó el otro usuario */
    private fun applyRemote(o: JSONObject) {
        val p = player ?: return
        val playing = o.optBoolean("playing")
        val pos = o.optLong("pos")
        val at = o.optLong("at")
        val elapsed = if (playing && at > 0) (System.currentTimeMillis() - at).coerceIn(0L, 21_600_000L) else 0L
        val target = pos + elapsed
        ignoreUntil = SystemClock.elapsedRealtime() + 1500
        synced = true
        if (abs(p.currentPosition - target) > 2500) p.seekTo(target)
        if (p.playWhenReady != playing) p.playWhenReady = playing
    }

    /** Avisa a la sala de lo que hice yo (play, pausa o salto) */
    private fun pushLocal(pos: Long?) {
        val p = player ?: return
        val w = roomWeb ?: return
        if (!pageReady || !synced) return
        if (SystemClock.elapsedRealtime() < ignoreUntil) return
        val position = pos ?: p.currentPosition
        w.evaluateJavascript("pushState(${p.playWhenReady},$position)", null)
    }

    /** Menú de calidad: "Automática" + las resoluciones que ofrezca el video (HLS/DASH) */
    private fun showQuality() {
        val pl = player ?: return
        val group = pl.currentTracks.groups.firstOrNull { it.type == C.TRACK_TYPE_VIDEO && it.length > 0 }
        if (group == null) {
            Toast.makeText(this, "Cargando video…", Toast.LENGTH_SHORT).show()
            return
        }
        // una opción por resolución (la de mayor bitrate), de mayor a menor
        val opts = (0 until group.length)
            .filter { group.isTrackSupported(it) && group.getTrackFormat(it).height > 0 }
            .map { it to group.getTrackFormat(it) }
            .sortedWith(compareByDescending<Pair<Int, androidx.media3.common.Format>> { it.second.height }
                .thenByDescending { it.second.bitrate })
            .distinctBy { it.second.height }
        if (opts.size < 2) {
            Toast.makeText(this, "Este video solo tiene una calidad", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = (listOf("Automática") + opts.map { "${it.second.height}p" }).toTypedArray()
        val ov = pl.trackSelectionParameters.overrides[group.mediaTrackGroup]
        val checked = if (ov == null || ov.trackIndices.isEmpty()) 0 else {
            val sel = pl.trackSelectionParameters.overrides[group.mediaTrackGroup]!!.trackIndices[0]
            val h = group.getTrackFormat(sel).height
            val i = opts.indexOfFirst { it.second.height == h }
            if (i >= 0) i + 1 else 0
        }
        AlertDialog.Builder(this)
            .setTitle("Calidad")
            .setSingleChoiceItems(labels, checked) { dlg, which ->
                val b = pl.trackSelectionParameters.buildUpon()
                if (which == 0) {
                    b.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                } else {
                    b.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, opts[which - 1].first))
                }
                pl.trackSelectionParameters = b.build()
                dlg.dismiss()
            }
            .show()
    }


    // =====================  SUBTÍTULOS  =====================

    private class TT(val group: Tracks.Group, val idx: Int, val fmt: Format)

    private fun resolveYoutube(id: String) {
        Toast.makeText(this, "Cargando video de YouTube…", Toast.LENGTH_SHORT).show()
        Thread {
            val r = YouTube.resolve(id)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (r == null) {
                    Toast.makeText(
                        this,
                        "No se pudo cargar este video de YouTube (puede ser privado, tener restricción de edad o YouTube cambió algo)",
                        Toast.LENGTH_LONG
                    ).show()
                    finish()
                    return@runOnUiThread
                }
                dsf?.setUserAgent(r.ua)
                mainUrl = r.url
                mainMime = r.mime
                audioUrl = r.audioUrl
                startPlayback()
            }
        }.start()
    }

    private fun startPlayback() {
        val p = player ?: return
        if (isDestroyed) return
        val cfgs = extSubs.mapNotNull { (u, lang, label) ->
            val mt = subMime(u) ?: return@mapNotNull null
            val lg = (if (lang.isBlank()) guessLang(u) else lang).ifBlank { null }
            MediaItem.SubtitleConfiguration.Builder(Uri.parse(u))
                .setMimeType(mt)
                .setLanguage(lg)
                .setLabel(label.ifBlank { null })
                .build()
        }
        val au = audioUrl
        val df = dsf
        if (au != null && df != null) {
            // YouTube con video y audio separados: se unen en el reproductor
            val f = ProgressiveMediaSource.Factory(df)
            p.setMediaSource(
                MergingMediaSource(
                    f.createMediaSource(MediaItem.fromUri(Uri.parse(mainUrl))),
                    f.createMediaSource(MediaItem.fromUri(Uri.parse(au)))
                )
            )
        } else {
            p.setMediaItem(
                MediaItem.Builder().setUri(Uri.parse(mainUrl)).setMimeType(mainMime)
                    .setSubtitleConfigurations(cfgs).build()
            )
        }
        p.prepare()
        p.playWhenReady = true
        room?.let { setupRoom(root, it) }
        applyLayout()
    }

    private fun subMime(u: String): String? {
        val path = (Uri.parse(u).path ?: u).lowercase()
        return when {
            path.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            path.endsWith(".srt") -> MimeTypes.APPLICATION_SUBRIP
            path.endsWith(".ass") || path.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            path.endsWith(".ttml") || path.endsWith(".dfxp") || path.endsWith(".xml") -> MimeTypes.APPLICATION_TTML
            else -> null
        }
    }

    /** Adivina el idioma por el nombre del archivo: pelicula.es.vtt, sub_eng.srt, ... */
    private fun guessLang(u: String): String {
        val name = (Uri.parse(u).lastPathSegment ?: "").lowercase().substringBeforeLast('.')
        val m = Regex("(?:^|[._\\-])(es|spa|lat|en|eng|pt|por|fr|fra|fre|de|deu|ger|it|ita|ja|jpn|ko|kor|zh|zho|chi|ru|rus)(?:[._\\-]|$)").find(name)
        return Langs.norm(m?.groupValues?.get(1))
    }

    /** Prueba si junto al video hay un archivo de subtítulos (mismo nombre + .vtt/.srt) */
    private fun probeSidecars(url: String, headers: Map<String, String>, cb: (List<Triple<String, String, String>>) -> Unit) {
        val u = Uri.parse(url)
        if (u.query != null || !url.substringAfterLast('/').contains('.')) {
            cb(emptyList())
            return
        }
        val base = url.substringBeforeLast('.')
        val l = if (subLang == "off") "" else subLang
        val cands = ArrayList<String>()
        if (l.isNotEmpty()) {
            cands.add("$base.$l.vtt"); cands.add("$base.$l.srt")
        }
        cands.add("$base.vtt"); cands.add("$base.srt")
        Thread {
            val found = CopyOnWriteArrayList<Triple<String, String, String>>()
            val latch = CountDownLatch(cands.size)
            for (c in cands) {
                Thread {
                    try {
                        val cn = URL(c).openConnection() as HttpURLConnection
                        cn.connectTimeout = 2000
                        cn.readTimeout = 2000
                        headers.forEach { (k, v) -> cn.setRequestProperty(k, v) }
                        cn.setRequestProperty("Range", "bytes=0-399")
                        val code = cn.responseCode
                        val ct = (cn.contentType ?: "").lowercase()
                        if ((code == 200 || code == 206) && !ct.contains("html")) {
                            val buf = ByteArray(400)
                            val n = cn.inputStream.read(buf)
                            val head = if (n > 0) String(buf, 0, n, Charsets.UTF_8).trimStart('\uFEFF', ' ', '\n', '\r') else ""
                            val ok = if (c.endsWith(".vtt")) head.startsWith("WEBVTT")
                            else Regex("^\\d+\\s*\\r?\\n\\d\\d:\\d\\d:\\d\\d").containsMatchIn(head)
                            if (ok) {
                                val lg = Langs.norm(guessLang(c)).ifBlank { l }
                                found.add(Triple(c, lg, ""))
                            }
                        }
                        cn.disconnect()
                    } catch (e: Exception) {
                    } finally {
                        latch.countDown()
                    }
                }.start()
            }
            try {
                latch.await(2500, java.util.concurrent.TimeUnit.MILLISECONDS)
            } catch (e: Exception) {
            }
            // un solo archivo por idioma (el primero de la lista de candidatos)
            val ordered = cands.mapNotNull { c -> found.firstOrNull { it.first == c } }
            val uniq = ordered.distinctBy { it.second }
            runOnUiThread { if (!isDestroyed) cb(uniq) }
        }.start()
    }

    private fun textTracks(): List<TT> {
        val pl = player ?: return emptyList()
        val out = ArrayList<TT>()
        for (g in pl.currentTracks.groups) {
            if (g.type != C.TRACK_TYPE_TEXT) continue
            for (i in 0 until g.length) if (g.isTrackSupported(i)) out.add(TT(g, i, g.getTrackFormat(i)))
        }
        return out
    }

    private fun trackLabel(t: TT): String {
        val lg = Langs.norm(t.fmt.language)
        val name = t.fmt.label?.takeIf { it.isNotBlank() } ?: if (lg.isNotEmpty()) Langs.name(lg) else "Subtítulos"
        return name
    }

    private fun effectiveLang(): String =
        if (subLang == "off" || subLang.isBlank()) java.util.Locale.getDefault().language else subLang

    private fun updateCcBtn() {
        ccBtn.text = if (subsOn) "CC ✓" else "CC"
    }

    /** Se ejecuta una vez, cuando el video ya cargó: elige la pista del idioma elegido o genera subtítulos */
    private fun decideSubs() {
        if (decided) return
        decided = true
        if (subLang == "off") return
        val tracks = textTracks()
        val match = tracks.firstOrNull { Langs.norm(it.fmt.language) == subLang }
            ?: tracks.firstOrNull { Langs.norm(it.fmt.language).isEmpty() }
        if (match != null) {
            selectTrack(match)
        } else {
            // No trae subtítulos en tu idioma: se crean automáticamente
            startAuto(false)
        }
    }

    private fun selectTrack(t: TT) {
        val pl = player ?: return
        stopAuto()
        autoWanted = false
        autoOn = false
        pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(t.group.mediaTrackGroup, t.idx))
            .build()
        subsOn = true
        updateCcBtn()
    }

    private fun subsOff() {
        val pl = player ?: return
        stopAuto()
        autoWanted = false
        autoOn = false
        pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
        subsOn = false
        updateCcBtn()
    }

    private fun showSubs() {
        val pl = player ?: return
        val tracks = textTracks()
        val labels = ArrayList<String>()
        labels.add("Desactivados")
        tracks.forEach { labels.add(trackLabel(it)) }
        labels.add("Automáticos en ${Langs.name(effectiveLang())} (beta)")
        var checked = 0
        if (subsOn) {
            checked = if (autoOn) labels.size - 1 else {
                val i = tracks.indexOfFirst { it.group.isTrackSelected(it.idx) }
                if (i >= 0) i + 1 else 0
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Subtítulos")
            .setSingleChoiceItems(labels.toTypedArray(), checked) { dlg, which ->
                when {
                    which == 0 -> subsOff()
                    which == labels.size - 1 -> startAuto(false)
                    else -> selectTrack(tracks[which - 1])
                }
                dlg.dismiss()
            }
            .show()
    }

    // ---- Subtítulos automáticos ----
    private fun startAuto(quiet: Boolean) {
        if (Build.VERSION.SDK_INT < 33) {
            Toast.makeText(this, "Este video no trae subtítulos. Los automáticos necesitan Android 13 o superior", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 78)
            return
        }
        val pl = player ?: return
        val t = tap ?: return
        stopAuto()
        // se apagan los subtítulos "normales" para no mezclar los dos
        pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
        val a = AutoCaptions(
            this, audLang, effectiveLang(),
            { txt -> showCaption(txt) },
            { msg ->
                runOnUiThread {
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                    auto = null
                    t.listener = null
                    autoOn = false
                    autoWanted = false
                    subsOn = false
                    updateCcBtn()
                }
            }
        )
        auto = a
        t.listener = { b -> a.feed(b) }
        autoOn = true
        subsOn = true
        autoWanted = true
        updateCcBtn()
        if (!quiet) Toast.makeText(this, "Generando subtítulos automáticos (beta)…", Toast.LENGTH_SHORT).show()
        a.start()
    }

    private fun stopAuto() {
        tap?.listener = null
        auto?.stop()
        auto = null
        hbHandler.removeCallbacks(capHide)
        capView?.visibility = View.GONE
    }

    private fun showCaption(t: String) {
        val v = capView ?: return
        var s = t.trim()
        if (s.isEmpty()) return
        if (s.length > 110) s = "…" + s.takeLast(110).substringAfter(' ')
        v.text = s
        v.visibility = View.VISIBLE
        hbHandler.removeCallbacks(capHide)
        hbHandler.postDelayed(capHide, 4500)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !isPortrait) goFullscreen()
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
        // sin video en pantalla no hace falta reconocer voz; se reanuda al volver
        val was = autoOn && auto != null
        stopAuto()
        autoWanted = was
    }

    override fun onResume() {
        super.onResume()
        if (autoWanted && auto == null) {
            autoWanted = false
            startAuto(true)
        }
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }

    override fun onDestroy() {
        hbHandler.removeCallbacksAndMessages(null)
        stopAuto()
        // Avisa a la sala que me fui y da un momento para que se envíe antes de cerrar el WebView
        val rw = roomWeb
        roomWeb = null
        rw?.evaluateJavascript("leaveVoice();leaveRoom()", null)
        if (rw != null) {
            (rw.parent as? ViewGroup)?.removeView(rw)
            Handler(Looper.getMainLooper()).postDelayed({
                try { rw.destroy() } catch (e: Exception) {}
            }, 1500)
        }
        player?.release()
        player = null
        super.onDestroy()
    }
}

/** WebView del chat: el teclado no usa modo pantalla completa (así no tapa el video en horizontal) */
class RoomWebView(context: Context) : WebView(context) {
    /** Cuando el chat está oculto no debe tapar los toques del video */
    var passThrough = false

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean =
        if (passThrough) false else super.dispatchTouchEvent(ev)

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val ic = super.onCreateInputConnection(outAttrs)
        outAttrs.imeOptions = outAttrs.imeOptions or EditorInfo.IME_FLAG_NO_FULLSCREEN or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        return ic
    }
}
