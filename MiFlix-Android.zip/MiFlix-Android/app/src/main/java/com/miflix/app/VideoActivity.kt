package com.miflix.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.text.TextUtils
import android.util.Base64
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.app.AlertDialog
import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import kotlin.math.abs
import android.view.Gravity
import android.view.MotionEvent
import android.view.GestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

class VideoActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var pv: PlayerView
    private lateinit var fitBtn: TextView
    private lateinit var btnBar: LinearLayout
    private lateinit var root: FrameLayout
    private var isPortrait = false
    private var notif: LinearLayout? = null
    private val notifHide = Runnable { notif?.visibility = View.GONE }
    private var modeIdx = 0

    // ---- Ver juntos ----
    private var room: String? = null
    private var roomWeb: WebView? = null
    private var pageReady = false
    private var isHost = false
    private var synced = false
    private var ignoreUntil = 0L
    private var panelOpen = false
    private var unread = 0
    private var chatPill: TextView? = null
    private var voicePill: TextView? = null
    private val hbHandler = Handler(Looper.getMainLooper())
    private val heartbeat = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && p.playWhenReady && p.playbackState == Player.STATE_READY) pushLocal(null)
            hbHandler.postDelayed(this, 15_000)
        }
    }

    private val modes = listOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT to "Ajustar",
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Llenar pantalla",
        AspectRatioFrameLayout.RESIZE_MODE_FILL to "Estirar"
    )

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url")
        if (url == null) {
            finish()
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        goFullscreen()

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        pv = PlayerView(this)
        pv.setBackgroundColor(Color.BLACK)
        pv.setShutterBackgroundColor(Color.BLACK)
        pv.setKeepContentOnPlayerReset(false)
        pv.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
        pv.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        root.addView(pv, FrameLayout.LayoutParams(-1, -1))

        // Botones arriba a la derecha: Calidad y ajuste de pantalla (visibles junto a los controles)
        val d = resources.displayMetrics.density
        fun pill(label: String): TextView {
            val t = TextView(this)
            t.text = label
            t.setTextColor(Color.WHITE)
            t.textSize = 13f
            t.typeface = Typeface.DEFAULT_BOLD
            t.gravity = Gravity.CENTER
            t.setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            val bg = GradientDrawable()
            bg.setColor(0x99000000.toInt())
            bg.cornerRadius = 20 * d
            t.background = bg
            return t
        }
        btnBar = LinearLayout(this)
        btnBar.orientation = LinearLayout.HORIZONTAL
        room = intent.getStringExtra("room")?.takeIf { it.isNotBlank() }
        val qBtn = pill("Calidad")
        fitBtn = pill(modes[0].second)
        val gap = LinearLayout.LayoutParams(-2, -2)
        gap.setMargins(0, 0, (8 * d).toInt(), 0)
        if (room != null) {
            btnBar.addView(pill("Sala $room"), gap)
            val cp = pill("Chat")
            cp.setOnClickListener { if (panelOpen) closePanel() else openPanel() }
            val vp = pill("Voz")
            vp.setOnClickListener { roomWeb?.evaluateJavascript("toggleVoice()", null) }
            chatPill = cp
            voicePill = vp
            btnBar.addView(cp, gap)
            btnBar.addView(vp, gap)
        }
        btnBar.addView(qBtn, gap)
        btnBar.addView(fitBtn)
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END)
        lp.setMargins(0, (16 * d).toInt(), (24 * d).toInt(), 0)
        root.addView(btnBar, lp)
        qBtn.setOnClickListener { showQuality() }
        fitBtn.setOnClickListener {
            modeIdx = (modeIdx + 1) % modes.size
            pv.resizeMode = modes[modeIdx].first
            fitBtn.text = modes[modeIdx].second
            pv.showController()
        }
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            btnBar.visibility = if (vis == View.VISIBLE) View.VISIBLE else View.GONE
            updateNotifPos()
        })
        setContentView(root)

        // Cabeceras que muchos servidores exigen para entregar el video
        val headers = HashMap<String, String>()
        intent.getStringExtra("referer")?.takeIf { it.isNotBlank() }?.let { headers["Referer"] = it }
        intent.getStringExtra("origin")?.takeIf { it.isNotBlank() }?.let { headers["Origin"] = it }
        intent.getStringExtra("cookie")?.takeIf { it.isNotBlank() }?.let { headers["Cookie"] = it }
        val dsf = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(headers)
        intent.getStringExtra("ua")?.takeIf { it.isNotBlank() }?.let { dsf.setUserAgent(it) }

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsf))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        player = p
        pv.player = p
        pv.controllerShowTimeoutMs = 3000
        pv.hideController()
        p.addListener(object : Player.Listener {
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                pushLocal(null)
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                if (reason == Player.DISCONTINUITY_REASON_SEEK) pushLocal(newPosition.positionMs)
            }

            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@VideoActivity, "No se pudo reproducir este video", Toast.LENGTH_LONG).show()
                finish()
            }
        })
        val low = url.lowercase()
        val mime = when {
            low.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
            low.contains(".mpd") -> MimeTypes.APPLICATION_MPD
            else -> null
        }
        p.setMediaItem(MediaItem.Builder().setUri(Uri.parse(url)).setMimeType(mime).build())
        p.prepare()
        p.playWhenReady = true
        room?.let { setupRoom(root, it) }
        applyLayout()

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val pl = player ?: return true
                val delta = if (e.x < pv.width / 2f) -10_000L else 10_000L
                val max = if (pl.duration > 0) pl.duration else Long.MAX_VALUE
                pl.seekTo((pl.currentPosition + delta).coerceIn(0L, max))
                return true
            }
        })
        pv.setOnTouchListener { _, ev -> gd.onTouchEvent(ev) }
    }

    /** WebView oculto que habla con Firestore (mismo inicio de sesión que la app) */
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupRoom(root: FrameLayout, code: String) {
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        val w = RoomWebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.setBackgroundColor(0xFF141414.toInt())
        w.alpha = 0.01f
        w.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val ok = request.origin.host == "appassets.androidplatform.net" &&
                        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (ok) request.grant(request.resources) else request.deny()
                }
            }
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                loader.shouldInterceptRequest(request.url)
        }
        w.addJavascriptInterface(object {
            @JavascriptInterface
            fun event(type: String, json: String) {
                runOnUiThread { onRoomEvent(type, json) }
            }
        }, "NativeRoom")
        root.addView(w, FrameLayout.LayoutParams(2, 2))
        roomWeb = w
        w.loadUrl("https://appassets.androidplatform.net/assets/room.html?code=$code")
    }

    private fun onRoomEvent(type: String, json: String) {
        try {
            when (type) {
                "ready" -> {
                    isHost = JSONObject(json).optBoolean("host")
                    pageReady = true
                    applyLayout()
                    if (isHost) {
                        synced = true
                        pushLocal(null)
                        hbHandler.postDelayed(heartbeat, 15_000)
                    }
                }
                "state" -> applyRemote(JSONObject(json))
                "close" -> closePanel()
                "chat" -> {
                    val o = JSONObject(json)
                    val priv = o.optBoolean("priv")
                    val visible = isPortrait || panelOpen
                    if (!visible && !isPortrait) {
                        unread++
                        chatPill?.text = "Chat ($unread)"
                    }
                    // Chat cerrado (o mensaje privado en vertical): aviso arriba a la derecha
                    if (!visible || (priv && isPortrait)) {
                        showNotif(o.optString("name"), o.optString("text"), o.optString("photo"), priv)
                    }
                }
                "voice" -> {
                    val o = JSONObject(json)
                    voicePill?.text = when {
                        !o.optBoolean("on") -> "Voz"
                        o.optBoolean("muted") -> "Mic silenciado"
                        else -> "Mic activo"
                    }
                }
                "needmic" -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        roomWeb?.evaluateJavascript("startVoice()", null)
                    } else {
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
                    }
                }
                "toast" -> Toast.makeText(this, JSONObject(json).optString("m"), Toast.LENGTH_SHORT).show()
                "joined" -> Toast.makeText(this, "${JSONObject(json).optString("name")} se unió a la sala", Toast.LENGTH_SHORT).show()
                "missing" -> Toast.makeText(this, "Esa sala ya no existe", Toast.LENGTH_LONG).show()
                "error" -> Toast.makeText(this, "No se pudo conectar con la sala", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
        }
    }

    private fun openPanel() {
        val w = roomWeb ?: return
        if (isPortrait) return
        panelOpen = true
        unread = 0
        chatPill?.text = "Chat"
        notif?.visibility = View.GONE
        showMini(w)
    }

    private fun closePanel() {
        val w = roomWeb ?: return
        panelOpen = false
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(w.windowToken, 0)
        hideMini(w)
        if (!isPortrait) goFullscreen()
    }

    private fun roundOutline(r: Float) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, r)
        }
    }

    /** Mini ventana flotante del chat (horizontal). El campo de escribir va arriba, así el teclado no lo tapa */
    private fun showMini(w: WebView) {
        val d = resources.displayMetrics.density
        val lp = FrameLayout.LayoutParams((300 * d).toInt(), (220 * d).toInt(), Gravity.TOP or Gravity.END)
        lp.setMargins(0, (56 * d).toInt(), (16 * d).toInt(), 0)
        w.layoutParams = lp
        w.outlineProvider = roundOutline(14 * d)
        w.clipToOutline = true
        w.alpha = 1f
        w.bringToFront()
        w.requestFocus()
    }

    private fun hideMini(w: WebView) {
        w.layoutParams = FrameLayout.LayoutParams(2, 2)
        w.alpha = 0.01f
    }

    /** Vertical: video arriba y chat siempre abajo. Horizontal: video completo y chat en mini ventana */
    @Suppress("DEPRECATION")
    private fun applyLayout() {
        val d = resources.displayMetrics.density
        val portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        isPortrait = portrait
        val blp = btnBar.layoutParams as FrameLayout.LayoutParams
        if (portrait) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            val vh = resources.displayMetrics.widthPixels * 9 / 16
            pv.layoutParams = FrameLayout.LayoutParams(-1, vh, Gravity.TOP)
            blp.setMargins(0, (8 * d).toInt(), (8 * d).toInt(), 0)
            if (room != null) {
                chatPill?.visibility = View.GONE
                fitBtn.visibility = View.GONE
            }
            panelOpen = false
            unread = 0
            chatPill?.text = "Chat"
            notif?.visibility = View.GONE
            roomWeb?.let { w ->
                val lp = FrameLayout.LayoutParams(-1, -1)
                lp.topMargin = vh
                w.layoutParams = lp
                w.clipToOutline = false
                w.alpha = 1f
            }
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
            goFullscreen()
            pv.layoutParams = FrameLayout.LayoutParams(-1, -1)
            blp.setMargins(0, (16 * d).toInt(), (24 * d).toInt(), 0)
            chatPill?.visibility = View.VISIBLE
            fitBtn.visibility = View.VISIBLE
            roomWeb?.let { w -> if (panelOpen) showMini(w) else hideMini(w) }
        }
        btnBar.layoutParams = blp
        btnBar.bringToFront()
        notif?.bringToFront()
        updateNotifPos()
        roomWeb?.evaluateJavascript("setMode('${if (portrait) "full" else "mini"}')", null)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayout()
    }

    // ---- Aviso de mensaje nuevo (esquina superior derecha) ----
    private fun notifTop(): Int {
        val d = resources.displayMetrics.density
        val barShown = btnBar.visibility == View.VISIBLE
        return ((if (barShown) (if (isPortrait) 52 else 64) else (if (isPortrait) 8 else 16)) * d).toInt()
    }

    private fun updateNotifPos() {
        val n = notif ?: return
        val lp = n.layoutParams as? FrameLayout.LayoutParams ?: return
        lp.topMargin = notifTop()
        n.layoutParams = lp
    }

    private fun decodePhoto(url: String?): Bitmap? {
        if (url.isNullOrEmpty() || !url.startsWith("data:image")) return null
        return try {
            val b = Base64.decode(url.substringAfter(','), Base64.DEFAULT)
            BitmapFactory.decodeByteArray(b, 0, b.size)
        } catch (e: Exception) {
            null
        }
    }

    private fun avatarView(photo: String?, name: String): View {
        val d = resources.displayMetrics.density
        val bmp = decodePhoto(photo)
        val v: View = if (bmp != null) {
            ImageView(this).apply {
                setImageBitmap(bmp)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
        } else {
            TextView(this).apply {
                text = name.take(1).uppercase()
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                setBackgroundColor(0xFFE50914.toInt())
            }
        }
        v.layoutParams = LinearLayout.LayoutParams((38 * d).toInt(), (38 * d).toInt())
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        v.clipToOutline = true
        return v
    }

    /** Avatar + nombre + mensaje en una línea; si es largo termina en "…" y hay que abrir el chat */
    private fun showNotif(name: String, text: String, photo: String?, priv: Boolean) {
        val d = resources.displayMetrics.density
        notif?.let { root.removeView(it) }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding((10 * d).toInt(), (8 * d).toInt(), (16 * d).toInt(), (8 * d).toInt())
        val bg = GradientDrawable()
        bg.setColor(0xF0222222.toInt())
        bg.cornerRadius = 16 * d
        bg.setStroke((1 * d).toInt().coerceAtLeast(1), 0x66FFFFFF)
        box.background = bg
        box.addView(avatarView(photo, name))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding((10 * d).toInt(), 0, 0, 0)
        val n = TextView(this)
        n.text = (if (priv) "🔒 " else "") + name
        n.setTextColor(0xFFFF6B6B.toInt())
        n.textSize = 12f
        n.typeface = Typeface.DEFAULT_BOLD
        n.maxLines = 1
        n.ellipsize = TextUtils.TruncateAt.END
        n.maxWidth = (190 * d).toInt()
        val t = TextView(this)
        t.text = text.replace('\n', ' ')
        t.setTextColor(Color.WHITE)
        t.textSize = 14f
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.maxWidth = (190 * d).toInt()
        col.addView(n)
        col.addView(t)
        box.addView(col)
        box.setOnClickListener {
            hbHandler.removeCallbacks(notifHide)
            box.visibility = View.GONE
            if (!isPortrait) openPanel()
        }
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END)
        lp.setMargins(0, notifTop(), (24 * d).toInt(), 0)
        root.addView(box, lp)
        notif = box
        hbHandler.removeCallbacks(notifHide)
        hbHandler.postDelayed(notifHide, 5000)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                roomWeb?.evaluateJavascript("startVoice()", null)
            } else {
                Toast.makeText(this, "Sin permiso de micrófono no se puede hablar", Toast.LENGTH_LONG).show()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panelOpen && !isPortrait) closePanel() else super.onBackPressed()
    }

    /** Aplica play/pausa/posición que mandó el otro usuario */
    private fun applyRemote(o: JSONObject) {
        val p = player ?: return
        val playing = o.optBoolean("playing")
        val pos = o.optLong("pos")
        val at = o.optLong("at")
        val elapsed = if (playing && at > 0) (System.currentTimeMillis() - at).coerceIn(0L, 21_600_000L) else 0L
        val target = pos + elapsed
        ignoreUntil = SystemClock.elapsedRealtime() + 1500
        synced = true
        if (abs(p.currentPosition - target) > 2500) p.seekTo(target)
        if (p.playWhenReady != playing) p.playWhenReady = playing
    }

    /** Avisa a la sala de lo que hice yo (play, pausa o salto) */
    private fun pushLocal(pos: Long?) {
        val p = player ?: return
        val w = roomWeb ?: return
        if (!pageReady || !synced) return
        if (SystemClock.elapsedRealtime() < ignoreUntil) return
        val position = pos ?: p.currentPosition
        w.evaluateJavascript("pushState(${p.playWhenReady},$position)", null)
    }

    /** Menú de calidad: "Automática" + las resoluciones que ofrezca el video (HLS/DASH) */
    private fun showQuality() {
        val pl = player ?: return
        val group = pl.currentTracks.groups.firstOrNull { it.type == C.TRACK_TYPE_VIDEO && it.length > 0 }
        if (group == null) {
            Toast.makeText(this, "Cargando video…", Toast.LENGTH_SHORT).show()
            return
        }
        // una opción por resolución (la de mayor bitrate), de mayor a menor
        val opts = (0 until group.length)
            .filter { group.isTrackSupported(it) && group.getTrackFormat(it).height > 0 }
            .map { it to group.getTrackFormat(it) }
            .sortedWith(compareByDescending<Pair<Int, androidx.media3.common.Format>> { it.second.height }
                .thenByDescending { it.second.bitrate })
            .distinctBy { it.second.height }
        if (opts.size < 2) {
            Toast.makeText(this, "Este video solo tiene una calidad", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = (listOf("Automática") + opts.map { "${it.second.height}p" }).toTypedArray()
        val ov = pl.trackSelectionParameters.overrides[group.mediaTrackGroup]
        val checked = if (ov == null || ov.trackIndices.isEmpty()) 0 else {
            val sel = pl.trackSelectionParameters.overrides[group.mediaTrackGroup]!!.trackIndices[0]
            val h = group.getTrackFormat(sel).height
            val i = opts.indexOfFirst { it.second.height == h }
            if (i >= 0) i + 1 else 0
        }
        AlertDialog.Builder(this)
            .setTitle("Calidad")
            .setSingleChoiceItems(labels, checked) { dlg, which ->
                val b = pl.trackSelectionParameters.buildUpon()
                if (which == 0) {
                    b.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                } else {
                    b.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, opts[which - 1].first))
                }
                pl.trackSelectionParameters = b.build()
                dlg.dismiss()
            }
            .show()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !isPortrait) goFullscreen()
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }

    override fun onDestroy() {
        hbHandler.removeCallbacksAndMessages(null)
        roomWeb?.evaluateJavascript("leaveVoice()", null)
        roomWeb?.destroy()
        roomWeb = null
        player?.release()
        player = null
        super.onDestroy()
    }
}

/** WebView del chat: el teclado no usa modo pantalla completa (así no tapa el video en horizontal) */
class RoomWebView(context: Context) : WebView(context) {
    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val ic = super.onCreateInputConnection(outAttrs)
        outAttrs.imeOptions = outAttrs.imeOptions or EditorInfo.IME_FLAG_NO_FULLSCREEN or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        return ic
    }
}
