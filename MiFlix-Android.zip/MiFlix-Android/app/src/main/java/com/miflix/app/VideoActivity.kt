package com.miflix.app

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.GestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

class VideoActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var pv: PlayerView
    private lateinit var fitBtn: TextView
    private lateinit var btnBar: LinearLayout
    private var modeIdx = 0

    private val modes = listOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT to "Ajustar",
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Llenar pantalla",
        AspectRatioFrameLayout.RESIZE_MODE_FILL to "Estirar"
    )

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url")
        if (url == null) {
            finish()
            return
        }
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        goFullscreen()

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        pv = PlayerView(this)
        pv.setBackgroundColor(Color.BLACK)
        pv.setShutterBackgroundColor(Color.BLACK)
        pv.setKeepContentOnPlayerReset(false)
        pv.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
        pv.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        root.addView(pv, FrameLayout.LayoutParams(-1, -1))

        // Botones arriba a la derecha: Calidad y ajuste de pantalla (visibles junto a los controles)
        val d = resources.displayMetrics.density
        fun pill(label: String): TextView {
            val t = TextView(this)
            t.text = label
            t.setTextColor(Color.WHITE)
            t.textSize = 13f
            t.typeface = Typeface.DEFAULT_BOLD
            t.gravity = Gravity.CENTER
            t.setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            val bg = GradientDrawable()
            bg.setColor(0x99000000.toInt())
            bg.cornerRadius = 20 * d
            t.background = bg
            return t
        }
        btnBar = LinearLayout(this)
        btnBar.orientation = LinearLayout.HORIZONTAL
        val qBtn = pill("Calidad")
        fitBtn = pill(modes[0].second)
        val gap = LinearLayout.LayoutParams(-2, -2)
        gap.setMargins(0, 0, (8 * d).toInt(), 0)
        btnBar.addView(qBtn, gap)
        btnBar.addView(fitBtn)
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END)
        lp.setMargins(0, (16 * d).toInt(), (24 * d).toInt(), 0)
        root.addView(btnBar, lp)
        qBtn.setOnClickListener { showQuality() }
        fitBtn.setOnClickListener {
            modeIdx = (modeIdx + 1) % modes.size
            pv.resizeMode = modes[modeIdx].first
            fitBtn.text = modes[modeIdx].second
            pv.showController()
        }
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            btnBar.visibility = if (vis == View.VISIBLE) View.VISIBLE else View.GONE
        })
        setContentView(root)

        // Cabeceras que muchos servidores exigen para entregar el video
        val headers = HashMap<String, String>()
        intent.getStringExtra("referer")?.takeIf { it.isNotBlank() }?.let { headers["Referer"] = it }
        intent.getStringExtra("origin")?.takeIf { it.isNotBlank() }?.let { headers["Origin"] = it }
        intent.getStringExtra("cookie")?.takeIf { it.isNotBlank() }?.let { headers["Cookie"] = it }
        val dsf = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(headers)
        intent.getStringExtra("ua")?.takeIf { it.isNotBlank() }?.let { dsf.setUserAgent(it) }

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsf))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        player = p
        pv.player = p
        pv.controllerShowTimeoutMs = 3000
        pv.hideController()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@VideoActivity, "No se pudo reproducir este video", Toast.LENGTH_LONG).show()
                finish()
            }
        })
        val low = url.lowercase()
        val mime = when {
            low.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
            low.contains(".mpd") -> MimeTypes.APPLICATION_MPD
            else -> null
        }
        p.setMediaItem(MediaItem.Builder().setUri(Uri.parse(url)).setMimeType(mime).build())
        p.prepare()
        p.playWhenReady = true

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val pl = player ?: return true
                val delta = if (e.x < pv.width / 2f) -10_000L else 10_000L
                val max = if (pl.duration > 0) pl.duration else Long.MAX_VALUE
                pl.seekTo((pl.currentPosition + delta).coerceIn(0L, max))
                return true
            }
        })
        pv.setOnTouchListener { _, ev -> gd.onTouchEvent(ev) }
    }

    /** Menú de calidad: "Automática" + las resoluciones que ofrezca el video (HLS/DASH) */
    private fun showQuality() {
        val pl = player ?: return
        val group = pl.currentTracks.groups.firstOrNull { it.type == C.TRACK_TYPE_VIDEO && it.length > 0 }
        if (group == null) {
            Toast.makeText(this, "Cargando video…", Toast.LENGTH_SHORT).show()
            return
        }
        // una opción por resolución (la de mayor bitrate), de mayor a menor
        val opts = (0 until group.length)
            .filter { group.isTrackSupported(it) && group.getTrackFormat(it).height > 0 }
            .map { it to group.getTrackFormat(it) }
            .sortedWith(compareByDescending<Pair<Int, androidx.media3.common.Format>> { it.second.height }
                .thenByDescending { it.second.bitrate })
            .distinctBy { it.second.height }
        if (opts.size < 2) {
            Toast.makeText(this, "Este video solo tiene una calidad", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = (listOf("Automática") + opts.map { "${it.second.height}p" }).toTypedArray()
        val ov = pl.trackSelectionParameters.overrides[group.mediaTrackGroup]
        val checked = if (ov == null || ov.trackIndices.isEmpty()) 0 else {
            val sel = pl.trackSelectionParameters.overrides[group.mediaTrackGroup]!!.trackIndices[0]
            val h = group.getTrackFormat(sel).height
            val i = opts.indexOfFirst { it.second.height == h }
            if (i >= 0) i + 1 else 0
        }
        AlertDialog.Builder(this)
            .setTitle("Calidad")
            .setSingleChoiceItems(labels, checked) { dlg, which ->
                val b = pl.trackSelectionParameters.buildUpon()
                if (which == 0) {
                    b.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                } else {
                    b.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, opts[which - 1].first))
                }
                pl.trackSelectionParameters = b.build()
                dlg.dismiss()
            }
            .show()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goFullscreen()
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
