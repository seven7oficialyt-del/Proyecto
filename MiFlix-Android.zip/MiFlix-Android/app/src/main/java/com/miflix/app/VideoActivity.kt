package com.miflix.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class VideoActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var pv: PlayerView

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url")
        if (url == null) {
            finish()
            return
        }
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        pv = PlayerView(this)
        pv.setBackgroundColor(0xFF000000.toInt())
        setContentView(pv)
        immersive()

        // Cabeceras que muchos servidores exigen para entregar el video
        val headers = HashMap<String, String>()
        intent.getStringExtra("referer")?.takeIf { it.isNotBlank() }?.let { headers["Referer"] = it }
        intent.getStringExtra("origin")?.takeIf { it.isNotBlank() }?.let { headers["Origin"] = it }
        intent.getStringExtra("cookie")?.takeIf { it.isNotBlank() }?.let { headers["Cookie"] = it }
        val dsf = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(headers)
        intent.getStringExtra("ua")?.takeIf { it.isNotBlank() }?.let { dsf.setUserAgent(it) }

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsf))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        player = p
        pv.player = p
        pv.controllerShowTimeoutMs = 3000
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@VideoActivity, "No se pudo reproducir este video", Toast.LENGTH_LONG).show()
            }
        })
        val low = url.lowercase()
        val mime = when {
            low.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
            low.contains(".mpd") -> MimeTypes.APPLICATION_MPD
            else -> null
        }
        p.setMediaItem(MediaItem.Builder().setUri(Uri.parse(url)).setMimeType(mime).build())
        p.prepare()
        p.playWhenReady = true

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val pl = player ?: return true
                val delta = if (e.x < pv.width / 2f) -10_000L else 10_000L
                val max = if (pl.duration > 0) pl.duration else Long.MAX_VALUE
                pl.seekTo((pl.currentPosition + delta).coerceIn(0L, max))
                return true
            }
        })
        pv.setOnTouchListener { _, ev -> gd.onTouchEvent(ev) }
    }

    @Suppress("DEPRECATION")
    private fun immersive() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
