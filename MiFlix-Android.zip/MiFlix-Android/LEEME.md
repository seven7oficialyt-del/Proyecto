# MiFlix para Android

## 1. Crear el proyecto de Firebase (gratis)
1. Entra a https://console.firebase.google.com y crea un proyecto.
2. Build > Authentication > Comenzar > activa **Correo electrónico/contraseña**.
3. Build > Firestore Database > Crear base de datos (modo producción).
4. En la pestaña **Reglas** de Firestore pega el contenido de `firestore.rules` y publica.
5. Configuración del proyecto > Tus apps > Web (</>) > registra la app y copia `firebaseConfig`.
6. Pega esos valores en `app/src/main/assets/index.html` (zona "PEGA AQUÍ").

## 2. Compilar el APK
- GitHub: sube el ZIP a la raíz del repositorio; tu flujo "Crear APK" lo descomprime y compila solo.
- Android Studio: abre la carpeta y elige Build > Build APK(s).

## 3. Ser administrador
1. Abre la app y crea tu cuenta (usuario y contraseña).
2. En Firebase > Authentication > Usuarios copia tu **UID**.
3. En Firestore crea la colección `admins` con un documento cuyo ID sea ese UID (agrega cualquier campo, p. ej. `ok: true`).
4. Cierra sesión y vuelve a entrar: verás "+ Agregar", Editar y Eliminar. Los demás usuarios solo ven y califican.

## 5. Perfiles de usuario
- Cada usuario tiene perfil: toca tu foto (arriba a la derecha) para subir, cambiar o quitar tu imagen.
- Todos pueden ver los perfiles desde la fila **Comunidad** o tocando a quien calificó un título.
- Las fotos se guardan (reducidas a 256×256) en Firestore, colección `users`; no necesitas Firebase Storage.
- **Importante:** vuelve a pegar `firestore.rules` en Firebase > Firestore > Reglas y publica, o las fotos no se podrán guardar.

## 6. Ver juntos
- En un título (o en un capítulo, botón 👥) toca **Ver juntos**: se crea una sala con un código de 5 letras.
- Invita a un amigo desde la sala o desde su perfil (Comunidad), o dale el código: él lo escribe en el botón 🎬 de arriba.
- Cada uno usa su reproductor nativo; play, pausa y saltos se sincronizan entre los dos.
- **Importante:** vuelve a publicar `firestore.rules` (ahora incluye `rooms`).

## 7. Amigos, chat y voz
- Agrega amigos desde su perfil (Comunidad) o desde el botón de chat del encabezado. El otro acepta la solicitud.
- Chat privado: botón de chat > toca a tu amigo.
- Mientras ven algo juntos, en el reproductor aparecen **Chat** (pestañas Sala / Privado / Voz) y **Voz** (micrófono en vivo).
- **Importante:** vuelve a publicar `firestore.rules` (incluye `friendships`, `chats` y subcolecciones de `rooms`).

## 8. Novedades (chat flotante, likes, cifrado, recuperación)
**IMPORTANTE: vuelve a publicar `firestore.rules`** (nuevas colecciones `likes`, `imgs`, `secrets`, `recovery` y mensajes privados cifrados).

- **Chat al ver juntos (horizontal):** el botón *Chat* abre una mini ventana flotante con avatar + mensaje. Con el chat cerrado, cada mensaje nuevo aparece arriba a la derecha (avatar, nombre y mensaje en una línea; si es largo termina en "…" y tocándolo se abre el chat).
- **Vertical:** al girar el teléfono el video queda arriba y el chat se abre solo debajo (con Sala / Privado / Voz). Al volver a horizontal vuelve el video completo.
- **Likes:** botón ♡ en cada título. El perfil muestra las portadas de lo que le diste like.
- **Imágenes originales:** las portadas y fotos de perfil se suben sin reducir (máx. 15 MB) y se guardan por partes en Firestore (`imgs`). En listas se usa una miniatura para que cargue rápido; al abrir el título o el perfil se carga la original (toca la imagen para ampliarla).
- **Chats privados cifrados de extremo a extremo** (ECDH P-256 + AES-GCM). La clave privada vive en tu teléfono y una copia protegida con tu contraseña en `secrets/{tu uid}`; los mensajes antiguos sin cifrar se siguen viendo. Ambos amigos deben abrir la app actualizada una vez para activarlo.
- **Edad + pregunta de seguridad** al crear cuenta (*¿Quién es tu persona o mascota favorita?*). Los usuarios ya existentes verán un aviso para completarlo.
- **Código de recuperación único** (20 caracteres): se muestra una sola vez al crear la cuenta. En el login, *¿Perdiste el acceso?* → usuario + código + respuesta (+ nueva contraseña opcional). Todo se verifica en el teléfono: la contraseña se guarda cifrada con (código + respuesta), así nadie —ni tú como administrador— puede leerla.

## 9. Imágenes optimizadas y caché local
**Vuelve a publicar `firestore.rules`** (nueva colección `meta`).

- **Imágenes:** se convierten a WebP al 85 % con lado mayor máximo de 1600 px (1024 px en fotos de perfil). Casi no se nota la diferencia y pesan 5 a 10 veces menos. Las miniaturas de las listas son de 400 px (256 px en avatares). GIF y fotos ya pequeñas (<300 KB) se suben tal cual.
- **Caché en el teléfono (IndexedDB):** la primera vez se descarga el catálogo y, en segundo plano, las imágenes originales. Las siguientes veces la app abre al instante desde el teléfono y solo pide lo **nuevo o editado** (`updatedAt`) y los títulos eliminados (`meta/catalog`).
- Los títulos que ya existían se descargan completos una vez; al editarlos reciben `updatedAt` y entran en la sincronización incremental.
- Si borras los datos de la app, se vuelve a descargar todo una vez.

## 10. Subtítulos
**No necesitas republicar nada para esto**, pero sí vuelve a compilar el APK (se agregó la librería de traducción de Google ML Kit).

- **Elegir idioma:** al abrir un título aparece el cuadro *Subtítulos* con dos opciones: el idioma de los subtítulos (o *Desactivados*) y el **idioma original del audio**. Se guardan en el teléfono y se usan en todo lo que reproduzcas (también en *Ver juntos*: cada persona usa su propio idioma).
- **Detección desde el enlace**, en este orden:
  1. Subtítulos incluidos en el video (HLS `.m3u8` o archivos `.mp4`/`.mkv` con pistas).
  2. Subtítulos que la página del enlace declare (`<track>`) o descargue (`.vtt`, `.srt`, `.ass`, `.ttml`).
  3. Archivos "hermanos" junto al video: `pelicula.mp4` → `pelicula.vtt` / `pelicula.srt` (también `pelicula.es.vtt`).
  Si hay uno en el idioma elegido se activa solo.
- **Si no hay subtítulos en tu idioma** se crean automáticamente (beta): la app toma el audio que suena, lo reconoce con el reconocimiento de voz del teléfono (en el idioma original que elegiste) y lo traduce en el teléfono al idioma de los subtítulos. Requisitos: **Android 13 o superior**, internet, y aceptar el permiso de micrófono la primera vez (solo se usa para el reconocimiento; no se graba nada). La primera vez de cada par de idiomas descarga el modelo de traducción (~30 MB).
- **Botón CC** en el reproductor (arriba, junto a *Calidad*): apaga los subtítulos, elige otra pista o fuerza los automáticos. Muestra ✓ cuando hay subtítulos activos.
- Los subtítulos automáticos salen unos instantes después de lo que se dice y no son perfectos; es normal en esta versión.

## 11. Reportes de bugs y sugerencias
**IMPORTANTE: vuelve a publicar `firestore.rules`** (nueva colección `feedback`).

- Todos los usuarios ven al final de la pantalla principal el botón **💡 Bug o sugerencia**: eligen tipo, escriben el mensaje y lo envían. También ven el estado de sus envíos (Pendiente / Resuelto).
- Cada reporte guarda usuario, tipo, texto, fecha y datos del dispositivo (para poder reproducir el bug).
- **El administrador** ve además el botón **📥 Reportes (n)** con todos los envíos, filtros (Pendientes / Resueltos / Todos), y puede marcarlos como resueltos, reabrirlos o eliminarlos. Los demás usuarios solo ven los suyos.
