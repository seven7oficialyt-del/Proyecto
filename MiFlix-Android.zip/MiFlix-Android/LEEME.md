# MiFlix para Android

## 1. Crear el proyecto de Firebase (gratis)
1. Entra a https://console.firebase.google.com y crea un proyecto.
2. Build > Authentication > Comenzar > activa **Correo electrónico/contraseña**.
3. Build > Firestore Database > Crear base de datos (modo producción).
4. En la pestaña **Reglas** de Firestore pega el contenido de `firestore.rules` y publica.
5. Configuración del proyecto > Tus apps > Web (</>) > registra la app y copia `firebaseConfig`.
6. Pega esos valores en `app/src/main/assets/index.html` (zona "PEGA AQUÍ").

## 2. Compilar el APK
- GitHub: sube el ZIP a la raíz del repositorio; tu flujo "Crear APK" lo descomprime y compila solo.
- Android Studio: abre la carpeta y elige Build > Build APK(s).

## 3. Ser administrador
1. Abre la app y crea tu cuenta (usuario y contraseña).
2. En Firebase > Authentication > Usuarios copia tu **UID**.
3. En Firestore crea la colección `admins` con un documento cuyo ID sea ese UID (agrega cualquier campo, p. ej. `ok: true`).
4. Cierra sesión y vuelve a entrar: verás "+ Agregar", Editar y Eliminar. Los demás usuarios solo ven y califican.
