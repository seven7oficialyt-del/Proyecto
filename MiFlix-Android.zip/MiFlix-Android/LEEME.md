# MiFlix para Android

## 1. Crear el proyecto de Firebase (gratis)
1. Entra a https://console.firebase.google.com y crea un proyecto.
2. Build > Authentication > Comenzar > activa **Correo electrónico/contraseña**.
3. Build > Firestore Database > Crear base de datos (modo producción).
4. En la pestaña **Reglas** de Firestore pega el contenido de `firestore.rules` y publica.
5. Configuración del proyecto > Tus apps > Web (</>) > registra la app y copia `firebaseConfig`.
6. Pega esos valores en `app/src/main/assets/index.html` (zona "PEGA AQUÍ").

## 2. Compilar el APK
- GitHub: sube el ZIP a la raíz del repositorio; tu flujo "Crear APK" lo descomprime y compila solo.
- Android Studio: abre la carpeta y elige Build > Build APK(s).

## 3. Ser administrador
1. Abre la app y crea tu cuenta (usuario y contraseña).
2. En Firebase > Authentication > Usuarios copia tu **UID**.
3. En Firestore crea la colección `admins` con un documento cuyo ID sea ese UID (agrega cualquier campo, p. ej. `ok: true`).
4. Cierra sesión y vuelve a entrar: verás "+ Agregar", Editar y Eliminar. Los demás usuarios solo ven y califican.

## 5. Perfiles de usuario
- Cada usuario tiene perfil: toca tu foto (arriba a la derecha) para subir, cambiar o quitar tu imagen.
- Todos pueden ver los perfiles desde la fila **Comunidad** o tocando a quien calificó un título.
- Las fotos se guardan (reducidas a 256×256) en Firestore, colección `users`; no necesitas Firebase Storage.
- **Importante:** vuelve a pegar `firestore.rules` en Firebase > Firestore > Reglas y publica, o las fotos no se podrán guardar.

## 6. Ver juntos
- En un título (o en un capítulo, botón 👥) toca **Ver juntos**: se crea una sala con un código de 5 letras.
- Invita a un amigo desde la sala o desde su perfil (Comunidad), o dale el código: él lo escribe en el botón 🎬 de arriba.
- Cada uno usa su reproductor nativo; play, pausa y saltos se sincronizan entre los dos.
- **Importante:** vuelve a publicar `firestore.rules` (ahora incluye `rooms`).

## 7. Amigos, chat y voz
- Agrega amigos desde su perfil (Comunidad) o desde el botón de chat del encabezado. El otro acepta la solicitud.
- Chat privado: botón de chat > toca a tu amigo.
- Mientras ven algo juntos, en el reproductor aparecen **Chat** (pestañas Sala / Privado / Voz) y **Voz** (micrófono en vivo).
- **Importante:** vuelve a publicar `firestore.rules` (incluye `friendships`, `chats` y subcolecciones de `rooms`).
