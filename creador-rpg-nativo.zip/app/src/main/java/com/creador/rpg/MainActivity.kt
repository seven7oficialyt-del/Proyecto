package com.creador.rpg

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.*
import android.media.MediaPlayer
import android.os.Bundle
import android.util.Base64
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.abs
import kotlin.random.Random

const val W = 16
const val H = 12

class MainActivity : Activity() {
    lateinit var gv: GameView
    override fun onCreate(b: Bundle?) { super.onCreate(b); gv = GameView(this); setContentView(gv) }
    override fun onPause() { super.onPause(); gv.save(); gv.music(false) }
    override fun onResume() { super.onResume(); if (gv.mode == 1) gv.music(true) }
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (res != RESULT_OK) return
        val u = d?.data ?: return
        if (rc == 1) contentResolver.openOutputStream(u)?.use { it.write(gv.toJson(true).toByteArray()) }
        if (rc == 2) contentResolver.openInputStream(u)?.use { gv.fromJson(it.readBytes().toString(Charsets.UTF_8)) }
        if (rc == 3) contentResolver.openInputStream(u)?.use { gv.setImg(BitmapFactory.decodeStream(it)) }
        if (rc == 4) contentResolver.openInputStream(u)?.use { i -> File(filesDir, "music.dat").outputStream().use { o -> i.copyTo(o) } }
        gv.invalidate()
    }
}

// k: 0 NPC que habla, 1 entrenador, 2 curandero, 3 puerta
class Npc(val x: Int, val y: Int, val k: Int, val s: String, val cr: Int = 0, val tm: Int = 0, val tx: Int = 0, val ty: Int = 0)
class GMap(var name: String) { val t = IntArray(W * H); val o = mutableListOf<Npc>(); val enc = mutableSetOf<Int>() }
class Mv(var n: String, var ty: Int, var pw: Int)
class Sp(var n: String, var ty: Int, var hp: Int, var a: Int) {
    val mv = mutableListOf<Mv>(); var evLv = 0; var evTo = -1; var img: Bitmap? = null
    fun mvs(): List<Mv> = if (mv.isEmpty()) listOf(Mv("Golpe", 0, 8)) else mv
}
class Cr(var sp: Sp, var hp: Int, var max: Int, var lv: Int = 1, var xp: Int = 0)
class Fi(var n: String, var hp: Int, var spd: Int, var pw: Int, var kk: Int, var sp: Int, var c: Int) { var img: Bitmap? = null; var cs = "112"; var cn = "Combo"; var cd = 20 }
class Stg(var n: String, var sky: Int, var gnd: Int)
class Fg(val f: Fi, var x: Float) { var y = 0f; var vy = 0f; var hp = f.hp; var face = 1; var atk = 0; var at = 0; var hit = false; var stun = 0; var en = 0; var blk = false; var bt = 0; var cw = 0; var cmb = 0; var seq = ""; var fx = 0; var mv = false }
class Btn(val id: String, val label: String, val r: RectF)

class GameView(val act: MainActivity) : View(act) {
    val maps = mutableListOf<GMap>(); val sps = mutableListOf<Sp>()
    var cur = 0; var gs = 0; var sx = 2; var sy = 2; var st = 0; var px = 2; var py = 2
    var mode = 0; var tool = 0; var msg = ""; var bmsg = ""; var S = 1f
    var btns = listOf<Btn>()
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val col = listOf("#7EC850", "#2D6A2D", "#3A7BD5", "#3F9A2A", "#D9C27A", "#8B5E3C", "#CDB38B").map { Color.parseColor(it) }
    val solid = booleanArrayOf(false, true, true, false, false, true, false)
    val tn = listOf("Normal", "Fuego", "Agua", "Planta")
    val tc = listOf("#9E9E9E", "#E5533D", "#4D8FE0", "#58B368").map { Color.parseColor(it) }
    val names = listOf("Pasto", "Árbol", "Agua", "Hierba", "Camino", "Casa", "Suelo", "NPC", "Entrenad.", "Curand.", "Puerta", "Inicio", "Borrar", "Objeto")
    val hints = listOf("Pinta pasto.", "Pinta árboles (no se pueden cruzar).", "Pinta agua (no se cruza).",
        "Pinta hierba alta: aquí salen criaturas.", "Pinta un camino.", "Pinta paredes de casa.", "Pinta suelo de interior.",
        "Toca el mapa: pones un personaje que habla.", "Toca el mapa: pones un entrenador que pelea.",
        "Toca el mapa: pones a alguien que cura tu equipo.", "Toca el mapa: pones una puerta a otro mapa.",
        "Toca el mapa: aquí empieza el jugador.", "Toca un objeto del mapa para borrarlo.", "Toca el mapa: dejas un objeto que el jugador recoge al pisarlo.")
    var team = mutableListOf<Cr>(); var foe: Cr? = null; var foeNpc: Npc? = null
    val beaten = mutableSetOf<String>(); var first = false
    val taken = mutableSetOf<String>(); val bag = mutableMapOf<Int, Int>(); var ai = 0; var pendImg = 0
    var mp: MediaPlayer? = null; val items = listOf("Poción", "Super Poción", "Bola Pro")
    var pendKind = 0; val fis = mutableListOf<Fi>(); val stgs = mutableListOf<Stg>(); var fp = 0; var fo = 1; var fs = 0
    val fcn = listOf("Rojo", "Azul", "Verde", "Amarillo", "Morado", "Naranja", "Negro", "Blanco", "Celeste", "Café")
    val fch = listOf("#E53935", "#1E88E5", "#43A047", "#FDD835", "#8E24AA", "#FB8C00", "#212121", "#FAFAFA", "#81D4FA", "#8D6E63").map { Color.parseColor(it) }
    val held = mutableSetOf<String>(); val pressed = mutableSetOf<String>()
    var pf: Fg? = null; var ef: Fg? = null; var over = 0; var rt = 0; var pw = 0; var ew = 0; var rmsg = ""
    var frame = 0; var cmsg = ""; var ct = 0
    val m: GMap get() = maps[cur]

    init { load(); post { if (first) help() } }

    fun newMap(n: String): GMap {
        val g = GMap(n)
        for (y in 0 until H) for (x in 0 until W) g.t[y * W + x] = if (x == 0 || y == 0 || x == W - 1 || y == H - 1) 1 else 0
        return g
    }
    fun def() {
        maps.clear(); maps.add(newMap("Pueblo")); val g = maps[0]
        for (y in 3..6) for (x in 8..12) g.t[y * W + x] = 3
        g.o.add(Npc(5, 4, 0, "¡Bienvenido! Toca Ayuda si te pierdes.")); g.enc.addAll(listOf(1, 2))
        sps.clear(); sps.add(Sp("Flamito", 1, 32, 9)); sps.add(Sp("Hojín", 3, 34, 8)); sps.add(Sp("Gotín", 2, 33, 8))
        sps.forEach { it.mv.add(Mv("Placaje", 0, 8)); it.mv.add(Mv(listOf("Golpe", "Llamarada", "Latigazo", "Burbuja")[it.ty], it.ty, 12)) }
        cur = 0; gs = 0; sx = 2; sy = 2; st = 0
        fis.clear(); fis.add(Fi("Rojo", 100, 5, 8, 12, 25, 0)); fis.add(Fi("Azul", 100, 6, 7, 11, 24, 1))
        stgs.clear(); stgs.add(Stg("Dojo", 8, 9)); fp = 0; fo = 1; fs = 0
    }
    fun file() = File(act.filesDir, "proj.json")
    fun load() { def(); first = !file().exists(); try { if (!first) fromJson(file().readText()) } catch (e: Exception) {} }
    fun save() { try { file().writeText(toJson()) } catch (e: Exception) {} }

    fun toJson(withMusic: Boolean = false): String {
        val ma = JSONArray()
        maps.forEach { g ->
            val oa = JSONArray()
            g.o.forEach { oa.put(JSONObject().put("x", it.x).put("y", it.y).put("k", it.k).put("s", it.s).put("cr", it.cr).put("tm", it.tm).put("tx", it.tx).put("ty", it.ty)) }
            ma.put(JSONObject().put("name", g.name).put("t", JSONArray(g.t.toList())).put("enc", JSONArray(g.enc.toList())).put("o", oa))
        }
        val sa = JSONArray()
        sps.forEach { z ->
            val mj = JSONArray(); z.mv.forEach { mj.put(JSONObject().put("n", it.n).put("ty", it.ty).put("pw", it.pw)) }
            val j = JSONObject().put("n", z.n).put("ty", z.ty).put("hp", z.hp).put("a", z.a).put("mv", mj).put("evLv", z.evLv).put("evTo", z.evTo)
            z.img?.let { b -> val bo = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.PNG, 100, bo); j.put("img", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)) }
            sa.put(j)
        }
        val fa = JSONArray()
        fis.forEach { z ->
            val j = JSONObject().put("n", z.n).put("hp", z.hp).put("spd", z.spd).put("pw", z.pw).put("kk", z.kk).put("sp", z.sp).put("c", z.c).put("cs", z.cs).put("cn", z.cn).put("cd", z.cd)
            z.img?.let { b -> val bo = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.PNG, 100, bo); j.put("img", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)) }
            fa.put(j)
        }
        val ga = JSONArray(); stgs.forEach { ga.put(JSONObject().put("n", it.n).put("sky", it.sky).put("gnd", it.gnd)) }
        val o = JSONObject().put("maps", ma).put("sp", sa).put("gs", gs).put("sx", sx).put("sy", sy).put("st", st)
            .put("fi", fa).put("sg", ga).put("fp", fp).put("fo", fo).put("fs", fs)
        val mf = File(act.filesDir, "music.dat")
        if (withMusic && mf.exists()) o.put("music", Base64.encodeToString(mf.readBytes(), Base64.NO_WRAP))
        return o.toString()
    }
    fun fromJson(s: String) {
        try {
            val o = JSONObject(s); val nm = mutableListOf<GMap>(); val ma = o.getJSONArray("maps")
            for (i in 0 until ma.length()) {
                val q = ma.getJSONObject(i); val g = GMap(q.getString("name")); val t = q.getJSONArray("t")
                if (t.length() != W * H) return
                for (j in 0 until W * H) g.t[j] = t.getInt(j)
                val e = q.getJSONArray("enc"); for (j in 0 until e.length()) g.enc.add(e.getInt(j))
                val ob = q.getJSONArray("o")
                for (j in 0 until ob.length()) { val r = ob.getJSONObject(j)
                    g.o.add(Npc(r.getInt("x"), r.getInt("y"), r.getInt("k"), r.getString("s"), r.getInt("cr"), r.getInt("tm"), r.getInt("tx"), r.getInt("ty"))) }
                nm.add(g)
            }
            val ns = mutableListOf<Sp>(); val sa = o.getJSONArray("sp")
            for (i in 0 until sa.length()) {
                val r = sa.getJSONObject(i); val z = Sp(r.getString("n"), r.getInt("ty"), r.getInt("hp"), r.getInt("a"))
                val mj = r.optJSONArray("mv")
                if (mj != null) for (j in 0 until mj.length()) { val q = mj.getJSONObject(j); z.mv.add(Mv(q.getString("n"), q.getInt("ty"), q.getInt("pw"))) }
                z.evLv = r.optInt("evLv", 0); z.evTo = r.optInt("evTo", -1)
                val ib = r.optString("img", "")
                if (ib.isNotEmpty()) { val by = Base64.decode(ib, Base64.NO_WRAP); z.img = BitmapFactory.decodeByteArray(by, 0, by.size) }
                ns.add(z)
            }
            if (nm.isEmpty() || ns.isEmpty()) return
            maps.clear(); maps.addAll(nm); sps.clear(); sps.addAll(ns)
            gs = o.getInt("gs"); sx = o.getInt("sx"); sy = o.getInt("sy"); st = o.getInt("st"); cur = gs
            val fj = o.optJSONArray("fi"); val gj = o.optJSONArray("sg")
            if (fj != null && gj != null && fj.length() > 0 && gj.length() > 0) {
                fis.clear(); stgs.clear()
                for (i in 0 until fj.length()) {
                    val r = fj.getJSONObject(i); val z = Fi(r.getString("n"), r.getInt("hp"), r.getInt("spd"), r.getInt("pw"), r.getInt("kk"), r.getInt("sp"), r.getInt("c"))
                    val ib = r.optString("img", ""); if (ib.isNotEmpty()) { val by = Base64.decode(ib, Base64.NO_WRAP); z.img = BitmapFactory.decodeByteArray(by, 0, by.size) }
                    z.cs = r.optString("cs", "112"); z.cn = r.optString("cn", "Combo"); z.cd = r.optInt("cd", 20); fis.add(z)
                }
                for (i in 0 until gj.length()) { val r = gj.getJSONObject(i); stgs.add(Stg(r.getString("n"), r.getInt("sky"), r.getInt("gnd"))) }
                fp = o.optInt("fp", 0); fo = o.optInt("fo", 1); fs = o.optInt("fs", 0)
            }
            val mb = o.optString("music", "")
            if (mb.isNotEmpty()) File(act.filesDir, "music.dat").writeBytes(Base64.decode(mb, Base64.NO_WRAP))
        } catch (e: Exception) {}
    }

    // ---------- diálogos ----------
    fun box(vararg v: View) = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0); v.forEach { addView(it) } }
    fun lbl(s: String) = TextView(act).apply { text = s }
    fun ed(h: String, s: String = "", num: Boolean = false) = EditText(act).apply { hint = h; setText(s); if (num) inputType = InputType.TYPE_CLASS_NUMBER }
    fun spin(items: List<String>, sel: Int = 0) = Spinner(act).apply { adapter = ArrayAdapter(act, android.R.layout.simple_spinner_item, items); setSelection(sel) }
    fun ask(title: String, v: View, ok: () -> Unit) {
        AlertDialog.Builder(act).setTitle(title).setView(v)
            .setPositiveButton("Aceptar") { _, _ -> ok(); save(); invalidate() }.setNegativeButton("Cancelar", null).show()
    }
    fun live(o: Npc) = mode == 0 || o.k != 4 || "$cur:${o.x}:${o.y}" !in taken
    fun setImg(b: Bitmap?) {
        if (b == null) return; val sc = Bitmap.createScaledBitmap(b, 64, 64, true)
        if (pendKind == 0 && pendImg in sps.indices) sps[pendImg].img = sc else if (pendKind == 1 && pendImg in fis.indices) fis[pendImg].img = sc
        save(); invalidate()
    }
    fun music(on: Boolean) {
        try {
            mp?.release(); mp = null; val f = File(act.filesDir, "music.dat")
            if (on && f.exists()) mp = MediaPlayer().apply { setDataSource(f.path); isLooping = true; prepare(); start() }
        } catch (e: Exception) { mp = null }
    }
    fun remap(f: (Npc) -> Npc?) { maps.forEach { g -> val l = g.o.mapNotNull(f); g.o.clear(); g.o.addAll(l) } }
    fun delMap(i: Int) {
        if (maps.size < 2) return
        remap { if (it.k == 3 && it.tm == i) null else if (it.k == 3 && it.tm > i) Npc(it.x, it.y, 3, it.s, it.cr, it.tm - 1, it.tx, it.ty) else it }
        maps.removeAt(i)
        if (gs == i) { gs = 0; sx = 2; sy = 2 } else if (gs > i) gs--
        cur = gs
    }
    fun delSp(i: Int) {
        if (sps.size < 2) return
        remap { if (it.k == 1 && it.cr == i) Npc(it.x, it.y, 1, it.s, 0, it.tm, it.tx, it.ty) else if (it.k == 1 && it.cr > i) Npc(it.x, it.y, 1, it.s, it.cr - 1, it.tm, it.tx, it.ty) else it }
        maps.forEach { g -> val ne = g.enc.filter { it != i }.map { if (it > i) it - 1 else it }; g.enc.clear(); g.enc.addAll(ne) }
        sps.removeAt(i)
        sps.forEach { if (it.evTo == i) it.evTo = -1 else if (it.evTo > i) it.evTo-- }
        if (st == i) st = 0 else if (st > i) st--
    }
    fun mvDlg(s: Sp) {
        val l = s.mv.map { "${it.n} (${tn[it.ty]}, poder ${it.pw})" } + (if (s.mv.size < 4) listOf("➕ Nuevo ataque") else emptyList<String>())
        AlertDialog.Builder(act).setTitle("Ataques de ${s.n}").setItems(l.toTypedArray()) { _, i ->
            if (i == s.mv.size) s.mv.add(Mv("Ataque", 0, 10)); editMv(s, i)
        }.show()
    }
    fun editMv(s: Sp, i: Int) {
        val v = s.mv[i]; val n = ed("Nombre", v.n); val ty = spin(tn, v.ty); val pw = ed("Poder (1-40)", v.pw.toString(), true)
        val del = CheckBox(act).apply { text = "Borrar este ataque" }
        ask("Ataque", box(n, lbl("Tipo"), ty, lbl("Poder"), pw, del)) {
            if (del.isChecked) s.mv.removeAt(i) else { v.n = n.text.toString(); v.ty = ty.selectedItemPosition; v.pw = (pw.text.toString().toIntOrNull() ?: 10).coerceIn(1, 40) }
        }
    }
    fun bagDlg() {
        val ks = bag.keys.filter { (bag[it] ?: 0) > 0 }
        if (ks.isEmpty()) { msg = "Tu mochila está vacía."; if (mode == 2) bmsg = msg; invalidate(); return }
        AlertDialog.Builder(act).setTitle("Mochila").setItems(ks.map { "${items[it]} x${bag[it]}" }.toTypedArray()) { _, i -> useItem(ks[i]); invalidate() }.show()
    }
    fun useItem(k: Int) {
        val me = team[ai]; val f = foe
        if (k == 2) { if (f != null && foeNpc == null) fight("ball") else msg = "La Bola Pro solo sirve contra criaturas salvajes."; return }
        if (me.hp >= me.max) { msg = "Ya tiene la vida completa."; if (f != null) bmsg = msg; return }
        bag[k] = (bag[k] ?: 1) - 1; me.hp = minOf(me.max, me.hp + (if (k == 0) 25 else 60))
        if (f != null) { bmsg = "Usaste ${items[k]}."; foeTurn(f) } else msg = "${me.sp.n} recuperó vida."
    }
    fun teamDlg() {
        AlertDialog.Builder(act).setTitle("Equipo").setItems(team.map { "${it.sp.n} Nv.${it.lv}  ${it.hp}/${it.max}" }.toTypedArray()) { _, i ->
            if (team[i].hp > 0 && i != ai) { ai = i; val f = foe; if (f != null) { bmsg = "¡Sale ${team[i].sp.n}!"; foeTurn(f) } else msg = "${team[i].sp.n} va primero." }
            invalidate()
        }.show()
    }
    // ---------- peleas 2D ----------
    fun fightMenu() {
        AlertDialog.Builder(act).setTitle("Juego de peleas").setItems(arrayOf("▶ Probar pelea", "Luchadores…", "Escenarios…")) { _, i ->
            if (i == 0) pickFight() else if (i == 1) fiDlg() else stDlg()
            invalidate()
        }.show()
    }
    fun pick(t: String, l: List<String>, ok: (Int) -> Unit) {
        AlertDialog.Builder(act).setTitle(t).setItems(l.toTypedArray()) { _, i -> ok(i) }.setNegativeButton("Cancelar", null).show()
    }
    fun pickFight() {
        pick("Elige tu luchador", fis.map { it.n }) { a ->
            fp = a
            pick("Elige al rival", fis.map { it.n } + "🎲 Al azar") { b ->
                fo = if (b == fis.size) Random.nextInt(fis.size) else b
                pick("Elige el escenario", stgs.map { it.n } + "🎲 Al azar") { k -> fs = if (k == stgs.size) Random.nextInt(stgs.size) else k; fightStart() }
            }
        }
    }
    fun fiDlg() {
        val l = fis.map { it.n } + "➕ Nuevo luchador"
        AlertDialog.Builder(act).setTitle("Luchadores").setItems(l.toTypedArray()) { _, i ->
            if (i == fis.size) fis.add(Fi("Nuevo", 100, 5, 8, 12, 25, 2)); editFi(minOf(i, fis.size - 1))
        }.show()
    }
    fun editFi(i: Int) {
        val f = fis[i]
        val n = ed("Nombre", f.n); val hp = ed("Vida", f.hp.toString(), true); val sv = ed("Velocidad", f.spd.toString(), true)
        val a = ed("Puño", f.pw.toString(), true); val b = ed("Patada", f.kk.toString(), true); val s3 = ed("Especial", f.sp.toString(), true)
        val co = spin(fcn, f.c)
        val c1 = CheckBox(act).apply { text = "Es mi luchador"; isChecked = fp == i }
        val c2 = CheckBox(act).apply { text = "Es el rival"; isChecked = fo == i }
        val bi = Button(act).apply { text = "Elegir imagen…"; setOnClickListener { pendKind = 1; pendImg = i
            act.startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), 3) } }
        val bd = CheckBox(act).apply { text = "Borrar este luchador" }
        val cs = ed("Combo", f.cs); val cn = ed("Nombre del combo", f.cn); val cd = ed("Daño extra", f.cd.toString(), true)
        ask("Luchador", ScrollView(act).apply { addView(box(lbl("Nombre"), n, lbl("Vida (30-300)"), hp, lbl("Velocidad (1-10)"), sv, lbl("Daño de puño"), a,
            lbl("Daño de patada"), b, lbl("Daño del especial (se carga al golpear)"), s3, lbl("Combo: golpes en cadena (1=puño 2=patada 3=especial), ej. 112"), cs, lbl("Nombre del combo"), cn, lbl("Daño extra del combo"), cd, lbl("Color"), co, c1, c2, bi, bd)) }) {
            if (bd.isChecked) {
                if (fis.size > 1) { fis.removeAt(i); fp = if (fp == i) 0 else if (fp > i) fp - 1 else fp; fo = if (fo == i) 0 else if (fo > i) fo - 1 else fo }
                return@ask
            }
            f.n = n.text.toString(); f.hp = (hp.text.toString().toIntOrNull() ?: 100).coerceIn(30, 300); f.spd = (sv.text.toString().toIntOrNull() ?: 5).coerceIn(1, 10)
            f.pw = (a.text.toString().toIntOrNull() ?: 8).coerceIn(1, 60); f.kk = (b.text.toString().toIntOrNull() ?: 12).coerceIn(1, 60)
            f.sp = (s3.text.toString().toIntOrNull() ?: 25).coerceIn(1, 100); f.c = co.selectedItemPosition
            f.cs = cs.text.toString().filter { it in '1'..'3' }; f.cn = cn.text.toString(); f.cd = (cd.text.toString().toIntOrNull() ?: 20).coerceIn(0, 100)
            if (c1.isChecked) fp = i; if (c2.isChecked) fo = i
        }
    }
    fun stDlg() {
        val l = stgs.map { it.n } + "➕ Nuevo escenario"
        AlertDialog.Builder(act).setTitle("Escenarios").setItems(l.toTypedArray()) { _, i ->
            if (i == stgs.size) stgs.add(Stg("Nuevo", 8, 9))
            val k = minOf(i, stgs.size - 1); val g = stgs[k]
            val n = ed("Nombre", g.n); val sk = spin(fcn, g.sky); val gr = spin(fcn, g.gnd)
            val c1 = CheckBox(act).apply { text = "Usar este escenario"; isChecked = fs == k }
            val bd = CheckBox(act).apply { text = "Borrar este escenario" }
            ask("Escenario", box(lbl("Nombre"), n, lbl("Color del fondo"), sk, lbl("Color del suelo"), gr, c1, bd)) {
                if (bd.isChecked) { if (stgs.size > 1) { stgs.removeAt(k); fs = if (fs == k) 0 else if (fs > k) fs - 1 else fs }; return@ask }
                g.n = n.text.toString(); g.sky = sk.selectedItemPosition; g.gnd = gr.selectedItemPosition; if (c1.isChecked) fs = k
            }
        }.show()
    }
    fun fightStart() { pw = 0; ew = 0; held.clear(); pressed.clear(); newRound(); mode = 3; music(true) }
    fun newRound() {
        pf = Fg(fis[fp.coerceIn(0, fis.size - 1)], 3f); ef = Fg(fis[fo.coerceIn(0, fis.size - 1)], 13f); over = 0; rt = 60; rmsg = "¡Pelea!"
    }
    fun fightEnd() { mode = 0; music(false); held.clear(); pressed.clear(); invalidate() }
    fun fightTouch(e: MotionEvent) {
        val a = e.actionMasked; val up = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL
        val now = mutableSetOf<String>()
        if (!up) for (i in 0 until e.pointerCount) {
            if (a == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
            btns.firstOrNull { it.r.contains(e.getX(i), e.getY(i)) }?.let { now.add(it.id) }
        }
        val newly = now - held; held.clear(); held.addAll(now)
        if ("fx" in newly) { fightEnd(); return }
        pressed.addAll(newly)
    }
    fun step(g: Fg, o: Fg, left: Boolean, right: Boolean, jump: Boolean, blk: Boolean, a1: Boolean, a2: Boolean, a3: Boolean, a4: Boolean = false) {
        g.face = if (o.x > g.x) 1 else -1; g.mv = false
        if (g.stun > 0) g.stun--
        if (g.fx > 0) g.fx--
        if (g.cw > 0) { g.cw--; if (g.cw == 0) { g.seq = ""; g.cmb = 0 } }
        val free = g.stun == 0 && g.atk == 0
        if (free || (g.stun == 0 && g.atk in 1..2 && g.hit)) {
            if (free) {
                val v = 0.04f + g.f.spd * 0.012f
                if (left) { g.x -= v; g.mv = true }
                if (right) { g.x += v; g.mv = true }
                if (jump && g.y == 0f) g.vy = 0.3f
                g.blk = blk && g.y == 0f
            }
            val k = if (a1) 1 else if (a2) 2 else if (a3 && g.en >= 50) 3 else if (a4) 4 else 0
            if (k > 0) { g.atk = k; g.at = 0; g.hit = false; g.blk = false; if (k == 3) g.en -= 50 }
        } else g.blk = false
        if (g.y > 0f || g.vy > 0f) { g.y += g.vy; g.vy -= 0.03f; if (g.y <= 0f) { g.y = 0f; g.vy = 0f } }
        g.x = g.x.coerceIn(0.8f, W - 0.8f)
        if (g.atk > 0) {
            g.at++
            val dur = intArrayOf(0, 10, 16, 24, 20)[g.atk]; val hf = intArrayOf(0, 4, 7, 10, 6)[g.atk]
            if (g.at == hf && !g.hit) {
                val rng = floatArrayOf(0f, 1.5f, 2f, 3.2f, 1.2f)[g.atk]; val dm = intArrayOf(0, g.f.pw, g.f.kk, g.f.sp, g.f.kk + 4)[g.atk]
                val near = abs(o.x - g.x) <= rng && (o.x - g.x) * g.face >= 0
                val ok = if (g.atk == 4) near && o.y < 0.3f && g.y < 0.3f else near && abs(o.y - g.y) < 1.5f
                if (ok) {
                    g.hit = true; val guard = o.blk && g.atk != 4; var d = if (guard) maxOf(1, dm / 5) else dm
                    if (!guard) {
                        g.cmb++; g.cw = 24; g.seq += g.atk
                        if (g.f.cs.isNotEmpty() && g.seq.endsWith(g.f.cs)) { d += g.f.cd; g.seq = ""; cmsg = "¡${g.f.cn}!"; ct = 70 }
                        o.stun = if (g.atk == 4) 26 else 14; o.atk = 0; o.at = 0; o.cw = 0; o.seq = ""; o.cmb = 0; o.fx = 8
                        o.x += g.face * (if (g.atk == 4) 1.6f else 0.4f); if (g.atk == 4) o.vy = 0.25f
                    }
                    o.hp = maxOf(0, o.hp - d)
                    g.en = minOf(100, g.en + 10); o.en = minOf(100, o.en + 6)
                }
            }
            if (g.at >= dur) { g.atk = 0; g.at = 0; g.hit = false }
        }
    }
    fun fightUpdate() {
        val pl = pf ?: return; val cp = ef ?: return
        frame++; if (ct > 0) ct--
        val pr = pressed.toSet(); pressed.clear()
        if (rt > 0) {
            rt--; if (rt == 0) rmsg = ""
            step(pl, cp, false, false, false, false, false, false, false); step(cp, pl, false, false, false, false, false, false, false); return
        }
        if (over > 0) {
            over--; step(pl, cp, false, false, false, false, false, false, false); step(cp, pl, false, false, false, false, false, false, false)
            if (over == 0) { if (pw >= 2 || ew >= 2) fightEnd() else newRound() }
            return
        }
        step(pl, cp, "fl" in held, "fr" in held, "fj" in pr, "fb" in held, "f1" in pr, "f2" in pr, "f3" in pr, "f4" in pr)
        val d = abs(cp.x - pl.x); var cl = false; var cr = false; var cj = false; var k1 = false; var k2 = false; var k3 = false; var k4 = false
        if (cp.bt > 0) cp.bt--
        if (d > 1.7f) { if (pl.x < cp.x) cl = true else cr = true }
        else { val r = Random.nextInt(100)
            if (r < 4) k1 = true else if (r < 7) k2 = true else if (r < 8 && cp.en >= 50) k3 = true else if (r < 11) cp.bt = 25 else if (r < 12) cj = true else if (r < 14) k4 = true }
        if (cp.cw > 0 && Random.nextInt(100) < 35) { val ch = cp.f.cs.getOrNull(cp.seq.length) ?: '1'; if (ch == '2') k2 = true else if (ch == '3') k3 = true else k1 = true }
        step(cp, pl, cl, cr, cj, cp.bt > 0, k1, k2, k3, k4)
        if (pl.hp <= 0 || cp.hp <= 0) {
            if (cp.hp <= 0) { pw++; rmsg = if (pw >= 2) "¡Ganaste el combate!" else "¡K.O.! Ganaste el round" }
            else { ew++; rmsg = if (ew >= 2) "Perdiste el combate" else "K.O. Perdiste el round" }
            over = 120
        }
    }
    fun drawFg(c: Canvas, g: Fg, gy: Float) {
        val f = g.face.toFloat(); val t = frame * 0.2f; val hip = gy - g.y * S
        val dur = intArrayOf(1, 10, 16, 24, 20)[g.atk]; val pr = if (g.atk > 0) g.at.toFloat() / dur else 0f
        val e = Math.sin(pr * Math.PI).toFloat()
        val ko = over > 0 && g.hp <= 0
        val bob = if (g.atk == 0 && !g.mv && g.stun == 0) Math.sin(t.toDouble()).toFloat() * S * .04f else 0f
        p.style = Paint.Style.FILL; p.color = Color.argb(70, 0, 0, 0)
        c.drawOval(RectF(g.x * S - S * .7f, gy - S * .12f, g.x * S + S * .7f, gy + S * .12f), p)
        c.save(); c.translate(0f, bob)
        if (g.atk == 1 || g.atk == 2 || g.atk == 4) c.translate(f * e * S * .5f, 0f)
        val tilt = if (ko) -85f * f else if (g.stun > 0) -14f * f else if (g.atk == 2) 10f * f * e else if (g.atk == 3) -6f * f * e else 0f
        c.rotate(tilt, g.x * S, hip)
        val img = g.f.img
        if (img != null) {
            val w = S * 1.2f; val h = S * 2.8f
            c.drawBitmap(img, null, RectF(g.x * S - w * .9f, hip - h, g.x * S + w * .9f, hip), p)
        } else {
            p.color = fch[g.f.c.coerceIn(0, 9)]; p.style = Paint.Style.STROKE; p.strokeWidth = S * .2f; p.strokeCap = Paint.Cap.ROUND
            val hx = g.x * S; val ll = S * 1.1f; val ty = hip - ll; val tt = ty - S * 1.0f
            val sw = if (g.mv) Math.sin(t * 2.0).toFloat() * S * .4f else 0f
            val kx = if (g.atk == 2) f * S * 1.2f * e else 0f
            c.drawLine(hx, ty, hx + f * S * .15f + sw + kx, if (g.atk == 2) ty + ll * (1f - .8f * e) else hip, p)
            c.drawLine(hx, ty, hx - f * S * .15f - sw, hip, p)
            c.drawLine(hx, ty, hx, tt, p)
            p.style = Paint.Style.FILL; c.drawCircle(hx, tt - S * .3f, S * .32f, p); p.style = Paint.Style.STROKE
            val sy = tt + S * .15f
            var ax = f * S * .5f; var ay = S * .5f; var bx = -f * S * .3f; var by = S * .5f
            if (g.atk == 1) { ax = f * S * (.5f + e); ay = S * .1f }
            if (g.atk == 3) { ax = f * S * (.5f + .8f * e); ay = S * .1f; bx = ax; by = S * .25f }
            if (g.atk == 4) { ax = f * S * (.5f + .7f * e); ay = S * .35f; bx = ax; by = S * .55f }
            if (g.blk) { ax = f * S * .45f; ay = -S * .4f; bx = ax; by = -S * .15f }
            if (g.stun > 0) { ax = -f * S * .5f; ay = S * .3f; bx = -f * S * .3f; by = S * .6f }
            c.drawLine(hx, sy, hx + ax, sy + ay, p); c.drawLine(hx, sy, hx + bx, sy + by, p)
            p.style = Paint.Style.FILL
        }
        c.restore()
        if (g.blk) { p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = Color.CYAN; c.drawCircle(g.x * S + f * S * .3f, hip - S * 1.5f, S * 1.4f, p); p.style = Paint.Style.FILL }
        if (g.atk == 3 && g.at >= 10) {
            val bx = g.x * S + f * (S + (g.at - 10) * S * .25f); val by = hip - S * 2.1f
            p.color = Color.YELLOW; c.drawCircle(bx, by, S * .5f, p); p.color = Color.WHITE; c.drawCircle(bx, by, S * .25f, p)
        }
        if (g.fx > 0) {
            val r = S * (.3f + (8 - g.fx) * .1f); p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = Color.WHITE
            c.drawCircle(g.x * S, hip - S * 1.8f, r, p); c.drawCircle(g.x * S, hip - S * 1.8f, r * .6f, p); p.style = Paint.Style.FILL
        }
    }
    fun drawFight(c: Canvas) {
        fightUpdate()
        if (mode != 3) { invalidate(); return }
        val st2 = stgs[fs.coerceIn(0, stgs.size - 1)]; val ah = S * H; val gy = ah * .82f
        c.drawColor(Color.parseColor("#1B1D1C")); p.style = Paint.Style.FILL
        p.color = fch[st2.sky.coerceIn(0, 9)]; c.drawRect(0f, 0f, width.toFloat(), gy, p)
        p.color = fch[st2.gnd.coerceIn(0, 9)]; c.drawRect(0f, gy, width.toFloat(), ah, p)
        val a = pf; val b = ef
        if (a != null && b != null) {
            drawFg(c, a, gy); drawFg(c, b, gy)
            p.textAlign = Paint.Align.LEFT; p.textSize = S * .55f; val bw = width * .42f
            p.color = Color.WHITE; c.drawText(a.f.n + " " + "●".repeat(pw), 10f, S * .6f, p)
            bar(c, 10f, S * .8f, bw, a.hp.toFloat() / a.f.hp)
            p.color = Color.YELLOW; c.drawRect(10f, S * 1.2f, 10f + bw * a.en / 100f, S * 1.35f, p)
            p.textAlign = Paint.Align.RIGHT; p.color = Color.WHITE; c.drawText(b.f.n + " " + "●".repeat(ew), width - 10f, S * .6f, p)
            bar(c, width - 10f - bw, S * .8f, bw, b.hp.toFloat() / b.f.hp)
            p.color = Color.YELLOW; c.drawRect(width - 10f - bw, S * 1.2f, width - 10f - bw + bw * b.en / 100f, S * 1.35f, p)
        }
        p.textAlign = Paint.Align.CENTER; p.color = Color.WHITE; p.textSize = S * 1.1f; c.drawText(rmsg, width / 2f, gy * .5f, p)
        p.textSize = S * .7f; p.color = Color.YELLOW
        pf?.let { if (it.cmb >= 2) c.drawText("${it.cmb} golpes", width * .25f, S * 2.2f, p) }
        ef?.let { if (it.cmb >= 2) c.drawText("${it.cmb} golpes", width * .75f, S * 2.2f, p) }
        if (ct > 0) { p.textSize = S * .9f; c.drawText(cmsg, width / 2f, S * 3.2f, p) }
        p.textSize = S * .6f
        btns.forEach { bt ->
            p.color = Color.parseColor(if (bt.id in held) "#2D6A4F" else "#33403A"); c.drawRoundRect(bt.r, 16f, 16f, p)
            p.color = Color.WHITE; c.drawText(bt.label, bt.r.centerX(), bt.r.centerY() + p.textSize / 3, p)
        }
        postInvalidateOnAnimation()
    }

    fun help() {
        AlertDialog.Builder(act).setTitle("Cómo crear tu juego").setMessage(
            "1) Elige un material (Pasto, Agua...) y pinta el mapa con el dedo.\n" +
            "2) Pinta HIERBA: ahí salen criaturas.\n" +
            "3) NPC pone personajes que hablan, Entrenad. pone rivales y Curand. cura tu equipo.\n" +
            "4) Puerta conecta mapas (casas, cuevas). Crea mapas en Mapas.\n" +
            "5) En Criaturas haz las tuyas y marca cuáles salen en la hierba de cada mapa.\n" +
            "6) Inicio marca dónde empieza el jugador.\n" +
            "7) En Criaturas también pones ataques, evolución e imagen.\n" +
            "8) Objeto deja cosas en el mapa. Toca Jugar para probar. En Archivo exportas el juego y eliges música.\n" +
            "9) Peleas: crea luchadores (con su combo) y escenarios, y elige quién pelea antes de empezar.").setPositiveButton("Entendido", null).show()
    }
    fun mapsDlg() {
        val l = maps.map { it.name } + listOf("➕ Nuevo mapa", "✏ Renombrar este mapa", "🗑 Borrar este mapa")
        AlertDialog.Builder(act).setTitle("Mapas").setItems(l.toTypedArray()) { _, i ->
            if (i < maps.size) cur = i
            else if (i == maps.size) { val t = ed("Nombre", "Mapa ${maps.size + 1}"); ask("Nuevo mapa", box(t)) { maps.add(newMap(t.text.toString())); cur = maps.size - 1 } }
            else if (i == maps.size + 1) { val t = ed("Nombre", m.name); ask("Renombrar", box(t)) { m.name = t.text.toString() } }
            else if (maps.size > 1) AlertDialog.Builder(act).setMessage("¿Borrar el mapa ${m.name}?")
                .setPositiveButton("Sí") { _, _ -> delMap(cur); save(); invalidate() }.setNegativeButton("No", null).show()
            invalidate()
        }.show()
    }
    fun crDlg() {
        val l = sps.map { it.n } + "➕ Nueva criatura"
        AlertDialog.Builder(act).setTitle("Criaturas").setItems(l.toTypedArray()) { _, i ->
            if (i == sps.size) sps.add(Sp("Nueva", 0, 30, 8)); editCr(minOf(i, sps.size - 1))
        }.show()
    }
    fun editCr(i: Int) {
        val s = sps[i]
        val n = ed("Nombre", s.n); val ty = spin(tn, s.ty); val hp = ed("Vida", s.hp.toString(), true); val a = ed("Ataque", s.a.toString(), true)
        val c1 = CheckBox(act).apply { text = "Sale en la hierba de este mapa"; isChecked = i in m.enc }
        val c2 = CheckBox(act).apply { text = "Es mi criatura inicial"; isChecked = st == i }
        val ev = ed("Nivel de evolución (0 = no evoluciona)", s.evLv.toString(), true)
        val et = spin(sps.map { it.n }, if (s.evTo in sps.indices) s.evTo else 0)
        val bm = Button(act).apply { text = "Ataques…"; setOnClickListener { mvDlg(s) } }
        val bi = Button(act).apply { text = "Elegir imagen…"; setOnClickListener { pendKind = 0; pendImg = i
            act.startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), 3) } }
        val bd = CheckBox(act).apply { text = "Borrar esta criatura" }
        ask("Criatura", ScrollView(act).apply { addView(box(n, lbl("Tipo (Fuego > Planta > Agua > Fuego)"), ty, lbl("Vida"), hp, lbl("Ataque"), a, c1, c2, lbl("Evoluciona a:"), et, ev, bm, bi, bd)) }) {
            if (bd.isChecked) { delSp(i); return@ask }
            s.evLv = (ev.text.toString().toIntOrNull() ?: 0).coerceIn(0, 99); s.evTo = et.selectedItemPosition
            s.n = n.text.toString(); s.ty = ty.selectedItemPosition
            s.hp = (hp.text.toString().toIntOrNull() ?: 30).coerceIn(5, 200); s.a = (a.text.toString().toIntOrNull() ?: 8).coerceIn(3, 50)
            if (c1.isChecked) m.enc.add(i) else m.enc.remove(i)
            if (c2.isChecked) st = i
        }
    }
    fun fileDlg() {
        AlertDialog.Builder(act).setItems(arrayOf("Exportar juego (.json)", "Importar juego (.json)", "Nuevo juego (borra todo)", "Elegir música…", "Quitar música")) { _, i ->
            if (i == 0) act.startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json").putExtra(Intent.EXTRA_TITLE, "juego.json"), 1)
            else if (i == 1) act.startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 2)
            else if (i == 3) act.startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*"), 4)
            else if (i == 4) { File(act.filesDir, "music.dat").delete(); music(false) }
            else AlertDialog.Builder(act).setMessage("¿Borrar todo y empezar de cero?")
                .setPositiveButton("Sí") { _, _ -> def(); save(); invalidate() }.setNegativeButton("No", null).show()
        }.show()
    }
    fun place(x: Int, y: Int) {
        fun add(n: Npc) { m.o.removeAll { it.x == x && it.y == y }; m.o.add(n) }
        when (tool) {
            7 -> { val t = ed("Qué dice", "Hola, viajero."); ask("Personaje", box(t)) { add(Npc(x, y, 0, t.text.toString())) } }
            8 -> { val t = ed("Qué dice", "¡Pelea conmigo!"); val s = spin(sps.map { it.n })
                ask("Entrenador", box(t, lbl("Su criatura:"), s)) { add(Npc(x, y, 1, t.text.toString(), s.selectedItemPosition)) } }
            9 -> { val t = ed("Qué dice", "Tu equipo está curado."); ask("Curandero", box(t)) { add(Npc(x, y, 2, t.text.toString())) } }
            13 -> { val s = spin(items); ask("Objeto en el suelo", box(lbl("¿Qué objeto?"), s)) { add(Npc(x, y, 4, "", s.selectedItemPosition)) } }
            10 -> {
                val s = spin(maps.map { it.name }); val ex = ed("X destino (0-15)", "8", true); val ey = ed("Y destino (0-11)", "6", true)
                val cb = CheckBox(act).apply { text = "Crear puerta de regreso"; isChecked = true }
                ask("Puerta: ¿a qué mapa lleva?", box(s, ex, ey, cb)) {
                    val tm = s.selectedItemPosition
                    val tx = (ex.text.toString().toIntOrNull() ?: 1).coerceIn(0, W - 1); val ty = (ey.text.toString().toIntOrNull() ?: 1).coerceIn(0, H - 1)
                    add(Npc(x, y, 3, "", 0, tm, tx, ty))
                    if (cb.isChecked) { val d = maps[tm]; d.o.removeAll { it.x == tx && it.y == ty }; d.o.add(Npc(tx, ty, 3, "", 0, cur, x, y)) }
                }
            }
        }
    }

    // ---------- pantalla ----------
    fun layout() {
        val top = S * H + 16f; val area = height - top; val l = mutableListOf<Btn>()
        fun cell(id: String, lb: String, c: Int, r: Int, cols: Int, rows: Int) {
            val cw = width.toFloat() / cols; val rh = area / rows
            l.add(Btn(id, lb, RectF(c * cw + 4, top + r * rh + 4, (c + 1) * cw - 4, top + (r + 1) * rh - 4)))
        }
        when (mode) {
            0 -> {
                names.forEachIndexed { i, s -> cell("t$i", s, i % 5, 1 + i / 5, 5, 5) }
                listOf("play" to "Jugar", "maps" to "Mapas", "cr" to "Criaturas", "help" to "Ayuda", "file" to "Archivo", "fight" to "Peleas")
                    .forEachIndexed { i, (a, b) -> cell(a, b, i, 4, 6, 5) }
            }
            3 -> {
                cell("fl", "←", 0, 0, 5, 2); cell("fr", "→", 1, 0, 5, 2); cell("fj", "↑", 2, 0, 5, 2); cell("fb", "Bloq.", 3, 0, 5, 2); cell("f4", "Agarre", 4, 0, 5, 2)
                cell("f1", "Puño", 0, 1, 5, 2); cell("f2", "Patada", 1, 1, 5, 2); cell("f3", "Especial", 2, 1, 5, 2); cell("fx", "Salir", 4, 1, 5, 2)
            }
            1 -> { cell("u", "↑", 1, 1, 3, 4); cell("l", "←", 0, 2, 3, 4); cell("A", "A", 1, 2, 3, 4)
                cell("r", "→", 2, 2, 3, 4); cell("d", "↓", 1, 3, 3, 4); cell("edit", "Editar", 0, 3, 3, 4); cell("team", "Equipo", 0, 1, 3, 4); cell("bag", "Mochila", 2, 1, 3, 4) }
            else -> {
                team[ai].sp.mvs().take(4).forEachIndexed { i, v -> cell("m$i", v.n, i, 1, 4, 3) }
                cell("cap", "Capturar", 0, 2, 4, 3); cell("sw", "Cambiar", 1, 2, 4, 3); cell("bag", "Mochila", 2, 2, 4, 3); cell("run", "Huir", 3, 2, 4, 3)
            }
        }
        btns = l
    }
    fun wrap(c: Canvas, s: String, x: Float, y: Float, maxW: Float, lh: Float) {
        var i = 0; var yy = y
        while (i < s.length) { val n = maxOf(1, p.breakText(s, i, s.length, true, maxW, null)); c.drawText(s, i, i + n, x, yy, p); i += n; yy += lh }
    }
    fun bar(c: Canvas, x: Float, y: Float, w: Float, f: Float) {
        p.color = Color.DKGRAY; c.drawRect(x, y, x + w, y + S * .3f, p)
        p.color = Color.parseColor("#44CC44"); c.drawRect(x, y, x + w * f.coerceIn(0f, 1f), y + S * .3f, p)
    }

    override fun onDraw(c: Canvas) {
        S = width.toFloat() / W; layout()
        if (mode == 3) { drawFight(c); return }
        c.drawColor(Color.parseColor("#1B1D1C")); p.style = Paint.Style.FILL; p.textAlign = Paint.Align.LEFT
        for (y in 0 until H) for (x in 0 until W) {
            val v = m.t[y * W + x]; p.color = col[v]
            c.drawRect(x * S, y * S, (x + 1) * S, (y + 1) * S, p)
            if (v == 3) { p.color = Color.parseColor("#2A7A1A")
                c.drawRect(x * S + S * .2f, y * S + S * .3f, x * S + S * .35f, y * S + S * .8f, p)
                c.drawRect(x * S + S * .6f, y * S + S * .2f, x * S + S * .75f, y * S + S * .7f, p) }
        }
        m.o.filter { live(it) }.forEach {
            p.color = Color.parseColor(when (it.k) { 0 -> "#E0A030"; 1 -> "#7B1FA2"; 2 -> "#FF8FB1"; 4 -> "#FFD54F"; else -> "#212121" })
            c.drawRect(it.x * S + S * .15f, it.y * S + S * .1f, it.x * S + S * .85f, it.y * S + S * .9f, p)
        }
        if (mode != 0 || gs == cur) {
            p.color = Color.RED; val ax = if (mode == 0) sx else px; val ay = if (mode == 0) sy else py
            c.drawCircle((ax + .5f) * S, (ay + .5f) * S, S * .38f, p)
        }
        val f = foe
        if (mode == 2 && f != null) {
            val me = team[ai]
            p.color = Color.argb(215, 0, 0, 0); c.drawRect(0f, 0f, width.toFloat(), S * H, p)
            p.color = tc[f.sp.ty]; c.drawCircle(width * .7f, S * 3f, S * 1.5f, p)
            f.sp.img?.let { c.drawBitmap(it, null, RectF(width * .7f - S * 1.5f, S * 1.5f, width * .7f + S * 1.5f, S * 4.5f), p) }
            p.color = tc[me.sp.ty]; c.drawCircle(width * .3f, S * 8f, S * 1.5f, p)
            me.sp.img?.let { c.drawBitmap(it, null, RectF(width * .3f - S * 1.5f, S * 6.5f, width * .3f + S * 1.5f, S * 9.5f), p) }
            p.color = Color.WHITE; p.textSize = S * .7f
            c.drawText("${f.sp.n} Nv.${f.lv}", width * .45f, S * 1.2f, p); bar(c, width * .45f, S * 1.5f, width * .45f, f.hp.toFloat() / f.max)
            c.drawText("${me.sp.n} Nv.${me.lv} ${me.hp}/${me.max}", width * .05f, S * 5.7f, p); bar(c, width * .05f, S * 6f, width * .45f, me.hp.toFloat() / me.max)
        }
        p.color = Color.WHITE; p.textSize = S * .5f
        val top = S * H + S * .9f
        if (mode == 0) wrap(c, "Mapa: ${m.name}. ${hints[tool]}", 16f, top, width - 32f, S * .6f)
        if (mode == 1) wrap(c, msg, 16f, top, width - 32f, S * .6f)
        if (mode == 2) wrap(c, bmsg, 16f, top, width - 32f, S * .6f)
        p.textAlign = Paint.Align.CENTER; p.textSize = S * if (mode == 0) .5f else .6f
        btns.forEach { b ->
            p.color = Color.parseColor(if (mode == 0 && b.id == "t$tool") "#2D6A4F" else "#33403A")
            c.drawRoundRect(b.r, 16f, 16f, p)
            p.color = Color.WHITE; c.drawText(b.label, b.r.centerX(), b.r.centerY() + p.textSize / 3, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (mode == 3) { fightTouch(e); return true }
        val down = e.action == MotionEvent.ACTION_DOWN
        if (down) btns.firstOrNull { it.r.contains(e.x, e.y) }?.let { press(it.id); invalidate(); return true }
        if (mode == 0 && (down || e.action == MotionEvent.ACTION_MOVE) && e.y < S * H) {
            val x = (e.x / S).toInt(); val y = (e.y / S).toInt()
            if (x in 0 until W && y in 0 until H) {
                if (tool < 7) m.t[y * W + x] = tool
                else if (tool == 11) { gs = cur; sx = x; sy = y }
                else if (tool == 12) m.o.removeAll { it.x == x && it.y == y }
                else if (down) place(x, y)
                save(); invalidate()
            }
        }
        return true
    }

    // ---------- juego ----------
    fun press(id: String) {
        when (id) {
            "play" -> { mode = 1; cur = gs; px = sx; py = sy; beaten.clear(); taken.clear(); bag.clear(); bag[0] = 3; bag[2] = 1; ai = 0; music(true)
                val s = sps[st.coerceIn(0, sps.size - 1)]; team = mutableListOf(Cr(s, s.hp + 8, s.hp + 8)); msg = "Muévete con la cruz. A = hablar." }
            "edit" -> { mode = 0; cur = gs; music(false) }
            "maps" -> mapsDlg(); "cr" -> crDlg(); "help" -> help(); "file" -> fileDlg(); "fight" -> fightMenu()
            "u", "d", "l", "r" -> move(id)
            "A" -> talk()
            "m0", "m1", "m2", "m3", "cap", "run" -> fight(id)
            "sw", "team" -> teamDlg()
            "bag" -> bagDlg()
            else -> if (id.startsWith("t")) tool = id.substring(1).toInt()
        }
    }
    fun talk() {
        val n = m.o.firstOrNull { it.k != 3 && abs(it.x - px) + abs(it.y - py) == 1 }
        if (n == null) { msg = "No hay nadie cerca."; return }
        if (n.k == 2) { team.forEach { it.hp = it.max }; msg = n.s + " (Equipo curado)"; return }
        if (n.k == 1 && "$cur:${n.x}:${n.y}" !in beaten) { startBattle(sps[n.cr.coerceIn(0, sps.size - 1)], n, n.s); return }
        msg = if (n.k == 1) "Buen combate." else n.s
    }
    fun move(id: String) {
        var dx = 0; var dy = 0
        when (id) { "u" -> { dy = -1 }; "d" -> { dy = 1 }; "l" -> { dx = -1 }; else -> { dx = 1 } }
        val nx = px + dx; val ny = py + dy
        if (nx < 0 || ny < 0 || nx >= W || ny >= H) return
        val o = m.o.firstOrNull { it.x == nx && it.y == ny && live(it) }
        if (o != null && o.k != 3 && o.k != 4) return
        if (o == null && solid[m.t[ny * W + nx]]) return
        if (o != null && o.k == 3) { if (o.tm in maps.indices) { cur = o.tm; px = o.tx; py = o.ty }; return }
        if (o != null) { bag[o.cr] = (bag[o.cr] ?: 0) + 1; taken.add("$cur:${o.x}:${o.y}"); msg = "¡Encontraste ${items[o.cr.coerceIn(0, 2)]}!" }
        px = nx; py = ny
        if (m.t[py * W + px] == 3) {
            if (m.enc.isEmpty()) { msg = "Aquí no salen criaturas. Márcalas en Editar > Criaturas."; return }
            if (Random.nextInt(100) < 25) {
                val s = sps[m.enc.random().coerceIn(0, sps.size - 1)]; startBattle(s, null, "¡Apareció ${s.n} salvaje!")
            }
        }
    }
    fun startBattle(s: Sp, n: Npc?, intro: String) { val lv = maxOf(1, team[ai].lv + Random.nextInt(-1, 2)); val h = s.hp + (lv - 1) * 3; foe = Cr(s, h, h, lv); foeNpc = n; mode = 2; bmsg = intro }
    fun endBattle(m2: String) { foe = null; foeNpc = null; mode = 1; msg = m2 }
    fun mult(a: Int, d: Int) = if ((a == 1 && d == 3) || (a == 2 && d == 1) || (a == 3 && d == 2)) 1.5
        else if ((d == 1 && a == 3) || (d == 2 && a == 1) || (d == 3 && a == 2)) 0.5 else 1.0
    fun foeTurn(f: Cr) {
        val me = team[ai]; val v = f.sp.mvs().random()
        val d = maxOf(1, ((v.pw / 2 + f.sp.a / 2 + f.lv + Random.nextInt(0, 4)) * mult(v.ty, me.sp.ty)).toInt()); me.hp -= d
        bmsg += " ${f.sp.n} usó ${v.n}: $d de daño."
        if (me.hp <= 0) {
            me.hp = 0; val nx = team.indexOfFirst { it.hp > 0 }
            if (nx >= 0) { ai = nx; bmsg += " ¡Sale ${team[ai].sp.n}!" }
            else { team.forEach { it.hp = it.max }; ai = 0; cur = gs; px = sx; py = sy; endBattle("Tu equipo cayó. Vuelves al inicio.") }
        }
    }
    fun gain(me: Cr, f: Cr): String {
        var r = ""; me.xp += 4 * f.lv
        while (me.xp >= me.lv * 10) {
            me.xp -= me.lv * 10; me.lv++; me.max += 3; me.hp += 3; r += " ¡${me.sp.n} subió al nivel ${me.lv}!"
            val e = me.sp.evTo
            if (me.sp.evLv in 1..me.lv && e in sps.indices && sps[e] !== me.sp) { me.sp = sps[e]; me.max += 5; me.hp += 5; r += " ¡Evolucionó a ${me.sp.n}!" }
        }
        return r
    }
    fun fight(id: String) {
        val f = foe ?: return; val me = team[ai]
        if ((id == "cap" || id == "run" || id == "ball") && foeNpc != null) { bmsg = "¡No puedes huir ni capturar en combate de entrenador!"; return }
        if (id.startsWith("m")) {
            val v = me.sp.mvs().getOrNull(id.substring(1).toInt()) ?: return
            val mu = mult(v.ty, f.sp.ty); val d = maxOf(1, ((v.pw + me.sp.a / 2 + me.lv + Random.nextInt(-2, 3)) * mu).toInt()); f.hp -= d
            if (f.hp <= 0) { foeNpc?.let { beaten.add("$cur:${it.x}:${it.y}") }; endBattle("¡Ganaste!" + gain(me, f)) }
            else { bmsg = "${me.sp.n} usó ${v.n}: $d de daño." + (if (mu > 1) " ¡Muy eficaz!" else if (mu < 1) " No es muy eficaz." else ""); foeTurn(f) }
        } else if (id == "cap" || id == "ball") {
            if (id == "ball") { if ((bag[2] ?: 0) <= 0) { bmsg = "No tienes Bolas Pro."; return }; bag[2] = (bag[2] ?: 1) - 1 }
            if (Random.nextDouble() < 1.0 - 0.8 * f.hp / f.max + 0.1 + (if (id == "ball") 0.3 else 0.0)) { team.add(Cr(f.sp, f.max, f.max, f.lv)); endBattle("¡Capturaste a ${f.sp.n}! Equipo: ${team.size}") }
            else { bmsg = "Se escapó de la captura."; foeTurn(f) }
        } else endBattle("Huiste.")
    }
}
