package com.nocheraptor.game;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * Etapa 1: sala con cámara que se mueve arrastrando el dedo.
 *  - Puerta (izquierda): el raptor aparece en la oscuridad (solo se ven los ojos).
 *    Mantén el botón LUZ mientras miras la puerta para echarlo.
 *  - Rejilla del techo y rejilla de la pared derecha: solo avisan con sonido.
 *    (Provisional) toca la rejilla para cerrar su compuerta unos segundos.
 */
public class GameView extends View {

    // ===================== AJUSTES (fáciles de cambiar) =====================
    /** Tamaño de room.png con el que se midieron las zonas de abajo. */
    private static final float REF_W = 1672f, REF_H = 941f;
    private static final float ZOOM = 1.6f;              // cuánto se acerca la cámara a la sala
    private static final float HOUR_SECONDS = 45f;       // duración de cada "hora" de la noche
    private static final float FIRST_EVENT_DELAY = 10f;  // primer ataque (siempre por la puerta)
    private static final float STEPS_TIME = 2.6f;        // pasos antes de que aparezca en la puerta
    private static final float LIGHT_NEEDED = 1.2f;      // segundos de luz para echarlo
    private static final float HATCH_TIME = 6f;          // segundos que dura cerrada una compuerta
    /** Posición del ojo dentro de dino.png (fracción del ancho/alto). */
    private static final float EYE_FX = 0.790f, EYE_FY = 0.072f;

    // estados del juego
    private static final int S_TITLE = 0, S_PLAY = 1, S_JUMPSCARE = 2, S_OVER = 3, S_WIN = 4;
    // estados del raptor
    private static final int R_IDLE = 0, R_DOOR_STEPS = 1, R_DOOR_PRESENT = 2, R_DOOR_LEAVE = 3, R_VENT = 4;
    // entradas
    private static final int E_DOOR = 0, E_CEIL = 1, E_RIGHT = 2;

    private static final String[] HOURS = {"12 AM", "1 AM", "2 AM", "3 AM", "4 AM", "5 AM"};

    private final Random rnd = new Random();
    private final float density;

    // ---- imágenes ----
    private Bitmap room, dinoFull, dinoDoor;
    private float worldW = REF_W, worldH = REF_H;
    private int dinoW = 1, dinoH = 1;

    // ---- pantalla y cámara ----
    private int sw = 1, sh = 1;
    private float scale = 1f, visW = 1f, visH = 1f;
    private float camX, camY, velX, velY;

    // ---- zonas (coordenadas del mundo = píxeles de room.png) ----
    private final RectF doorRect = new RectF();
    private final RectF dinoRect = new RectF();
    private final RectF ceilTap = new RectF();
    private final RectF rightTap = new RectF();
    private final RectF tmpRect = new RectF();
    private final RectF jumpRect = new RectF();
    private final Path ceilPath = new Path();
    private final Path rightPath = new Path();
    private float aimWX, aimWY;     // punto de la cabeza del raptor en la puerta

    // ---- pinceles ----
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint dinoPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shutterFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shutterLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint eyePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint beamPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vignettePaint = new Paint();
    private final ColorMatrix cm = new ColorMatrix();
    private float eyeR = 46f;
    private float beamR = 600f;

    // ---- entrada táctil ----
    private int panPointer = -1, lightPointer = -1;
    private float lastX, lastY, downX, downY, moved;
    private long lastT, downT;
    private boolean lightOn;
    private float btnX, btnY, btnR;

    // ---- juego ----
    private int state = S_TITLE;
    private float stateTime;
    private float nightTime, hintTime;
    private final float[] hatchTimer = new float[2];
    private final float[] hatchAnim = new float[2];
    private float beamX, beamY;
    private boolean beamOnDoor;
    private float litLevel;

    // ---- raptor ----
    private int rs = R_IDLE;
    private float rTime, idleTimer, doorPatience, ventTime, lightAccum, doorAlpha;
    private boolean firstEvent = true;
    private int curEntrance = E_DOOR, lastEntrance = -1, sameCount;

    // ---- audio ----
    private SoundPool pool;
    private MediaPlayer ambient;
    private final Set<Integer> loaded = Collections.synchronizedSet(new HashSet<Integer>());
    private int sndSteps, sndVent, sndGrowl, sndScreech, sndClank, sndClick;
    private int ventStream;
    private float ventBaseL, ventBaseR;

    // ---- bucle ----
    private long lastNanos;
    private boolean paused;

    public GameView(Context ctx) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;
        room = loadAsset("img/room.png");
        dinoFull = loadAsset("img/dino.png");
        if (room != null) {
            worldW = room.getWidth();
            worldH = room.getHeight();
        }
        if (dinoFull != null) {
            dinoW = dinoFull.getWidth();
            dinoH = dinoFull.getHeight();
        }
        initPaints();
        layoutWorld();
        initAudio();
        resetGame();
        state = S_TITLE;
    }

    // =====================================================================
    //  Carga e inicialización
    // =====================================================================
    private Bitmap loadAsset(String name) {
        try (InputStream in = getContext().getAssets().open(name)) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            return BitmapFactory.decodeStream(in, null, o);
        } catch (IOException e) {
            return null;
        }
    }

    private void initPaints() {
        textPaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        shutterFill.setStyle(Paint.Style.FILL);
        shutterFill.setColor(0xFF1E2226);
        shutterLine.setStyle(Paint.Style.STROKE);
        shutterLine.setColor(0xFF0A0C0E);
        strokePaint.setStyle(Paint.Style.STROKE);
    }

    /** Convierte una coordenada de la imagen de referencia al mundo real. */
    private float wx(float refX) {
        return refX / REF_W * worldW;
    }

    private float wy(float refY) {
        return refY / REF_H * worldH;
    }

    private void layoutWorld() {
        // Puerta de la izquierda
        doorRect.set(wx(140f), wy(160f), wx(285f), wy(690f));

        // El raptor aparece de pie dentro de la puerta
        float dhWorld = wy(400f);
        float dwWorld = dhWorld * dinoW / dinoH;
        float left = doorRect.centerX() - dwWorld * 0.45f;
        float bottom = wy(700f);
        dinoRect.set(left, bottom - dhWorld, left + dwWorld, bottom);
        aimWX = dinoRect.left + EYE_FX * dinoRect.width();
        aimWY = dinoRect.top + EYE_FY * dinoRect.height();
        eyeR = wy(46f);

        // Rejilla del techo (trapecio)
        ceilPath.reset();
        ceilPath.moveTo(wx(640f), wy(25f));
        ceilPath.lineTo(wx(1025f), wy(25f));
        ceilPath.lineTo(wx(985f), wy(135f));
        ceilPath.lineTo(wx(685f), wy(135f));
        ceilPath.close();
        ceilTap.set(wx(600f), 0f, wx(1070f), wy(190f));

        // Rejilla de la pared derecha
        rightPath.reset();
        rightPath.addRect(wx(1398f), wy(172f), wx(1562f), wy(456f), Path.Direction.CW);
        rightTap.set(wx(1340f), wy(120f), wx(1620f), wy(520f));

        shutterLine.setStrokeWidth(wy(5f));

        // Resplandor del ojo
        eyePaint.setShader(new RadialGradient(0f, 0f, eyeR,
                new int[]{0xFFFFE070, 0x88FFC030, 0x00FFB000},
                new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
    }

    private void initAudio() {
        try {
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            pool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(aa).build();
            pool.setOnLoadCompleteListener((sp, id, status) -> {
                if (status == 0) loaded.add(id);
            });
            sndSteps = loadSnd("sounds/steps.wav");
            sndVent = loadSnd("sounds/vent_scratch.wav");
            sndGrowl = loadSnd("sounds/growl.wav");
            sndScreech = loadSnd("sounds/screech.wav");
            sndClank = loadSnd("sounds/clank.wav");
            sndClick = loadSnd("sounds/click.wav");
        } catch (Exception e) {
            pool = null;
        }
        try {
            AssetFileDescriptor afd = getContext().getAssets().openFd("sounds/ambient.wav");
            ambient = new MediaPlayer();
            ambient.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            ambient.setLooping(true);
            ambient.setVolume(0.30f, 0.30f);
            ambient.prepare();
        } catch (Exception e) {
            ambient = null;
        }
    }

    private int loadSnd(String path) {
        if (pool == null) return 0;
        try (AssetFileDescriptor afd = getContext().getAssets().openFd(path)) {
            return pool.load(afd, 1);
        } catch (IOException e) {
            return 0;
        }
    }

    private int play(int id, float l, float r, int loop, float rate) {
        if (pool == null || id == 0 || !loaded.contains(id)) return 0;
        return pool.play(id, l, r, 1, loop, rate);
    }

    private void stopVent() {
        if (ventStream != 0 && pool != null) pool.stop(ventStream);
        ventStream = 0;
    }

    // ---- ciclo de vida (lo llama MainActivity) ----
    public void onHostResume() {
        paused = false;
        lastNanos = 0;
        if (pool != null) pool.autoResume();
        if (ambient != null) {
            try {
                ambient.start();
            } catch (Exception ignored) {
            }
        }
        postInvalidateOnAnimation();
    }

    public void onHostPause() {
        paused = true;
        panPointer = -1;
        lightPointer = -1;
        lightOn = false;
        if (pool != null) pool.autoPause();
        if (ambient != null) {
            try {
                ambient.pause();
            } catch (Exception ignored) {
            }
        }
    }

    public void release() {
        try {
            if (pool != null) pool.release();
        } catch (Exception ignored) {
        }
        pool = null;
        try {
            if (ambient != null) ambient.release();
        } catch (Exception ignored) {
        }
        ambient = null;
    }

    // =====================================================================
    //  Tamaño de pantalla y cámara
    // =====================================================================
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        sw = Math.max(1, w);
        sh = Math.max(1, h);
        scale = ZOOM * Math.max(sw / worldW, sh / worldH);
        visW = sw / scale;
        visH = sh / scale;

        btnR = sh * 0.11f;
        btnX = sw - btnR * 1.5f - sh * 0.03f;
        btnY = sh - btnR * 1.5f - sh * 0.03f;
        beamR = sh * 0.62f;
        beamX = sw / 2f;
        beamY = sh / 2f;

        beamPaint.setShader(new RadialGradient(0f, 0f, beamR,
                new int[]{0x70FFF3CC, 0x38FFF3CC, 0x00FFF3CC},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        vignettePaint.setShader(new RadialGradient(sw / 2f, sh / 2f,
                (float) Math.hypot(sw, sh) / 2f,
                new int[]{0x00000000, 0x00000000, 0xB8000000},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));

        // Raptor de la puerta a la medida exacta en pantalla (se ve nítido)
        if (dinoFull != null) {
            int pw = Math.max(1, Math.round(dinoRect.width() * scale));
            int ph = Math.max(1, Math.round(dinoRect.height() * scale));
            dinoDoor = Bitmap.createScaledBitmap(dinoFull, pw, ph, true);
        }
        clampCam();
    }

    private float camLeft() {
        return camX - visW / 2f;
    }

    private float camTop() {
        return camY - visH / 2f;
    }

    private void clampCam() {
        float minX = visW / 2f, maxX = worldW - visW / 2f;
        float minY = visH / 2f, maxY = worldH - visH / 2f;
        if (camX < minX) {
            camX = minX;
            velX = 0f;
        }
        if (camX > maxX) {
            camX = maxX;
            velX = 0f;
        }
        if (camY < minY) {
            camY = minY;
            velY = 0f;
        }
        if (camY > maxY) {
            camY = maxY;
            velY = 0f;
        }
    }

    // =====================================================================
    //  Entrada táctil
    // =====================================================================
    private boolean inLightButton(float x, float y) {
        return Math.hypot(x - btnX, y - btnY) <= btnR * 1.35f;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();

        if (action == MotionEvent.ACTION_CANCEL) {
            panPointer = -1;
            lightPointer = -1;
            setLight(false);
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int id = e.getPointerId(idx);
                float x = e.getX(idx), y = e.getY(idx);
                if (state == S_TITLE) {
                    if (action == MotionEvent.ACTION_DOWN) startGame();
                } else if (state == S_OVER || state == S_WIN) {
                    if (action == MotionEvent.ACTION_DOWN && stateTime > 1f) startGame();
                } else if (state == S_PLAY) {
                    if (lightPointer == -1 && inLightButton(x, y)) {
                        lightPointer = id;
                        setLight(true);
                    } else if (panPointer == -1) {
                        panPointer = id;
                        lastX = x;
                        lastY = y;
                        downX = x;
                        downY = y;
                        moved = 0f;
                        downT = e.getEventTime();
                        lastT = downT;
                        velX = 0f;
                        velY = 0f;
                    }
                }
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                if (state == S_PLAY && panPointer != -1) {
                    int pi = e.findPointerIndex(panPointer);
                    if (pi >= 0) {
                        float x = e.getX(pi), y = e.getY(pi);
                        float dx = x - lastX, dy = y - lastY;
                        moved += (float) Math.hypot(dx, dy);
                        camX -= dx / scale;
                        camY -= dy / scale;
                        long t = e.getEventTime();
                        float dt = Math.max(1L, t - lastT) / 1000f;
                        velX = velX * 0.6f + 0.4f * (-dx / scale / dt);
                        velY = velY * 0.6f + 0.4f * (-dy / scale / dt);
                        lastT = t;
                        lastX = x;
                        lastY = y;
                        clampCam();
                    }
                }
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                int id = e.getPointerId(idx);
                if (id == lightPointer) {
                    lightPointer = -1;
                    setLight(false);
                }
                if (id == panPointer) {
                    panPointer = -1;
                    float x = e.getX(idx), y = e.getY(idx);
                    boolean isTap = moved < 14f * density && (e.getEventTime() - downT) < 400;
                    if (isTap && state == S_PLAY) handleTap(x, y);
                }
                break;
            }
            default:
                break;
        }
        return true;
    }

    private void setLight(boolean on) {
        if (state != S_PLAY) on = false;
        if (on && !lightOn) play(sndClick, 0.7f, 0.7f, 0, 1f);
        lightOn = on;
    }

    /** Toque corto: si cae sobre una rejilla, cierra su compuerta. */
    private void handleTap(float x, float y) {
        float wxp = camLeft() + x / scale;
        float wyp = camTop() + y / scale;
        if (ceilTap.contains(wxp, wyp)) closeHatch(0);
        else if (rightTap.contains(wxp, wyp)) closeHatch(1);
    }

    private void closeHatch(int v) {
        if (hatchTimer[v] > 0f) return;
        hatchTimer[v] = HATCH_TIME;
        if (v == 0) play(sndClank, 0.8f, 0.8f, 0, 0.8f);
        else play(sndClank, 0.35f, 0.9f, 0, 1f);
    }

    // =====================================================================
    //  Lógica
    // =====================================================================
    private void resetGame() {
        nightTime = 0f;
        hintTime = 0f;
        rs = R_IDLE;
        rTime = 0f;
        idleTimer = FIRST_EVENT_DELAY;
        firstEvent = true;
        sameCount = 0;
        lastEntrance = -1;
        hatchTimer[0] = 0f;
        hatchTimer[1] = 0f;
        hatchAnim[0] = 0f;
        hatchAnim[1] = 0f;
        lightOn = false;
        lightAccum = 0f;
        litLevel = 0f;
        doorAlpha = 0f;
        panPointer = -1;
        lightPointer = -1;
        velX = 0f;
        velY = 0f;
        camX = worldW * 0.5f;
        camY = worldH * 0.5f;
        stopVent();
        clampCam();
    }

    private void startGame() {
        resetGame();
        state = S_PLAY;
        stateTime = 0f;
    }

    private void update(float dt) {
        stateTime += dt;
        if (state == S_PLAY) {
            updatePlay(dt);
        } else if (state == S_JUMPSCARE) {
            if (stateTime >= 1.8f) {
                state = S_OVER;
                stateTime = 0f;
            }
        }
    }

    private void updatePlay(float dt) {
        nightTime += dt;
        hintTime += dt;
        if (nightTime >= 6f * HOUR_SECONDS) {
            winNight();
            return;
        }

        // Cámara con inercia
        if (panPointer == -1) {
            camX += velX * dt;
            camY += velY * dt;
            float damp = (float) Math.exp(-5.0 * dt);
            velX *= damp;
            velY *= damp;
            if (Math.abs(velX) < 2f) velX = 0f;
            if (Math.abs(velY) < 2f) velY = 0f;
        }
        clampCam();

        // Compuertas de las rejillas
        for (int i = 0; i < 2; i++) {
            if (hatchTimer[i] > 0f) hatchTimer[i] = Math.max(0f, hatchTimer[i] - dt);
            if (hatchTimer[i] > 0f) hatchAnim[i] = Math.min(1f, hatchAnim[i] + dt * 8f);
            else hatchAnim[i] = Math.max(0f, hatchAnim[i] - dt * 5f);
        }

        // Linterna: ¿la cabeza del raptor está en pantalla? Entonces el haz va hacia ella.
        float aimSx = (aimWX - camLeft()) * scale;
        float aimSy = (aimWY - camTop()) * scale;
        boolean aimInView = aimSx > sw * 0.08f && aimSx < sw * 0.75f
                && aimSy > sh * 0.10f && aimSy < sh * 0.90f;
        float tx = aimInView ? aimSx : sw / 2f;
        float ty = aimInView ? aimSy : sh / 2f;
        float k = Math.min(1f, dt * 10f);
        beamX += (tx - beamX) * k;
        beamY += (ty - beamY) * k;
        beamOnDoor = lightOn && aimInView;
        if (beamOnDoor) litLevel = Math.min(1f, litLevel + dt * 6f);
        else litLevel = Math.max(0f, litLevel - dt * 3f);

        updateRaptor(dt);
    }

    private int hourNow() {
        return Math.min(5, (int) (nightTime / HOUR_SECONDS));
    }

    private void updateRaptor(float dt) {
        int hour = hourNow();
        rTime += dt;

        switch (rs) {
            case R_IDLE:
                idleTimer -= dt;
                if (idleTimer <= 0f) startApproach(chooseEntrance(), hour);
                break;

            case R_DOOR_STEPS:
                if (rTime >= STEPS_TIME) {
                    rs = R_DOOR_PRESENT;
                    rTime = 0f;
                    lightAccum = 0f;
                }
                break;

            case R_DOOR_PRESENT:
                doorAlpha = Math.min(1f, doorAlpha + dt * 2.5f);
                if (beamOnDoor) lightAccum += dt;
                else lightAccum = Math.max(0f, lightAccum - 0.6f * dt);
                if (lightAccum >= LIGHT_NEEDED) {
                    rs = R_DOOR_LEAVE;
                    rTime = 0f;
                    play(sndGrowl, 0.9f, 0.4f, 0, 1f);
                } else if (rTime >= doorPatience) {
                    startJumpscare();
                }
                break;

            case R_DOOR_LEAVE:
                doorAlpha = Math.max(0f, doorAlpha - dt * 2.2f);
                if (rTime >= 0.9f) goIdle(hour);
                break;

            case R_VENT: {
                float p = Math.min(1f, rTime / ventTime);
                float vol = 0.25f + 0.75f * p;
                if (ventStream != 0 && pool != null) {
                    pool.setVolume(ventStream, ventBaseL * vol, ventBaseR * vol);
                }
                if (rTime >= ventTime) arriveAtVent(hour);
                break;
            }
            default:
                break;
        }
    }

    private int chooseEntrance() {
        if (firstEvent) {
            firstEvent = false;
            lastEntrance = E_DOOR;
            sameCount = 1;
            return E_DOOR;
        }
        float r = rnd.nextFloat();
        int e = r < 0.40f ? E_DOOR : (r < 0.70f ? E_CEIL : E_RIGHT);
        if (e == lastEntrance && sameCount >= 2) e = (e + 1 + rnd.nextInt(2)) % 3;
        if (e == lastEntrance) sameCount++;
        else sameCount = 1;
        lastEntrance = e;
        return e;
    }

    private void startApproach(int e, int hour) {
        curEntrance = e;
        rTime = 0f;
        if (e == E_DOOR) {
            rs = R_DOOR_STEPS;
            doorAlpha = 0f;
            doorPatience = Math.max(3.5f, 7.5f - 0.6f * hour);
            play(sndSteps, 0.9f, 0.35f, 0, 1f);
        } else {
            rs = R_VENT;
            ventTime = Math.max(5f, 9f - 0.7f * hour);
            float rate;
            if (e == E_RIGHT) {
                ventBaseL = 0.30f;
                ventBaseR = 1.00f;
                rate = 1.0f;
            } else {
                ventBaseL = 0.85f;
                ventBaseR = 0.85f;
                rate = 0.7f;
            }
            stopVent();
            ventStream = play(sndVent, ventBaseL * 0.25f, ventBaseR * 0.25f, -1, rate);
        }
    }

    private void arriveAtVent(int hour) {
        stopVent();
        int h = (curEntrance == E_CEIL) ? 0 : 1;
        if (hatchTimer[h] > 0f) {
            // La compuerta estaba cerrada: golpea y se va
            float l = (h == 0) ? 0.8f : 0.35f;
            float r = (h == 0) ? 0.8f : 0.95f;
            play(sndClank, l, r, 0, 1f);
            play(sndGrowl, l, r, 0, 0.85f);
            goIdle(hour);
        } else {
            startJumpscare();
        }
    }

    private void goIdle(int hour) {
        rs = R_IDLE;
        rTime = 0f;
        doorAlpha = 0f;
        idleTimer = Math.max(3.5f, 11f - 0.9f * hour) * (0.7f + rnd.nextFloat() * 0.6f);
    }

    private void startJumpscare() {
        stopVent();
        lightOn = false;
        panPointer = -1;
        lightPointer = -1;
        rs = R_IDLE;
        state = S_JUMPSCARE;
        stateTime = 0f;
        play(sndScreech, 1f, 1f, 0, 1f);
        vibrate(400);
    }

    private void winNight() {
        stopVent();
        lightOn = false;
        panPointer = -1;
        lightPointer = -1;
        state = S_WIN;
        stateTime = 0f;
    }

    @SuppressWarnings("deprecation")
    private void vibrate(int ms) {
        try {
            Vibrator v = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(ms);
            }
        } catch (Exception ignored) {
        }
    }

    // =====================================================================
    //  Dibujo
    // =====================================================================
    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 0f : (now - lastNanos) / 1e9f;
        lastNanos = now;
        if (dt > 0.05f) dt = 0.05f;
        if (!paused) update(dt);
        render(c);
        if (!paused) postInvalidateOnAnimation();
    }

    private void render(Canvas c) {
        c.drawColor(Color.BLACK);
        if (room == null) {
            textPaint.setTextAlign(Paint.Align.CENTER);
            drawCentered(c, "Falta assets/img/room.png", sw / 2f, sh / 2f, sh * 0.05f, Color.WHITE);
            return;
        }

        float shakeX = 0f, shakeY = 0f;
        if (state == S_JUMPSCARE) {
            float k = Math.max(0f, 1f - stateTime / 1.6f);
            shakeX = (rnd.nextFloat() - 0.5f) * 2f * sh * 0.03f * k;
            shakeY = (rnd.nextFloat() - 0.5f) * 2f * sh * 0.03f * k;
        }

        c.save();
        c.translate(shakeX, shakeY);

        // --- mundo ---
        c.save();
        c.scale(scale, scale);
        c.translate(-camLeft(), -camTop());
        c.drawBitmap(room, 0f, 0f, bmpPaint);
        drawHatch(c, ceilPath, hatchAnim[0]);
        drawHatch(c, rightPath, hatchAnim[1]);
        drawDoorRaptor(c);
        c.restore();

        // --- linterna ---
        if (lightOn && state == S_PLAY) {
            beamPaint.setAlpha((int) (255 * (0.80f + 0.20f * rnd.nextFloat())));
            c.save();
            c.translate(beamX, beamY);
            c.drawCircle(0f, 0f, beamR, beamPaint);
            c.restore();
        }

        // --- susto ---
        if (state == S_JUMPSCARE && dinoFull != null) drawJumpscare(c);

        c.restore();

        // viñeta
        c.drawRect(0f, 0f, sw, sh, vignettePaint);

        if (state == S_PLAY) drawHud(c);
        else if (state == S_TITLE) drawTitle(c);
        else if (state == S_OVER) drawGameOver(c);
        else if (state == S_WIN) drawWin(c);
    }

    private void drawHatch(Canvas c, Path p, float a) {
        if (a <= 0.01f) return;
        int al = (int) (235 * a);
        shutterFill.setAlpha(al);
        c.drawPath(p, shutterFill);
        c.save();
        c.clipPath(p);
        p.computeBounds(tmpRect, true);
        shutterLine.setAlpha(al);
        float step = tmpRect.height() / 6f;
        for (float y = tmpRect.top + step * 0.5f; y < tmpRect.bottom; y += step) {
            c.drawLine(tmpRect.left, y, tmpRect.right, y, shutterLine);
        }
        c.restore();
    }

    private void drawDoorRaptor(Canvas c) {
        if (doorAlpha <= 0.01f || dinoDoor == null) return;

        // Sin luz: casi negro. Con luz: se ve completo.
        float bright = 0.10f + 0.90f * litLevel;
        cm.setScale(bright, bright, bright, 1f);
        dinoPaint.setColorFilter(new ColorMatrixColorFilter(cm));
        dinoPaint.setAlpha((int) (255 * doorAlpha));
        c.drawBitmap(dinoDoor, null, dinoRect, dinoPaint);

        // Ojo brillante en la oscuridad
        float pulse = 0.75f + 0.25f * (float) Math.sin(nightTime * 9f);
        float a = doorAlpha * pulse * (1f - 0.65f * litLevel);
        eyePaint.setAlpha((int) (255 * Math.max(0f, Math.min(1f, a))));
        c.save();
        c.translate(aimWX, aimWY);
        c.drawCircle(0f, 0f, eyeR, eyePaint);
        c.restore();
    }

    private void drawJumpscare(Canvas c) {
        c.drawColor(0xB0000000);
        float k = Math.min(1f, stateTime / 0.16f);
        float dh = sh * (0.7f + 0.8f * k);
        float dw = dh * dinoW / dinoH;
        float jx = (rnd.nextFloat() - 0.5f) * sh * 0.03f;
        float jy = (rnd.nextFloat() - 0.5f) * sh * 0.03f;
        // Colocamos el ojo cerca del centro de la pantalla
        float left = sw * 0.52f - EYE_FX * dw + jx;
        float top = sh * 0.32f - EYE_FY * dh + jy;
        jumpRect.set(left, top, left + dw, top + dh);
        c.drawBitmap(dinoFull, null, jumpRect, bmpPaint);
        if (((int) (stateTime * 18f)) % 2 == 0) c.drawColor(0x40FF0000);
    }

    private void drawHud(Canvas c) {
        float pad = sh * 0.05f;
        int hour = hourNow();

        // Reloj
        textPaint.setTextAlign(Paint.Align.RIGHT);
        textPaint.setShadowLayer(8f, 0f, 0f, Color.BLACK);
        textPaint.setTextSize(sh * 0.075f);
        textPaint.setColor(0xFFE8E8E8);
        c.drawText(HOURS[hour], sw - pad, pad + sh * 0.075f, textPaint);
        textPaint.setTextSize(sh * 0.035f);
        textPaint.setColor(0xFF9AA0A6);
        c.drawText("NOCHE 1", sw - pad, pad + sh * 0.075f + sh * 0.05f, textPaint);

        // Botón de luz
        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setColor(lightOn ? 0xEEEED17A : 0x88000000);
        c.drawCircle(btnX, btnY, btnR, fillPaint);
        strokePaint.setStrokeWidth(sh * 0.006f);
        strokePaint.setColor(0xCCFFFFFF);
        c.drawCircle(btnX, btnY, btnR, strokePaint);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(sh * 0.05f);
        textPaint.setColor(lightOn ? 0xFF222222 : 0xFFFFFFFF);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
        c.drawText("LUZ", btnX, btnY + sh * 0.018f, textPaint);

        // Pistas de los primeros segundos
        if (hintTime < 9f) {
            float alpha = hintTime < 7f ? 1f : (9f - hintTime) / 2f;
            textPaint.setShadowLayer(8f, 0f, 0f, Color.BLACK);
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTextSize(sh * 0.04f);
            textPaint.setColor(0xFFFFFFFF);
            textPaint.setAlpha((int) (255 * alpha));
            c.drawText("Arrastra para mirar alrededor", sw / 2f, sh * 0.88f, textPaint);
            textPaint.setTextSize(sh * 0.032f);
            c.drawText("Mantén LUZ para alumbrar  ·  Toca una rejilla para cerrarla",
                    sw / 2f, sh * 0.94f, textPaint);
            textPaint.setAlpha(255);
        }
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
    }

    private void drawTitle(Canvas c) {
        c.drawColor(0xCC000000);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
        textPaint.setTextAlign(Paint.Align.CENTER);
        drawCentered(c, "NOCHE RAPTOR", sw / 2f, sh * 0.38f, sh * 0.13f, 0xFFDDE8C0);
        drawCentered(c, "(título provisional)", sw / 2f, sh * 0.46f, sh * 0.035f, 0xFF8A9A7A);
        if ((System.nanoTime() / 600000000L) % 2 == 0) {
            drawCentered(c, "Toca para empezar", sw / 2f, sh * 0.64f, sh * 0.06f, Color.WHITE);
        }
        drawCentered(c, "Arrastra para mirar  ·  Mantén LUZ para echarlo de la puerta",
                sw / 2f, sh * 0.80f, sh * 0.032f, 0xFFB0B0B0);
        drawCentered(c, "Si oyes algo en las rejillas, tócalas para cerrarlas",
                sw / 2f, sh * 0.86f, sh * 0.032f, 0xFFB0B0B0);
    }

    private void drawGameOver(Canvas c) {
        c.drawColor(0xCC200000);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
        textPaint.setTextAlign(Paint.Align.CENTER);
        drawCentered(c, "TE ATRAPARON", sw / 2f, sh * 0.45f, sh * 0.13f, 0xFFE03030);
        if (stateTime > 1f) {
            drawCentered(c, "Toca para reintentar", sw / 2f, sh * 0.62f, sh * 0.06f, Color.WHITE);
        }
    }

    private void drawWin(Canvas c) {
        c.drawColor(0xCC000000);
        textPaint.setShadowLayer(0f, 0f, 0f, 0);
        textPaint.setTextAlign(Paint.Align.CENTER);
        drawCentered(c, "6 AM", sw / 2f, sh * 0.42f, sh * 0.18f, 0xFFEED17A);
        drawCentered(c, "¡Sobreviviste la noche 1!", sw / 2f, sh * 0.58f, sh * 0.06f, Color.WHITE);
        if (stateTime > 1f) {
            drawCentered(c, "Toca para jugar otra vez", sw / 2f, sh * 0.70f, sh * 0.04f, 0xFFB0B0B0);
        }
    }

    private void drawCentered(Canvas c, String s, float cx, float cy, float size, int color) {
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(size);
        textPaint.setColor(color);
        c.drawText(s, cx, cy, textPaint);
    }
}
