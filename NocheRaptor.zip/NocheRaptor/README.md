# Noche Raptor (título provisional) – Etapa 1
Juego nativo Android (Java + Canvas). Sin internet, sin WebView.

- Arrastra para mover la cámara. Mantén LUZ para alumbrar la puerta (izquierda).
- Rejilla del techo y de la pared derecha: avisan solo con sonido; toca la rejilla para cerrar su compuerta (provisional).
- Ajustes rápidos al inicio de GameView.java (duración de la noche, tiempos, posición del raptor...).
- Imágenes en app/src/main/assets/img, sonidos en app/src/main/assets/sounds.
