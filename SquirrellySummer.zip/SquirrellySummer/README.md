# One Squirrelly Summer – APK para Android

App Android que ejecuta el SWF original (menú/shell del juego) con el emulador Ruffle dentro de un WebView,
con pantalla completa horizontal, controles táctiles y un menú ☰.

## Cómo obtener el APK (la opción fácil, sin instalar nada)
1. Crea un repositorio en GitHub y sube TODO el contenido de esta carpeta (incluida `.github`).
2. Pestaña **Actions → Build APK → Run workflow**. Descarga y descomprime el artefacto `SquirrellySummer-apk`.
3. Copia `app-debug.apk` al móvil e instálalo (permite "instalar apps desconocidas").

## Compilar en tu PC
Requisitos: JDK 17, Android SDK (platform 34), Gradle 8.7+, Node.js.
    bash scripts/fetch_ruffle.sh      # descarga Ruffle a app/src/main/assets/www/ruffle
    gradle assembleDebug              # APK en app/build/outputs/apk/debug/
(o abre la carpeta en Android Studio tras ejecutar fetch_ruffle.sh).

## Archivos extra del juego
- Al iniciar, la app detecta que faltan `sb01_icecream.swf`, `sb02_golf.swf`, `sb03_mower.swf` y ofrece **Importarlos**
  (selector de archivos; puedes elegir varios). También puedes hacerlo luego desde ☰ → Importar.
- Opcional: los `.zip` de la tienda (`mp3-a1.zip`, `wall-121.zip`, etc.), mismo botón.
- Se guardan en el almacenamiento interno de la app. Sin ellos el menú, el mapa y la tienda funcionan igual.
- Alternativa: copia los SWF a `app/src/main/assets/game/` antes de compilar para incluirlos en el APK.

## Controles
☰ (arriba a la derecha): importar, reiniciar, silenciar, mostrar/ocultar controles, salir.
Cruceta = flechas, A = Espacio, B = Enter. Los toques funcionan como ratón.
