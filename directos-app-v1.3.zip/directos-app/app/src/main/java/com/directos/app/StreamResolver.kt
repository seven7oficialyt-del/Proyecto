package com.directos.app

import android.util.Base64
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

class Media(val url: String, val referer: String)

class Page(val code: Int, val body: String, val finalUrl: String)

/**
 * Extrae la URL real del video (.m3u8 / .mpd) del enlace externo SIN cargar su reproductor:
 * descarga el HTML/JS por HTTP y lo analiza (URLs directas, base64, JS "packed", iframes anidados).
 */
object StreamResolver {
    val log = StringBuilder()

    private val MEDIA = Regex("""https?://[^\s"'<>\\()]+?\.(?:m3u8|mpd)(?:\?[^\s"'<>\\()]*)?""", RegexOption.IGNORE_CASE)
    private val REL = Regex("""["'`]((?:/|\./|\.\./)?[A-Za-z0-9_\-./%]+\.(?:m3u8|mpd)(?:\?[^"'`\s]*)?)["'`]""", RegexOption.IGNORE_CASE)
    private val B64 = Regex("""["']([A-Za-z0-9+/]{24,}={0,2})["']""")
    private val IFR = Regex("""<iframe\b[^>]*?\bsrc\s*=\s*["']([^"']+)["']""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val SCRIPT_SRC = Regex("""<script\b[^>]*?\bsrc\s*=\s*["']([^"']+)["']""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val PACKED = Regex("""\}\(\s*'((?:[^'\\]|\\.)*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)""", RegexOption.DOT_MATCHES_ALL)

    fun get(url: String, referer: String): Page? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000; c.readTimeout = 15000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Referer", referer)
        c.setRequestProperty("Accept", "*/*")
        c.setRequestProperty("Accept-Language", "es-ES,es;q=0.9")
        try {
            val code = c.responseCode
            val s = if (code in 200..299) c.inputStream else c.errorStream
            val body = s?.bufferedReader()?.use { it.readText().take(2_000_000) } ?: ""
            Page(code, body, c.url.toString())
        } finally { c.disconnect() }
    } catch (e: Exception) { log.append("Error de red en $url: ${e.javaClass.simpleName} ${e.message}\n"); null }

    fun httpGet(url: String, referer: String): String? = get(url, referer)?.takeIf { it.code in 200..299 }?.body

    private fun clean(s: String): String {
        var t = s.replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&").replace("\\x2f", "/").replace("\\u002F", "/")
        t = Regex("""\\u([0-9a-fA-F]{4})""").replace(t) { it.groupValues[1].toInt(16).toChar().toString() }
        t = Regex("""\\x([0-9a-fA-F]{2})""").replace(t) { it.groupValues[1].toInt(16).toChar().toString() }
        return t
    }

    private fun unpack(js: String): String {
        val sb = StringBuilder()
        for (m in PACKED.findAll(js)) {
            try {
                var p = m.groupValues[1].replace("\\'", "'").replace("\\\\", "\\")
                val base = m.groupValues[2].toInt()
                val words = m.groupValues[4].split("|")
                fun enc(n: Int): String {
                    val d = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
                    var x = n; var r = ""
                    if (x == 0) return "0"
                    while (x > 0) { r = d[x % base] + r; x /= base }
                    return r
                }
                p = Regex("""\b\w+\b""").replace(p) { w ->
                    val key = w.value
                    val idx = key.fold(0) { acc, ch -> acc * base + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(ch) }
                    if (key.all { "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(it) in 0 until base } && idx < words.size && words[idx].isNotEmpty() && enc(idx) == key) words[idx] else key
                }
                sb.append(p).append('\n')
            } catch (e: Exception) {}
        }
        return sb.toString()
    }

    private fun resolveRel(base: String, rel: String): String? = try { URI(base).resolve(rel).toString() } catch (e: Exception) { null }

    private fun findMedia(raw: String, base: String): String? {
        val variants = ArrayList<String>()
        val txt = clean(raw)
        variants.add(txt)
        val un = unpack(txt); if (un.isNotEmpty()) variants.add(clean(un))
        for (v in variants.toList()) {
            for (m in B64.findAll(v)) {
                try {
                    val dec = clean(String(Base64.decode(m.groupValues[1], Base64.DEFAULT)))
                    if (dec.contains("m3u8") || dec.contains(".mpd")) variants.add(dec)
                } catch (e: Exception) {}
            }
        }
        for (v in variants) MEDIA.find(v)?.let { return it.value }
        for (v in variants) REL.find(v)?.let { r -> resolveRel(base, r.groupValues[1])?.let { return it } }
        return null
    }

    /** Analiza la página (y sus iframes / scripts) hasta encontrar el video. */
    fun resolve(embed: String, referer: String = "$BASE/", depth: Int = 0): Media? {
        val pg = get(embed, referer)
        if (pg == null) return null
        log.append("[${pg.code}] $embed (${pg.body.length} bytes)\n")
        if (pg.code !in 200..299) {
            if (log.length < 4000) log.append(pg.body.take(300)).append('\n')
            return null
        }
        findMedia(pg.body, pg.finalUrl)?.let { return Media(it, embed) }
        if (depth >= 3) { log.append(pg.body.take(1500)).append('\n'); return null }
        for (m in IFR.findAll(pg.body)) {
            val src = abs(pg.finalUrl, clean(m.groupValues[1])) ?: continue
            resolve(src, embed, depth + 1)?.let { return it }
        }
        // scripts externos del mismo origen (el reproductor suele estar en un .js)
        val host = try { URI(pg.finalUrl).host } catch (e: Exception) { null }
        for (m in SCRIPT_SRC.findAll(pg.body).take(8)) {
            val src = abs(pg.finalUrl, clean(m.groupValues[1])) ?: continue
            if (try { URI(src).host } catch (e: Exception) { null } != host) continue
            val js = get(src, embed) ?: continue
            log.append("[${js.code}] $src (${js.body.length} bytes)\n")
            findMedia(js.body, src)?.let { return Media(it, embed) }
        }
        if (depth == 0 || log.length < 6000) log.append("--- inicio del HTML de ${pg.finalUrl} ---\n").append(pg.body.take(1800)).append('\n')
        return null
    }

    private fun abs(base: String, s: String): String? {
        if (s.startsWith("javascript:") || s.startsWith("about:")) return null
        return try { URI(base).resolve(if (s.startsWith("//")) "https:$s" else s).toString().takeIf { it.startsWith("http") } } catch (e: Exception) { null }
    }
}
