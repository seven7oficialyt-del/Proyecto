# Directos (v1.1)

Cambio: al tocar un apartado ya NO se abre la página del blog. La app toma el enlace externo
de transmisión (iframe del post), obtiene el video (.m3u8/.mpd) y lo reproduce en ExoPlayer (nativo).
Si no lo logra, muestra el enlace externo como respaldo.

Compilar: abre la carpeta en Android Studio (Build > Build APK) o sube a GitHub (workflow incluido,
descarga `app-debug` en Actions).
