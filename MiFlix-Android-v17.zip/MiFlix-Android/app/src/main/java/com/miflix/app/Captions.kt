package com.miflix.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Procesador de audio "espía": deja pasar el sonido tal cual (no cambia nada de lo que oyes)
 * y a la vez entrega una copia en mono, 16 kHz, 16 bits, que sirve para reconocer voz.
 */
class AudioTap : BaseAudioProcessor() {
    @Volatile
    var listener: ((ByteArray) -> Unit)? = null
    private var rate = 48000
    private var channels = 2
    private var acc = 0.0
    private var cnt = 0
    private var phase = 0

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        // Si no es PCM de 16 bits no hacemos nada (el procesador queda inactivo y no afecta la reproducción)
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) return AudioProcessor.AudioFormat.NOT_SET
        rate = inputAudioFormat.sampleRate
        channels = if (inputAudioFormat.channelCount < 1) 1 else inputAudioFormat.channelCount
        acc = 0.0
        cnt = 0
        phase = 0
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val n = inputBuffer.remaining()
        if (n == 0) return
        val copy = inputBuffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        val out = replaceOutputBuffer(n)
        out.put(inputBuffer)
        out.flip()
        val l = listener ?: return
        try {
            l(downmix(copy))
        } catch (e: Exception) {
        }
    }

    /** Estéreo/5.1 -> mono y baja la frecuencia a 16 kHz (promediando) */
    private fun downmix(b: ByteBuffer): ByteArray {
        val frames = b.remaining() / (2 * channels)
        val est = frames * 16000 / rate + 4
        val out = ByteArray(est * 2)
        var o = 0
        for (f in 0 until frames) {
            var s = 0
            for (c in 0 until channels) s += b.getShort().toInt()
            acc += s.toDouble() / channels
            cnt++
            phase += 16000
            if (phase >= rate) {
                phase -= rate
                var v = (acc / cnt).toInt()
                if (v > 32767) v = 32767
                if (v < -32768) v = -32768
                if (o + 1 < out.size) {
                    out[o++] = (v and 0xFF).toByte()
                    out[o++] = ((v shr 8) and 0xFF).toByte()
                }
                acc = 0.0
                cnt = 0
            }
        }
        return out.copyOf(o)
    }
}

/** Idiomas que ofrece la app: código corto -> etiqueta de reconocimiento de voz y nombre */
object Langs {
    private val tags = mapOf(
        "es" to "es-ES", "en" to "en-US", "pt" to "pt-BR", "fr" to "fr-FR", "de" to "de-DE",
        "it" to "it-IT", "ja" to "ja-JP", "ko" to "ko-KR", "zh" to "zh-CN", "ru" to "ru-RU"
    )
    private val iso3 = mapOf(
        "spa" to "es", "eng" to "en", "por" to "pt", "fra" to "fr", "fre" to "fr", "deu" to "de",
        "ger" to "de", "ita" to "it", "jpn" to "ja", "kor" to "ko", "zho" to "zh", "chi" to "zh",
        "rus" to "ru", "lat" to "es"
    )

    fun recTag(code: String): String = tags[code] ?: code

    /** "es-MX", "spa", "es_419" -> "es" ; "und"/vacío -> "" */
    fun norm(l: String?): String {
        if (l.isNullOrBlank()) return ""
        val x = l.lowercase().replace('_', '-').substringBefore('-')
        if (x == "und" || x == "zxx") return ""
        return iso3[x] ?: x
    }

    fun name(code: String): String {
        val n = java.util.Locale(code).getDisplayLanguage(java.util.Locale("es"))
        return if (n.isBlank()) code else n.replaceFirstChar { it.uppercase() }
    }
}

/**
 * Subtítulos automáticos (beta): toma el audio que está sonando en el reproductor,
 * lo pasa al reconocedor de voz de Android (idioma original) y, si hace falta,
 * traduce el texto en el teléfono (ML Kit) al idioma elegido.
 * Requiere Android 13+ (el reconocedor acepta audio propio desde esa versión).
 */
@SuppressLint("NewApi")
class AutoCaptions(
    private val ctx: Context,
    private val audioLang: String,
    private val targetLang: String,
    private val show: (String) -> Unit,
    private val fail: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val queue = LinkedBlockingQueue<ByteArray>()
    private val qBytes = AtomicInteger(0)

    @Volatile
    private var running = false

    @Volatile
    private var session = 0
    private var rec: SpeechRecognizer? = null
    private var readFd: ParcelFileDescriptor? = null
    private var translator: Translator? = null
    private var needTr = false
    private var seq = 0
    private var errs = 0

    /** Llega audio nuevo desde el reproductor (hilo de audio) */
    fun feed(b: ByteArray) {
        if (!running) return
        queue.offer(b)
        // máximo ~8 s guardados (16000 muestras/s * 2 bytes)
        var total = qBytes.addAndGet(b.size)
        while (total > 16000 * 2 * 8) {
            val d = queue.poll() ?: break
            total = qBytes.addAndGet(-d.size)
        }
    }

    fun clearQueue() {
        queue.clear()
        qBytes.set(0)
    }

    fun start() {
        if (Build.VERSION.SDK_INT < 33) {
            fail(L.t("Los subtítulos automáticos necesitan Android 13 o superior", "Automatic subtitles need Android 13 or higher"))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            fail(L.t("Tu teléfono no tiene reconocimiento de voz disponible", "Your phone doesn't have speech recognition available"))
            return
        }
        val src = TranslateLanguage.fromLanguageTag(audioLang)
        val dst = TranslateLanguage.fromLanguageTag(targetLang)
        running = true
        if (audioLang != targetLang) {
            if (src == null || dst == null) {
                running = false
                fail("Ese par de idiomas no se puede traducir")
                return
            }
            needTr = true
            val t = Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build()
            )
            translator = t
            show(L.t("Preparando traducción…", "Preparing translation…"))
            t.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnSuccessListener { if (running) beginSession() }
                .addOnFailureListener {
                    if (running) {
                        stop()
                        fail("No se pudo descargar el traductor (necesita internet la primera vez)")
                    }
                }
        } else {
            beginSession()
        }
    }

    fun stop() {
        running = false
        main.removeCallbacksAndMessages(null)
        endSession()
        try {
            translator?.close()
        } catch (e: Exception) {
        }
        translator = null
        queue.clear()
        qBytes.set(0)
    }

    private fun beginSession() {
        if (!running) return
        session += 1
        val my = session
        val pipe: Array<ParcelFileDescriptor>
        try {
            pipe = ParcelFileDescriptor.createPipe()
        } catch (e: Exception) {
            stop()
            fail("No se pudo iniciar el reconocimiento de voz")
            return
        }
        readFd = pipe[0]
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                if (my != session) return
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) push(t)
            }

            override fun onResults(results: Bundle?) {
                if (my != session) return
                errs = 0
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) push(t)
                next(120)
            }

            override fun onError(error: Int) {
                if (my != session) return
                when (error) {
                    12, 13 -> {
                        stop()
                        fail(L.t("Tu teléfono no tiene el reconocimiento de voz para el idioma original del audio", "Your phone doesn't have speech recognition for the audio's original language"))
                        return
                    }
                    9 -> {
                        stop()
                        fail(L.t("Falta el permiso del micrófono para los subtítulos automáticos", "Microphone permission is missing for automatic subtitles"))
                        return
                    }
                    6, 7 -> {
                    }
                    else -> {
                        errs += 1
                        if (errs >= 4) {
                            stop()
                            fail("No se pudo reconocer el audio (revisa tu internet)")
                            return
                        }
                    }
                }
                next(if (error == 8) 900 else 300)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Langs.recTag(audioLang))
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, pipe[0])
        i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
        i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
        i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, 16000)
        try {
            r.startListening(i)
        } catch (e: Exception) {
            stop()
            fail("No se pudo iniciar el reconocimiento de voz")
            return
        }
        val wfd = pipe[1]
        Thread {
            try {
                ParcelFileDescriptor.AutoCloseOutputStream(wfd).use { os ->
                    while (running && session == my) {
                        val c = queue.poll(150, TimeUnit.MILLISECONDS) ?: continue
                        qBytes.addAndGet(-c.size)
                        os.write(c)
                    }
                }
            } catch (e: Exception) {
                try {
                    wfd.close()
                } catch (x: Exception) {
                }
            }
        }.start()
    }

    private fun endSession() {
        session += 1
        val old = rec
        rec = null
        try {
            old?.cancel()
        } catch (e: Exception) {
        }
        main.post {
            try {
                old?.destroy()
            } catch (e: Exception) {
            }
        }
        try {
            readFd?.close()
        } catch (e: Exception) {
        }
        readFd = null
    }

    private fun next(delay: Long) {
        endSession()
        main.postDelayed({ beginSession() }, delay)
    }

    private fun push(text: String) {
        if (!needTr) {
            show(text)
            return
        }
        seq += 1
        val my = seq
        translator?.translate(text)?.addOnSuccessListener { s -> if (running && my == seq) show(s) }
    }
}
