package com.miflix.app

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.view.View

/**
 * Pantalla completa REAL: oculta barras del sistema y dibuja también detrás de la muesca (notch)
 * / bordes redondeados, para que el video ocupe toda la pantalla sin franjas ni barra gris arriba.
 */
@Suppress("DEPRECATION")
fun Activity.goFullscreen() {
    window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
    if (Build.VERSION.SDK_INT >= 28) {
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30)
            android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else
            android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp
    }
    window.decorView.systemUiVisibility =
        View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
}
