package com.miflix.app

import android.app.Application
import android.content.Context

/** Idioma de la app (es / en). La página lo guarda aquí con MFBridge.setLang y el código nativo lo lee con L.t("es", "en") */
object L {
    @Volatile var en = false
    fun init(c: Context) {
        en = c.getSharedPreferences("mf", Context.MODE_PRIVATE).getString("lang", "es") == "en"
    }
    fun set(c: Context, lang: String) {
        val v = if (lang == "en") "en" else "es"
        c.getSharedPreferences("mf", Context.MODE_PRIVATE).edit().putString("lang", v).apply()
        en = v == "en"
    }
    fun t(es: String, en: String): String = if (this.en) en else es
}

class MiFlixApp : Application() {
    override fun onCreate() {
        super.onCreate()
        L.init(this)
    }
}
