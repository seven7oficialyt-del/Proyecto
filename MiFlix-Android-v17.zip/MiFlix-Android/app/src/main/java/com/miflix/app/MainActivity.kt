package com.miflix.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Updater.cleanup(this)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web = WebView(this)
        web.setBackgroundColor(0xFF141414.toInt())
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        // La página avisa aquí del idioma elegido (Español / English) para que lo use también el código nativo
        web.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun setLang(l: String) { L.set(this@MainActivity, l) }

            // ---- actualizaciones ----
            @android.webkit.JavascriptInterface
            fun versionCode(): Int = Updater.versionCode(this@MainActivity)

            @android.webkit.JavascriptInterface
            fun versionName(): String = Updater.versionName(this@MainActivity)

            @android.webkit.JavascriptInterface
            fun downloadApk(url: String) { Updater.download(this@MainActivity, web, url) }

            @android.webkit.JavascriptInterface
            fun installApk() { runOnUiThread { Updater.install(this@MainActivity, web) } }
        }, "MFBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == "appassets.androidplatform.net") return false
                val scheme = request.url.scheme
                if (scheme == "http" || scheme == "https") {
                    val path = (request.url.path ?: "").lowercase()
                    val direct = listOf(".mp4", ".m3u8", ".mpd", ".webm", ".mkv", ".m4v", ".mov").any { path.endsWith(it) }
                    val ytId = YouTube.idOf(request.url)
                    val target = when {
                        ytId != null -> YouTubeRoomActivity::class.java
                        direct -> VideoActivity::class.java
                        else -> PlayerActivity::class.java
                    }
                    // La web agrega al enlace: #mfroom=CODIGO&mfsub=es&mfaud=en
                    val frag = request.url.fragment ?: ""
                    // Botón "Elegir video de YouTube" de la sala: abre el selector
                    if (frag.contains("mfpick=1")) {
                        startActivityForResult(Intent(this@MainActivity, YouTubeActivity::class.java), 3)
                        return true
                    }
                    val kv = HashMap<String, String>()
                    for (part in frag.split('&')) {
                        val i = part.indexOf('=')
                        if (i > 0) kv[part.substring(0, i)] = part.substring(i + 1)
                    }
                    val room = (kv["mfroom"] ?: "").filter { it.isLetterOrDigit() }.take(12)
                    val sub = (kv["mfsub"] ?: "es").filter { it.isLetter() }.take(3).ifEmpty { "es" }
                    val aud = (kv["mfaud"] ?: "en").filter { it.isLetter() }.take(3).ifEmpty { "en" }
                    startActivity(
                        Intent(this@MainActivity, target)
                            .putExtra("url", request.url.toString().substringBefore('#'))
                            .putExtra("yt", ytId ?: "")
                            .putExtra("room", room)
                            .putExtra("sub", sub)
                            .putExtra("aud", aud)
                    )
                }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView,
                cb: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params.createIntent(), 1)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
        }
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 1) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else if (requestCode == 3) {
            // Video de YouTube elegido: se lo pasamos a la página para crear la sala
            val id = data?.getStringExtra("id")
            if (resultCode == RESULT_OK && !id.isNullOrEmpty()) {
                val title = data?.getStringExtra("title") ?: "Video de YouTube"
                web.evaluateJavascript("window.onYoutubePicked&&onYoutubePicked(${JSONObject.quote(id)},${JSONObject.quote(title)})", null)
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onResume() {
        super.onResume()
        // Al volver de una sala: si quedó vacía, la página la borra pasados 10 s
        web.evaluateJavascript("window.mfResume&&mfResume()", null)
        Updater.onResume(this, web)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
