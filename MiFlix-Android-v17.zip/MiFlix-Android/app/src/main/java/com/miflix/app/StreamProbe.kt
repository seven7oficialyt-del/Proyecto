package com.miflix.app

import android.media.MediaMetadataRetriever
import android.net.Uri
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicLong

/**
 * Averigua cuánto dura un video a partir de su dirección, para quedarse con el MÁS LARGO
 * cuando una página tiene varios (tráilers, avances, anuncios, recomendados...).
 * Se llama fuera del hilo principal. Devuelve 0 si no se pudo saber.
 */
object StreamProbe {
    fun durationMs(url: String, headers: Map<String, String>): Long {
        val low = url.lowercase()
        val path = (Uri.parse(url).path ?: "").lowercase()
        return try {
            when {
                path.endsWith(".m3u8") || low.contains(".m3u8") -> hls(url, headers, 0)
                path.endsWith(".mpd") || low.contains(".mpd?") -> dash(url, headers)
                else -> file(url, headers)
            }
        } catch (e: Throwable) {
            0L
        }
    }

    private fun open(url: String, headers: Map<String, String>): HttpURLConnection {
        val cn = URL(url).openConnection() as HttpURLConnection
        cn.connectTimeout = 4000
        cn.readTimeout = 4000
        cn.instanceFollowRedirects = true
        headers.forEach { (k, v) -> cn.setRequestProperty(k, v) }
        return cn
    }

    private fun text(url: String, headers: Map<String, String>): String? {
        val cn = open(url, headers)
        return try {
            if (cn.responseCode !in 200..299) null
            else cn.inputStream.bufferedReader(Charsets.UTF_8).use {
                val buf = CharArray(1_500_000)
                val n = it.read(buf)
                if (n > 0) String(buf, 0, n) else null
            }
        } finally {
            cn.disconnect()
        }
    }

    /** Lista .m3u8: suma lo que dura cada trozo. Si es la lista maestra, entra a la primera calidad */
    private fun hls(url: String, headers: Map<String, String>, depth: Int): Long {
        val t = text(url, headers) ?: return 0L
        if (t.contains("#EXT-X-STREAM-INF")) {
            if (depth > 1) return 0L
            val lines = t.lines()
            val i = lines.indexOfFirst { it.startsWith("#EXT-X-STREAM-INF") }
            val next = lines.drop(i + 1).firstOrNull { it.isNotBlank() && !it.startsWith("#") }?.trim() ?: return 0L
            return hls(URL(URL(url), next).toString(), headers, depth + 1)
        }
        var sum = 0.0
        Regex("#EXTINF:([0-9]+(?:\\.[0-9]+)?)").findAll(t).forEach { sum += it.groupValues[1].toDouble() }
        return (sum * 1000).toLong()
    }

    /** DASH (.mpd): lee mediaPresentationDuration="PT1H35M12.5S" */
    private fun dash(url: String, headers: Map<String, String>): Long {
        val t = text(url, headers) ?: return 0L
        val m = Regex("mediaPresentationDuration=\"PT(?:([0-9.]+)H)?(?:([0-9.]+)M)?(?:([0-9.]+)S)?\"").find(t) ?: return 0L
        val h = m.groupValues[1].toDoubleOrNull() ?: 0.0
        val mi = m.groupValues[2].toDoubleOrNull() ?: 0.0
        val s = m.groupValues[3].toDoubleOrNull() ?: 0.0
        return ((h * 3600 + mi * 60 + s) * 1000).toLong()
    }

    /** Archivo suelto (.mp4, .mkv...): duración real si se puede; si no, se estima por el peso */
    private fun file(url: String, headers: Map<String, String>): Long {
        val d = AtomicLong(0)
        val t = Thread {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(url, HashMap(headers))
                d.set(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L)
                r.release()
            } catch (e: Throwable) {
            }
        }
        t.start()
        t.join(4500)
        if (d.get() > 0) return d.get()
        val len = size(url, headers)
        return if (len > 0) len / 300 else 0L   // ~300 KB/s: solo para comparar entre candidatos
    }

    private fun size(url: String, headers: Map<String, String>): Long {
        val cn = open(url, headers)
        return try {
            cn.setRequestProperty("Range", "bytes=0-0")
            val range = cn.getHeaderField("Content-Range")
            if (range != null && range.contains('/')) range.substringAfter('/').trim().toLongOrNull() ?: 0L
            else cn.contentLengthLong.coerceAtLeast(0L)
        } catch (e: Exception) {
            0L
        } finally {
            cn.disconnect()
        }
    }
}
