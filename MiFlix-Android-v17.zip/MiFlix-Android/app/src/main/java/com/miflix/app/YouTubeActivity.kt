package com.miflix.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Selector de video de YouTube: se navega YouTube normalmente (buscar, canales, etc.)
 * y al abrir un video aparece el botón "Ver juntos". El video NO se reproduce aquí: solo se elige.
 */
class YouTubeActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var pick: TextView
    private val h = Handler(Looper.getMainLooper())
    private var curId: String? = null
    private var queueMode = false

    companion object {
        /** La sala la pone mientras el selector está abierto en modo fila: recibe (id, título) de cada video agregado */
        var onAdd: ((String, String) -> Unit)? = null
    }

    private val poll = object : Runnable {
        override fun run() {
            val id = web.url?.let { YouTube.idOf(Uri.parse(it)) }
            if (id != curId) {
                curId = id
                pick.visibility = if (id != null) View.VISIBLE else View.GONE
            }
            h.postDelayed(this, 600)
        }
    }

    // Mantiene en pausa cualquier reproducción de la página (aquí solo se elige, no se mira)
    private val PAUSE = """(function(){if(window.__mfp)return;window.__mfp=1;setInterval(function(){document.querySelectorAll('video').forEach(function(v){try{if(!v.paused)v.pause()}catch(e){}})},400)})();"""

    private val NOPLAY = """(function(){try{HTMLMediaElement.prototype.play=function(){try{this.muted=true;this.pause()}catch(e){}return Promise.resolve()}}catch(e){}})();"""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        queueMode = intent.getBooleanExtra("queue", false)
        val d = resources.displayMetrics.density
        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF0F0F0F.toInt())

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(0xFF1C1C1C.toInt())
        bar.setPadding((6 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
        val close = TextView(this)
        close.text = "✕"
        close.setTextColor(Color.WHITE)
        close.textSize = 20f
        close.setPadding((14 * d).toInt(), (6 * d).toInt(), (14 * d).toInt(), (6 * d).toInt())
        close.setOnClickListener { finish() }
        val title = TextView(this)
        title.text = if (queueMode) L.t("Busca videos para la fila", "Search videos for the queue") else L.t("Elige un video de YouTube", "Choose a YouTube video")
        title.setTextColor(Color.WHITE)
        title.textSize = 15f
        title.typeface = Typeface.DEFAULT_BOLD
        bar.addView(close)
        bar.addView(title)
        col.addView(bar, LinearLayout.LayoutParams(-1, -2))

        web = WebView(this)
        web.setBackgroundColor(0xFF0F0F0F.toInt())
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val host = (request.url.host ?: "").lowercase()
                val ok = host.endsWith("youtube.com") || host == "youtu.be" || host.endsWith("google.com") ||
                    host.endsWith("gstatic.com") || host.endsWith("googleusercontent.com")
                return !ok
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                // Aquí solo se elige: se anula play() para que esta página nunca tome el audio del video de la sala
                view.evaluateJavascript(NOPLAY, null)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(PAUSE, null)
            }
        }
        col.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        pick = TextView(this)
        pick.text = if (queueMode) L.t("＋  Agregar a la fila", "＋  Add to queue") else L.t("▶  Ver juntos este video", "▶  Watch this video together")
        pick.setTextColor(Color.WHITE)
        pick.textSize = 16f
        pick.typeface = Typeface.DEFAULT_BOLD
        pick.gravity = Gravity.CENTER
        pick.setPadding((22 * d).toInt(), (14 * d).toInt(), (22 * d).toInt(), (14 * d).toInt())
        val bg = GradientDrawable()
        bg.setColor(0xFFE50914.toInt())
        bg.cornerRadius = 28 * d
        pick.background = bg
        pick.elevation = 8 * d
        pick.visibility = View.GONE
        pick.setOnClickListener {
            val id = curId ?: return@setOnClickListener
            val t = (web.title ?: "").removeSuffix("- YouTube").trim().trimEnd('-').trim().ifEmpty { L.t("Video de YouTube", "YouTube video") }
            if (queueMode) {
                // Se queda abierto para poder agregar varios videos seguidos
                onAdd?.invoke(id, t)
                Toast.makeText(this, L.t("Agregado a la fila ✓", "Added to queue ✓"), Toast.LENGTH_SHORT).show()
            } else {
                setResult(RESULT_OK, Intent().putExtra("id", id).putExtra("title", t))
                finish()
            }
        }
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = (28 * d).toInt()
        root.addView(pick, lp)

        setContentView(root)
        web.loadUrl(if (L.en) "https://m.youtube.com/?hl=en" else "https://m.youtube.com/?hl=es")
        h.post(poll)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else finish()
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }
}
