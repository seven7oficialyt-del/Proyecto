package com.miflix.app

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * "Mejorar imagen": afinado de nitidez (unsharp mask) en la GPU sobre cada fotograma, en tiempo real.
 * No inventa detalle (no es IA), pero hace que 480p/720p se vean más definidos.
 */
class SharpenEffect(private val strength: Float) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        SharpenProgram(useHdr, strength)
}

private class SharpenProgram(useHdr: Boolean, private val strength: Float) : BaseGlShaderProgram(useHdr, 1) {
    private val gl: GlProgram
    private var w = 1
    private var h = 1

    init {
        try {
            gl = GlProgram(VERTEX, FRAGMENT)
            gl.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e)
        }
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        w = inputWidth.coerceAtLeast(1)
        h = inputHeight.coerceAtLeast(1)
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            gl.use()
            gl.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            gl.setFloatsUniform("uTexel", floatArrayOf(1f / w, 1f / h))
            gl.setFloatUniform("uStrength", strength)
            gl.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try { gl.delete() } catch (e: Exception) { throw VideoFrameProcessingException(e) }
    }

    companion object {
        private const val VERTEX = """
attribute vec4 aFramePosition;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = aFramePosition;
  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""
        private const val FRAGMENT = """
precision highp float;
uniform sampler2D uTexSampler;
uniform vec2 uTexel;
uniform float uStrength;
varying vec2 vTexSamplingCoord;
void main() {
  vec4 c = texture2D(uTexSampler, vTexSamplingCoord);
  vec3 n = texture2D(uTexSampler, vTexSamplingCoord + vec2(uTexel.x, 0.0)).rgb
         + texture2D(uTexSampler, vTexSamplingCoord - vec2(uTexel.x, 0.0)).rgb
         + texture2D(uTexSampler, vTexSamplingCoord + vec2(0.0, uTexel.y)).rgb
         + texture2D(uTexSampler, vTexSamplingCoord - vec2(0.0, uTexel.y)).rgb;
  vec3 o = c.rgb + (c.rgb - n * 0.25) * uStrength;
  gl_FragColor = vec4(clamp(o, 0.0, 1.0), c.a);
}
"""
    }
}
