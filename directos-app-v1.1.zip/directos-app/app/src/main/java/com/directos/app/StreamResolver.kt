package com.directos.app

import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL

const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

class Media(val url: String, val referer: String)

/**
 * Convierte el enlace externo (página embebida) en la URL real del video (.m3u8 / .mpd)
 * para dárselo al reproductor nativo. Todo esto corre en un hilo secundario.
 */
object StreamResolver {
    private val MEDIA = Regex("""https?://[^\s"'<>\\]+?\.(?:m3u8|mpd)(?:\?[^\s"'<>\\]*)?""", RegexOption.IGNORE_CASE)
    private val ATOB = Regex("""atob\(\s*["']([A-Za-z0-9+/=]{16,})["']\s*\)""")
    private val IFR = Regex("""<iframe\b[^>]*?\bsrc\s*=\s*["']([^"']+)["']""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

    fun httpGet(url: String, referer: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 12000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Referer", referer)
        c.setRequestProperty("Accept", "*/*")
        try {
            if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText().take(2_000_000) } else null
        } finally { c.disconnect() }
    } catch (e: Exception) { null }

    private fun clean(s: String) = s.replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&")

    private fun findMedia(raw: String): String? {
        val txt = clean(raw)
        MEDIA.find(txt)?.let { return it.value }
        for (m in ATOB.findAll(txt)) {
            try {
                val dec = clean(String(Base64.decode(m.groupValues[1], Base64.DEFAULT)))
                MEDIA.find(dec)?.let { return it.value }
            } catch (e: Exception) {}
        }
        return null
    }

    /** Busca el video en la página del embed (y en iframes anidados, hasta 2 niveles). */
    fun resolve(embed: String, referer: String = "$BASE/", depth: Int = 0): Media? {
        val html = httpGet(embed, referer) ?: return null
        findMedia(html)?.let { return Media(it, embed) }
        if (depth >= 2) return null
        for (m in IFR.findAll(html)) {
            var src = clean(m.groupValues[1])
            if (src.startsWith("//")) src = "https:$src"
            if (!src.startsWith("http")) continue
            resolve(src, embed, depth + 1)?.let { return it }
        }
        return null
    }
}
