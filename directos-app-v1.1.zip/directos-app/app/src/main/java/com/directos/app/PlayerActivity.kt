package com.directos.app

import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

/**
 * Reproduce la transmisión directamente en el reproductor nativo (ExoPlayer).
 *
 * Flujo:
 *  1. Toma el enlace externo de transmisión (iframe del post).
 *  2. Intenta sacar la URL real del video (.m3u8/.mpd) leyendo esa página.
 *  3. Si el video se arma con JavaScript, carga el enlace en un WebView oculto, "escucha" las
 *     peticiones de red y apenas aparece el .m3u8/.mpd lo pasa al reproductor nativo.
 *  4. Si nada de eso funciona (o el reproductor falla), muestra el enlace en pantalla como respaldo.
 */
class PlayerActivity : Activity() {
    private lateinit var frame: FrameLayout
    private lateinit var msg: TextView
    private var pv: PlayerView? = null
    private var player: ExoPlayer? = null
    private var web: WebView? = null
    private var custom: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private val h = Handler(Looper.getMainLooper())
    private var embed = ""
    private var postUrl = ""
    @Volatile private var sniffing = false
    @Volatile private var found = false
    private var closed = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        embed = intent.getStringExtra("stream").orEmpty()
        postUrl = intent.getStringExtra("url").orEmpty()
        if (embed.isEmpty() && postUrl.isEmpty()) { finish(); return }

        frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        msg = TextView(this).apply {
            text = "Cargando transmisión…"; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
        }
        frame.addView(msg, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
        hideBars()

        Thread {
            var emb = embed
            if (emb.isEmpty()) emb = StreamResolver.httpGet(postUrl, "$BASE/")?.let { Feed.embedFrom(it) }.orEmpty()
            if (emb.isEmpty()) { post { showPage(postUrl) }; return@Thread }
            embed = emb
            val m = StreamResolver.resolve(emb)
            post { if (m != null) play(m, emptyMap()) else sniff(emb) }
        }.start()
    }

    private fun post(r: () -> Unit) = runOnUiThread { if (!closed) r() }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    // ---------------------------------------------------------------- reproductor nativo
    private fun play(m: Media, extra: Map<String, String>) {
        if (found) return
        found = true
        sniffing = false
        killWeb()
        msg.visibility = View.GONE

        val headers = HashMap<String, String>()
        headers["Referer"] = m.referer
        try { val u = Uri.parse(m.referer); headers["Origin"] = "${u.scheme}://${u.host}" } catch (e: Exception) {}
        headers.putAll(extra)

        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent(UA)
            .setDefaultRequestProperties(headers)
        val exo = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .build()
        val item = MediaItem.Builder().setUri(m.url).apply {
            val low = m.url.lowercase()
            if (low.contains(".m3u8")) setMimeType(MimeTypes.APPLICATION_M3U8)
            else if (low.contains(".mpd")) setMimeType(MimeTypes.APPLICATION_MPD)
        }.build()
        exo.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                // El reproductor nativo no pudo con el stream: mostramos el enlace como respaldo.
                post {
                    releasePlayer()
                    showPage(embed.ifEmpty { postUrl })
                }
            }
        })
        exo.setMediaItem(item)
        exo.prepare()
        exo.playWhenReady = true

        val view = PlayerView(this).apply {
            player = exo
            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
            keepScreenOn = true
        }
        frame.addView(view, FrameLayout.LayoutParams(-1, -1))
        pv = view
        player = exo
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun releasePlayer() {
        pv?.let { it.player = null; frame.removeView(it) }
        pv = null
        player?.release()
        player = null
    }

    // ---------------------------------------------------------------- detección de la URL real
    private fun sniff(url: String) {
        sniffing = true
        val w = makeWeb(url)
        w.visibility = View.INVISIBLE
        frame.addView(w, 0, ViewGroup.LayoutParams(-1, -1))
        web = w
        w.loadUrl(url, mapOf("Referer" to "$BASE/"))
        // Si el reproductor de la página necesita un toque para arrancar, la mostramos.
        h.postDelayed({
            if (sniffing && !closed) {
                web?.visibility = View.VISIBLE
                msg.text = "Toca play en el video…"
                msg.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                msg.setPadding(0, 48, 0, 0)
            }
        }, 8000)
    }

    private fun showPage(url: String) {
        sniffing = false
        msg.visibility = View.GONE
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val w = web ?: makeWeb(url).also {
            frame.addView(it, 0, ViewGroup.LayoutParams(-1, -1)); web = it
            it.loadUrl(url, mapOf("Referer" to "$BASE/"))
        }
        w.visibility = View.VISIBLE
    }

    private fun mediaUrl(u: String): Boolean {
        val l = u.lowercase().substringBefore('#')
        val path = l.substringBefore('?')
        return path.endsWith(".m3u8") || path.endsWith(".mpd") || (l.contains(".m3u8?") )
    }

    private fun makeWeb(startUrl: String): WebView {
        val host = Uri.parse(startUrl).host
        val w = WebView(this)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            userAgentString = UA
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                // Bloquea anuncios/popups que el usuario dispare hacia otros dominios.
                return r.hasGesture() && !r.isRedirect && r.url.host != host
            }

            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url.toString()
                if (sniffing && !found && mediaUrl(u)) {
                    val ref = r.requestHeaders["Referer"] ?: startUrl
                    val extra = HashMap<String, String>()
                    CookieManager.getInstance().getCookie(u)?.let { extra["Cookie"] = it }
                    post { play(Media(u, ref), extra) }
                }
                return null
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(v: View, cb: CustomViewCallback) {
                custom = v; customCb = cb
                frame.addView(v, ViewGroup.LayoutParams(-1, -1))
                web?.visibility = View.GONE
            }

            override fun onHideCustomView() {
                custom?.let { frame.removeView(it) }
                custom = null
                customCb?.onCustomViewHidden()
                web?.visibility = View.VISIBLE
            }
        }
        return w
    }

    private fun killWeb() {
        h.removeCallbacksAndMessages(null)
        web?.let {
            try { frame.removeView(it); it.stopLoading(); it.destroy() } catch (e: Exception) {}
        }
        web = null
    }

    // ---------------------------------------------------------------- ciclo de vida
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (custom != null) { web?.webChromeClient?.onHideCustomView(); return }
        val w = web
        if (w != null && w.visibility == View.VISIBLE && w.canGoBack()) w.goBack() else finish()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onPause() { super.onPause(); web?.onPause(); player?.pause() }
    override fun onResume() { super.onResume(); web?.onResume(); player?.play() }

    override fun onDestroy() {
        closed = true
        h.removeCallbacksAndMessages(null)
        releasePlayer()
        killWeb()
        super.onDestroy()
    }
}
