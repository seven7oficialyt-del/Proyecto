# Jurassic Experience – v0.6
Juego nativo Android (Java + Canvas). Sin internet, sin WebView.
(El paquete sigue siendo `com.nocheraptor.game` y la clave `keystore.jks` es la misma, así que se instala encima de la versión anterior.)

## Cómo se juega
- Arrastra para mover la cámara. Mantén **LUZ** sobre el raptor de la puerta (izquierda) para echarlo.
- **Trampillas** (techo y pared derecha): se abren/cierran cuando quieras con sus botones (TECHO / PARED) o tocando la rejilla.
  Cuando el raptor se acerca por una trampilla se oyen rasguños y se ve una **luz brillante entre las rendijas**.
  Si llega con la trampilla abierta, te atrapa; si está cerrada, golpea y se va.
- **Energía** (esquina inferior izquierda): la luz y cada trampilla cerrada gastan batería, además de un gasto base que sube cada noche.
  Si llega a 0% se va la luz, las trampillas se abren y el raptor viene a por ti.
- **7 noches**. Cada noche y cada hora es más difícil. En las noches 1-3 el raptor da unos segundos extra (+3 s en la puerta, +2 s en las trampillas).

## Cámaras (v0.3)
- Botón **CÁMARAS** abajo en el centro: abre/cierra el monitor. Mientras miras las cámaras no puedes usar luz ni trampillas, y gastan energía.
- **Mapa** a la derecha con las 5 cámaras y tu sala (**TÚ**). Toca una casilla para cambiar de cámara.
  CAM 1 hábitat del T-Rex · CAM 2 ducto del techo (arriba de tu sala) · CAM 3 comedor · CAM 4 ducto derecho (la trampilla de la pared) · CAM 5 hábitat de raptors.
- **T-Rex rojo** (CAM 1, fijo en la imagen del hábitat, **activo desde la noche 3**): el círculo blanco se va cortando. Pulsa **ALIMENTAR** antes de que se acabe o muerde los fusibles y te quedas sin electricidad.
  Si queda poco, la casilla CAM 1 del mapa parpadea en rojo.
- **Dinosaurio de espinas** (**activo desde la noche 2**): recorre hábitat de raptors → comedor → ductos. Cada sala tiene su imagen con el dinosaurio dentro (`cam_dining_spiky.jpg`, `cam_vent_top_spiky.jpg`, `cam_vent_right_spiky.jpg`). Antes de llegar a una trampilla siempre pasa por la cámara de su ducto, donde se ve acercarse.
  Si añades `img/cam_pen_spiky.jpg` se usará en el hábitat de raptors; si no existe, se dibuja el sprite `spiky_side.png`.
  Si llega por un ducto con la trampilla abierta, te atrapa; si está cerrada, golpea y se va. También puede venir por la **puerta** (se echa con la luz, como el raptor).
  En cualquier cámara (menos la del T-Rex) pulsa **SONIDO** para atraerlo hacia esa sala (espera unos segundos entre sonidos).
- El **raptor** protagonista ahora solo viene por la puerta.

## Estática de transición
Cuando el dinosaurio de espinas cambia de sala (o entra/sale de un ducto o de la puerta), las cámaras de la sala que deja y de la que llega muestran **1.5 s de estática** (último 0.3 s se desvanece) con su sonido. El video se recortó a 36 fotogramas en `img/static/static_01..36.jpg` y `sounds/static.wav` (`STATIC_TIME`, `STATIC_FRAMES`, `STATIC_FADE`).
Si hay un dinosaurio en una sala, la cámara muestra solo la imagen con el dinosaurio (sin parpadeo con la sala vacía).

## Tienda
Icono de tienda abajo a la derecha del menú principal. Muestra tus monedas y vende el **peluche del T-Rex rojo** (`PLUSH_PRICE`, 400 monedas). Al comprarlo aparece en el suelo de tu sala (se ve al mirar alrededor). Imagen: `img/plush_trex.png` (peluche frontal, fondo transparente).

## Energía (v0.5)
Gasto base por segundo según la noche: 0.130 · 0.160 · 0.180 · 0.195 · 0.210 · 0.225 · 0.240 (`BASE_DRAIN`), más luz (0.11), cada trampilla cerrada (0.09) y cámaras abiertas (0.065). Acciones puntuales: alimentar al T-Rex cuesta 0.5% (`FEED_COST`) y cada sonido para atraer al de espinas 0.8% (`LURE_COST`). La dificultad multiplica todo (`D_DRAIN`: 0.85 / 1.0 / 1.10 / 1.20).
Noche 1 solo el raptor de la puerta (solo gasta la luz); noche 2 se suman trampillas y cámaras; noche 3 el T-Rex.

## Susto
Todos los sustos usan la imagen frontal del velociraptor (`spiky_front.png`). El grito suena a volumen máximo en 3 capas y baja la música.

## Pausa
Botón **||** arriba a la izquierda (o botón atrás del teléfono, o salir de la app): CONTINUAR · OPCIONES · SALIR AL MENÚ PRINCIPAL. El juego queda congelado.

## Noches de activación (inicio de GameView.java)
`SPIKY_FIRST_NIGHT = 2`, `TREX_FIRST_NIGHT = 3`. Noche 1: solo el raptor de la puerta. Noche 2: + dinosaurio de espinas. Noche 3: + T-Rex.

## Monedas
Al terminar la noche (ganes o te atrapen) recibes monedas por el **tiempo sobrevivido**, multiplicadas por la **dificultad**; si superas la noche hay un bonus extra. El total se guarda y se ve en el menú principal.

## Menú
Continuar · Nueva partida · Seleccionar noche (solo las desbloqueadas) · Opciones · Salir.
Opciones: dificultad (fácil / normal / difícil / extremo), idioma (español / English), sonido (música y efectos) y botones (mover y cambiar tamaño).
El progreso (noche desbloqueada, noche actual, opciones y posición de botones) se guarda automáticamente.

## Ajustes rápidos (inicio de GameView.java)
Duración de la hora, gasto de energía (`BASE_DRAIN`, `HATCH_DRAIN`, `LIGHT_DRAIN`), tablas de dificultad (`D_*`), bonus de las primeras noches (`EASY_*`), cámaras (`CAM_DRAIN`, `LURE_COOLDOWN`, `FEED_TIME`, `SPIKY_START`, `RAPTOR_IDLE_MULT`) y monedas (`COIN_PER_SEC`, `COIN_WIN_BONUS`, `D_COIN`).

## Archivos
- `GameView.java`: juego y menús. `Settings.java`: guardado de progreso y opciones.
- Imágenes en `app/src/main/assets/img`, sonidos en `app/src/main/assets/sounds`.
- Icono: `res/mipmap-*` (adaptativo para Android 8+, a sangre, sin bordes).
