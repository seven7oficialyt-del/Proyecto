package com.directos.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object Notifier {
    private const val CH = "nuevos"

    /** Intent que abre directamente la transmisión en el reproductor nativo. */
    fun playIntent(c: Context, p: Post): Intent =
        Intent(c, PlayerActivity::class.java)
            .putExtra("url", p.link)
            .putExtra("stream", p.stream)
            .putExtra("title", p.title)

    fun show(c: Context, fresh: List<Post>) {
        if (fresh.isEmpty()) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Nuevos directos", 4))
        for (p in fresh.take(5)) {
            val open = PendingIntent.getActivity(c, p.id.hashCode(), playIntent(c, p), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            nm.notify(p.id.hashCode(), builder(c).setContentTitle("Nuevo: ${p.label}").setContentText(p.title).setContentIntent(open).setAutoCancel(true).build())
        }
        if (fresh.size > 5) {
            val app = PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            nm.notify(1, builder(c).setContentTitle("Más directos nuevos").setContentText("Hay ${fresh.size - 5} más en la app").setContentIntent(app).setAutoCancel(true).build())
        }
    }

    private fun builder(c: Context): Notification.Builder {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CH) else Notification.Builder(c)
        return b.setSmallIcon(android.R.drawable.ic_dialog_info)
    }
}
