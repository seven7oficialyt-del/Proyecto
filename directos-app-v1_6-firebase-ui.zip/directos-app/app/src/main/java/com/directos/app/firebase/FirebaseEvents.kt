package com.directos.app.firebase

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

/**
 * Replica la lectura de "partidos" (eventos) y del banner superior de la app antigua
 * (Futbol Gigante, com.futbol.gigante / NewPlayListActivity).
 *
 * Documentos usados en la app antigua (confirmados leyendo el bytecode real del
 * constructor de NewPlayListActivity en el .dex, no inventados):
 *
 *   partidosRef = db.collection("Fix_event").document("rc83wlM4mKtlzasv2YSd")
 *   topRef      = db.collection("Channel_properties").document("x8ynivyrETqYJITRLHXi")
 *
 * IMPORTANTE: el ID del documento ("rc83wlM4mKtlzasv2YSd", "x8ynivyrETqYJITRLHXi") es el
 * identificador concreto de ESE documento en ESE proyecto Firebase. Si en algún momento
 * cambia el documento del lado del servidor, hay que actualizar estas constantes.
 */

/** Un ítem de partido/evento dentro de un grupo. Campos confirmados: title, status, link(s). */
data class EventItem(
    val title: String = "",
    val status: String = "",
    val urlList: List<String> = emptyList()
)

/** Un grupo de partidos con su propio título (ej. "En vivo", "Próximos"). */
data class EventGroup(
    val title: String = "",
    val items: List<EventItem> = emptyList()
)

/** Datos del banner superior (top) de la pantalla de partidos. */
data class TopBanner(
    val topBackground: String = "",
    val image: String = "",
    val title: String = "",
    val subtitle: String = ""
)

object FirebaseEvents {
    private val db by lazy { FirebaseFirestore.getInstance() }

    private const val EVENTS_COLLECTION = "Fix_event"
    private const val EVENTS_DOC_ID = "rc83wlM4mKtlzasv2YSd"

    private const val TOP_COLLECTION = "Channel_properties"
    private const val TOP_DOC_ID = "x8ynivyrETqYJITRLHXi"

    /**
     * Escucha en tiempo real los grupos de partidos/eventos.
     * El documento es un mapa de "grupos", cada uno con título y una lista de items
     * (cada item con title/status/link). Como no tenemos aquí la forma exacta anidada
     * (array vs map) confirmada campo por campo, se expone el snapshot crudo además
     * de un intento de parseo best-effort a EventGroup/EventItem — revisa en consola
     * de Firebase la forma real y ajusta parseGroups() si hace falta.
     */
    fun listenEvents(
        onRaw: (Map<String, Any?>) -> Unit,
        onError: (Exception) -> Unit = {}
    ): ListenerRegistration {
        return db.collection(EVENTS_COLLECTION).document(EVENTS_DOC_ID)
            .addSnapshotListener { snap, error ->
                if (error != null) { onError(error); return@addSnapshotListener }
                if (snap == null || !snap.exists()) return@addSnapshotListener
                onRaw(snap.data.orEmpty())
            }
    }

    fun listenTopBanner(
        onUpdate: (TopBanner) -> Unit,
        onError: (Exception) -> Unit = {}
    ): ListenerRegistration {
        return db.collection(TOP_COLLECTION).document(TOP_DOC_ID)
            .addSnapshotListener { snap, error ->
                if (error != null) { onError(error); return@addSnapshotListener }
                if (snap == null || !snap.exists()) return@addSnapshotListener
                onUpdate(
                    TopBanner(
                        topBackground = snap.getString("topBackground").orEmpty(),
                        image = snap.getString("image").orEmpty(),
                        title = snap.getString("title").orEmpty(),
                        subtitle = snap.getString("subtitle").orEmpty()
                    )
                )
            }
    }

    /**
     * Intento de parseo best-effort de la estructura anidada de partidos a partir del
     * mapa crudo de Firestore. Ajusta las claves si al inspeccionar `onRaw` ves otros
     * nombres de nivel superior (p. ej. si los grupos están en una lista bajo una clave
     * como "items" o "data" en vez de ser el propio mapa raíz).
     */
    @Suppress("UNCHECKED_CAST")
    fun parseGroups(raw: Map<String, Any?>): List<EventGroup> {
        val groups = mutableListOf<EventGroup>()
        for ((_, value) in raw) {
            val groupMap = value as? Map<String, Any?> ?: continue
            val groupTitle = groupMap["title"] as? String ?: continue
            val itemsRaw = groupMap["playListItems"] as? List<Any?> ?: emptyList()
            val items = itemsRaw.mapNotNull { itemAny ->
                val itemMap = itemAny as? Map<String, Any?> ?: return@mapNotNull null
                EventItem(
                    title = itemMap["title"] as? String ?: "",
                    status = itemMap["status"] as? String ?: "",
                    urlList = (itemMap["urlList"] as? List<Any?>)
                        ?.mapNotNull { it as? String } ?: emptyList()
                )
            }
            groups.add(EventGroup(title = groupTitle, items = items))
        }
        return groups
    }
}
