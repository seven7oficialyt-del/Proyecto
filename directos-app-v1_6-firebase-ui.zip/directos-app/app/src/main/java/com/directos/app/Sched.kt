package com.directos.app

import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context

object Sched {
    fun start(c: Context) {
        val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        if (js.getPendingJob(1) != null) return
        val info = JobInfo.Builder(1, ComponentName(c, CheckJob::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPeriodic(900000L)
            .setPersisted(true)
            .build()
        js.schedule(info)
    }
}
