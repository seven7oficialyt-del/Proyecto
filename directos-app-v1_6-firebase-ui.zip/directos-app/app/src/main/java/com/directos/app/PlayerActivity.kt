package com.directos.app

import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

/**
 * Reproduce la transmisión SOLO en el reproductor nativo (ExoPlayer).
 * No carga ni muestra ningún reproductor/WebView de la página: la app extrae la URL del video
 * del enlace externo por HTTP (StreamResolver) y se la da directo a ExoPlayer.
 */
class PlayerActivity : Activity() {
    private lateinit var frame: FrameLayout
    private lateinit var cover: LinearLayout
    private lateinit var msg: TextView
    private lateinit var actions: LinearLayout
    private var pv: PlayerView? = null
    private var player: ExoPlayer? = null
    private var embed = ""
    private var postUrl = ""
    private var closed = false
    private var gen = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        embed = intent.getStringExtra("stream").orEmpty()
        postUrl = intent.getStringExtra("url").orEmpty()
        if (embed.isEmpty() && postUrl.isEmpty()) { finish(); return }

        frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        msg = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32); setTextIsSelectable(true)
        }
        actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; visibility = View.GONE }
        actions.addView(Button(this).apply { text = "Reintentar"; setOnClickListener { start() } })
        actions.addView(Button(this).apply { text = "Salir"; setOnClickListener { finish() } })
        cover = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            addView(ScrollView(this@PlayerActivity).apply { addView(msg) }, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(actions, LinearLayout.LayoutParams(-1, -2))
        }
        frame.addView(cover, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
        hideBars()
        start()
    }

    private fun post(r: () -> Unit) = runOnUiThread { if (!closed) r() }

    private fun start() {
        gen++
        val g = gen
        releasePlayer()
        StreamResolver.log.setLength(0)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        cover.visibility = View.VISIBLE
        actions.visibility = View.GONE
        msg.gravity = Gravity.CENTER
        msg.textSize = 15f
        msg.text = "Cargando transmisión…"
        Thread {
            var emb = embed
            if (emb.isEmpty()) emb = StreamResolver.httpGet(postUrl, "$BASE/")?.let { Feed.embedFrom(it) }.orEmpty()
            if (emb.isEmpty()) { post { if (g == gen) fail("El post no trae enlace de transmisión.") }; return@Thread }
            embed = emb
            val m = StreamResolver.resolve(emb)
            post { if (g == gen) { if (m != null) play(m) else fail("No encontré la URL del video en el enlace.") } }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    private fun fail(reason: String) {
        cover.visibility = View.VISIBLE
        actions.visibility = View.VISIBLE
        msg.gravity = Gravity.START
        msg.textSize = 11f
        msg.text = "$reason\n\nEnlace: $embed\n\nDiagnóstico (mándale una captura a Claude):\n${StreamResolver.log}"
    }

    private fun play(m: Media) {
        cover.visibility = View.GONE
        val headers = HashMap<String, String>()
        headers["Referer"] = m.referer
        try { val u = Uri.parse(m.referer); headers["Origin"] = "${u.scheme}://${u.host}" } catch (e: Exception) {}

        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent(UA)
            .setDefaultRequestProperties(headers)
        val exo = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .build()
        val item = MediaItem.Builder().setUri(m.url)
            .setMimeType(if (m.url.lowercase().contains(".mpd")) MimeTypes.APPLICATION_MPD else MimeTypes.APPLICATION_M3U8)
            .build()
        exo.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                post {
                    releasePlayer()
                    StreamResolver.log.append("Video: ${m.url}\nError del reproductor: ${error.errorCodeName} ${error.message}\n")
                    fail("El reproductor nativo no pudo abrir el video.")
                }
            }
        })
        exo.setMediaItem(item)
        exo.prepare()
        exo.playWhenReady = true

        val view = PlayerView(this).apply {
            player = exo
            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
            keepScreenOn = true
        }
        frame.addView(view, 0, FrameLayout.LayoutParams(-1, -1))
        pv = view
        player = exo
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun releasePlayer() {
        pv?.let { it.player = null; frame.removeView(it) }
        pv = null
        player?.release()
        player = null
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onPause() { super.onPause(); player?.pause() }
    override fun onResume() { super.onResume(); player?.play() }

    override fun onDestroy() {
        closed = true
        releasePlayer()
        super.onDestroy()
    }
}
