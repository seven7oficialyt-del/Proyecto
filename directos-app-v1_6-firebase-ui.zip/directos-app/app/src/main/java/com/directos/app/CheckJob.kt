package com.directos.app

import android.app.job.JobParameters
import android.app.job.JobService

class CheckJob : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            try {
                val r = Feed.check(applicationContext)
                Notifier.show(applicationContext, r.fresh)
            } catch (e: Exception) {
            }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true
}
