package com.directos.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale

const val BASE = "https://jo.jeinzmacias.cx"
const val FEED = "$BASE/feeds/posts/default?alt=json&max-results=150"

/** [stream] = enlace externo de transmisión (src del iframe del post). Vacío si el post no trae uno. */
class Post(
    val id: String,
    val title: String,
    val link: String,
    val label: String,
    val time: Long,
    val stream: String = "",
    /** De dónde sale este ítem: "Blog" (jo.jeinzmacias.cx) o "Firebase" (proyecto futbol-gigante). */
    val source: String = "Blog"
)

class Result(val posts: List<Post>, val fresh: List<Post>)

object Feed {
    private val IFRAME = Regex("""<iframe\b[^>]*?\b(?:data-src|src)\s*=\s*["']([^"']+)["']""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

    /** Extrae el enlace externo de transmisión (iframe) del HTML de un post. */
    fun embedFrom(html: String): String {
        val raw = IFRAME.findAll(html).map { it.groupValues[1].trim() }
            .firstOrNull {
                it.isNotEmpty() && !it.startsWith("about:") && !it.startsWith("javascript:") &&
                    !it.contains("blogger.com") && !it.contains("facebook.com/plugins")
            }
            ?: return ""
        var u = raw.replace("&amp;", "&")
        if (u.startsWith("//")) u = "https:$u"
        return u
    }

    fun fetch(): List<Post> {
        val c = URL(FEED).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "DirectosApp/1.0")
        try {
            val txt = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val entries = JSONObject(txt).getJSONObject("feed").optJSONArray("entry") ?: return emptyList()
            val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US)
            val out = ArrayList<Post>()
            for (i in 0 until entries.length()) {
                val e = entries.getJSONObject(i)
                val title = e.getJSONObject("title").optString("\$t")
                val id = e.getJSONObject("id").optString("\$t")
                var link = ""
                e.optJSONArray("link")?.let { ls ->
                    for (j in 0 until ls.length()) {
                        val l = ls.getJSONObject(j)
                        if (l.optString("rel") == "alternate") link = l.optString("href")
                    }
                }
                val cats = e.optJSONArray("category")
                val label = if (cats == null || cats.length() == 0) "Otros" else cats.getJSONObject(0).optString("term")
                val t = try { fmt.parse(e.getJSONObject("published").optString("\$t"))?.time ?: 0L } catch (x: Exception) { 0L }
                val html = e.optJSONObject("content")?.optString("\$t").orEmpty()
                if (link.isNotEmpty()) out.add(Post(id, title, link, label, t, embedFrom(html)))
            }
            return out
        } finally {
            c.disconnect()
        }
    }

    private fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("directos", 0)
    private fun getSet(c: Context, k: String): Set<String> = prefs(c).getStringSet(k, emptySet()) ?: emptySet()
    private fun addAll(c: Context, k: String, ids: Collection<String>) {
        val s = HashSet(getSet(c, k)); s.addAll(ids)
        prefs(c).edit().putStringSet(k, s).apply()
    }

    fun isSeen(c: Context, id: String) = getSet(c, "seen").contains(id)
    fun markSeen(c: Context, id: String) = addAll(c, "seen", listOf(id))

    @Synchronized
    fun check(c: Context): Result {
        val posts = fetch()
        val first = !prefs(c).contains("known")
        val old = getSet(c, "known")
        val fresh = if (first) emptyList() else posts.filter { !old.contains(it.id) }
        addAll(c, "known", posts.map { it.id })
        if (first) addAll(c, "seen", posts.map { it.id })
        return Result(posts, fresh)
    }
}
