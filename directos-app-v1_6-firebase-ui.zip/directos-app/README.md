# Directos (v1.1)

Cambio: al tocar un apartado ya NO se abre la página del blog. La app toma el enlace externo
de transmisión (iframe del post), obtiene el video (.m3u8/.mpd) y lo reproduce en ExoPlayer (nativo).
Si no lo logra, muestra el enlace externo como respaldo.

Compilar: abre la carpeta en Android Studio (Build > Build APK) o sube a GitHub (workflow incluido,
descarga `app-debug` en Actions).

## Integración con Firebase (misma base de datos que "Futbol Gigante")

Se agregó `com.google.gms.google-services` + Firebase Firestore, apuntando al MISMO
proyecto Firebase que usaba la app antigua (`com.futbol.gigante`), proyecto `futbol-gigante`.
No se tocó nada del lado de la app antigua: todo el código nuevo vive en `app/src/main/java/com/directos/app/firebase/`.

- `FirebaseChannels.kt` — replica `MainActivity.readChannelList()` de la app antigua.
  Lee/escucha `collection("fix_channel").document("channel")`, con campos
  `azteca, cn, raid, telefe, telemundo, tn` (cada uno = URL del canal).
- `FirebaseEvents.kt` — replica `NewPlayListActivity` de la app antigua.
  - Partidos/eventos: `collection("Fix_event").document("rc83wlM4mKtlzasv2YSd")`
  - Banner superior: `collection("Channel_properties").document("x8ynivyrETqYJITRLHXi")`
    con campos `topBackground, image, title, subtitle`.

**Pendiente de verificar (no confirmado al 100%, solo inferido del bytecode):**
la forma EXACTA anidada del documento de partidos (si los grupos son un mapa o un
array, y el nombre exacto de la clave de la lista de items). `parseGroups()` en
`FirebaseEvents.kt` trae un primer intento — conviene abrir la consola de Firebase,
mirar el documento `Fix_event/rc83wlM4mKtlzasv2YSd` una vez, y ajustar esa función
si las claves no coinciden.

**Sobre `app/google-services.json`:** usa las credenciales reales del proyecto
`futbol-gigante` (API key y `project_id`/`storage_bucket` recuperados del APK
antiguo), pero el `mobilesdk_app_id` sigue registrado a nombre del paquete
`com.futbol.gigante`, no de `com.directos.app`. Debería funcionar igual para leer
Firestore (el acceso lo controlan las reglas de seguridad de Firestore, no el
paquete), pero si algo falla al conectar, lo correcto es entrar a la consola de
Firebase de ese proyecto → Configuración del proyecto → "Agregar app" → Android,
registrar `com.directos.app` ahí, y reemplazar este `google-services.json` por el
que te dé la consola (los demás datos del proyecto no cambian).
