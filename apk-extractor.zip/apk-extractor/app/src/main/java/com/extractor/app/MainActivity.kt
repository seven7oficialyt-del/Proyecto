package com.extractor.app

import android.app.Activity
import android.content.ContentValues
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class App(
    val label: String,
    val pkg: String,
    val version: String,
    val info: ApplicationInfo,
    val updated: Long,
    val system: Boolean,
    val debug: Boolean,
    val sizeBytes: Long,
    val splits: Boolean
)

class MainActivity : Activity() {
    private var all: List<App> = emptyList()
    private val shown = ArrayList<App>()
    private lateinit var list: ListView
    private lateinit var status: TextView
    private var showSystem = false
    private var query = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.WRITE_EXTERNAL_STORAGE"), 1)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#14161A"))
            setPadding(dp(16), dp(36), dp(16), 0)
        }
        root.addView(TextView(this).apply { text = "Extractor de APK"; textSize = 24f; setTypeface(null, 1); setTextColor(Color.WHITE) })
        status = TextView(this).apply {
            text = "Cargando apps…"; textSize = 13f; setTextColor(Color.parseColor("#8A9099")); setPadding(0, dp(2), 0, dp(8))
        }
        root.addView(status)

        val search = EditText(this).apply {
            hint = "Buscar por nombre o paquete"
            setHintTextColor(Color.parseColor("#6B7280")); setTextColor(Color.WHITE)
            setSingleLine(true)
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#262A31")) }
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s.toString().trim().lowercase(); applyFilter() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        root.addView(search)

        val toggle = TextView(this).apply {
            textSize = 13f; setTextColor(Color.parseColor("#7FD1A8")); setPadding(0, dp(10), 0, dp(6))
            text = "Mostrando: apps instaladas por ti (toca para incluir apps del sistema)"
            setOnClickListener {
                showSystem = !showSystem
                text = if (showSystem) "Mostrando: todas las apps (toca para ocultar las del sistema)" else "Mostrando: apps instaladas por ti (toca para incluir apps del sistema)"
                applyFilter()
            }
        }
        root.addView(toggle)

        list = ListView(this).apply {
            divider = null
            adapter = Adapter()
            setOnItemClickListener { _, _, pos, _ -> export(shown[pos]) }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        load()
    }

    private fun load() {
        Thread {
            val pm = packageManager
            val pkgs: List<PackageInfo> = if (Build.VERSION.SDK_INT >= 33)
                pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0))
            else @Suppress("DEPRECATION") pm.getInstalledPackages(0)
            val apps = pkgs.mapNotNull { p ->
                val ai = p.applicationInfo ?: return@mapNotNull null
                val sys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                App(
                    label = pm.getApplicationLabel(ai).toString(),
                    pkg = p.packageName,
                    version = p.versionName ?: "?",
                    info = ai,
                    updated = p.lastUpdateTime,
                    system = sys,
                    debug = (ai.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0,
                    sizeBytes = File(ai.sourceDir).length(),
                    splits = !ai.splitSourceDirs.isNullOrEmpty()
                )
            }.sortedByDescending { it.updated }
            runOnUiThread { all = apps; applyFilter() }
        }.start()
    }

    private fun applyFilter() {
        shown.clear()
        shown.addAll(all.filter { (showSystem || !it.system) && (query.isEmpty() || it.label.lowercase().contains(query) || it.pkg.lowercase().contains(query)) })
        (list.adapter as BaseAdapter).notifyDataSetChanged()
        status.text = "${shown.size} apps · toca una para guardar su APK en Descargas"
    }

    // ------------------------------------------------------------------ exportar
    private fun safe(s: String) = s.replace(Regex("[^A-Za-z0-9._-]+"), "_")

    private fun export(a: App) {
        status.text = "Guardando ${a.label}…"
        Thread {
            try {
                val files = ArrayList<File>()
                files.add(File(a.info.sourceDir))
                a.info.splitSourceDirs?.forEach { files.add(File(it)) }
                val base = "${safe(a.label)}_${safe(a.version)}"
                val name: String
                val mime: String
                val writer: (OutputStream) -> Unit
                if (files.size == 1) {
                    name = "$base.apk"; mime = "application/vnd.android.package-archive"
                    writer = { out -> FileInputStream(files[0]).use { it.copyTo(out) } }
                } else {
                    // App con "splits" (bundle): se empaqueta todo en un .apks (zip instalable con SAI / Split APKs Installer)
                    name = "$base.apks"; mime = "application/zip"
                    writer = { out ->
                        ZipOutputStream(out).use { z ->
                            for (f in files) { z.putNextEntry(ZipEntry(f.name)); FileInputStream(f).use { it.copyTo(z) }; z.closeEntry() }
                        }
                    }
                }
                val where = save(name, mime, writer)
                runOnUiThread {
                    status.text = "Guardado: $where"
                    Toast.makeText(this, "Guardado en Descargas: $name", Toast.LENGTH_LONG).show()
                }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Error: ${e.javaClass.simpleName} ${e.message}" }
            }
        }.start()
    }

    private fun save(name: String, mime: String, writer: (OutputStream) -> Unit): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/APKs")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: error("No se pudo crear el archivo")
            contentResolver.openOutputStream(uri)!!.use { writer(it) }
            return "Descargas/APKs/$name"
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "APKs").apply { mkdirs() }
        File(dir, name).outputStream().use { writer(it) }
        return "Descargas/APKs/$name"
    }

    // ------------------------------------------------------------------ lista
    private inner class Adapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int) = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, parent: ViewGroup?): View {
            val a = shown[i]
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = 16
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.parseColor("#1E2127")) }
            }
            row.addView(ImageView(this@MainActivity).apply {
                try { setImageDrawable(packageManager.getApplicationIcon(a.info)) } catch (e: Exception) {}
            }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(12) })
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this@MainActivity).apply {
                text = a.label + if (a.debug) "  [DEBUG]" else ""; textSize = 16f; setTypeface(null, 1)
                setTextColor(if (a.debug) Color.parseColor("#F4B740") else Color.WHITE)
            })
            col.addView(TextView(this@MainActivity).apply {
                text = a.pkg; textSize = 12f; setTextColor(Color.parseColor("#8A9099"))
            })
            val date = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(a.updated))
            col.addView(TextView(this@MainActivity).apply {
                text = "v${a.version} · %.1f MB · $date".format(a.sizeBytes / 1048576.0) + if (a.splits) " · splits" else ""
                textSize = 12f; setTextColor(Color.parseColor("#8A9099"))
            })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            return LinearLayout(this@MainActivity).apply {
                setPadding(0, 0, 0, dp(8)); addView(row, LinearLayout.LayoutParams(-1, -2))
            }
        }
    }
}
