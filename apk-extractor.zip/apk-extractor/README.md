# Extractor de APK
Lista las apps instaladas en el celular y guarda el APK de la que elijas en Descargas/APKs.
Si la app usa "splits" (bundle), guarda un .apks con todas las partes.
Compilar: Android Studio (Build > Build APK) o GitHub Actions (workflow incluido).
