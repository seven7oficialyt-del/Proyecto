package com.miflix.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.webkit.WebView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Actualizaciones dentro de la app: la página (index.html) compara la versión publicada por el administrador
 * (Firestore meta/update) con la instalada, avisa al usuario y, al pulsar "Descargar", este objeto baja el APK
 * y abre el instalador de Android. El APK nuevo debe estar firmado con la misma llave (miflix.jks) para instalarse encima.
 */
object Updater {
    @Volatile private var busy = false
    private var pendingInstall = false

    private fun apk(a: Activity) = File(File(a.cacheDir, "update").also { it.mkdirs() }, "MiFlix.apk")

    fun versionCode(a: Activity): Int = try {
        val pi = a.packageManager.getPackageInfo(a.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else @Suppress("DEPRECATION") pi.versionCode
    } catch (e: Exception) { 0 }

    fun versionName(a: Activity): String = try {
        a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: ""
    } catch (e: Exception) { "" }

    /** Al abrir la app: si ya se instaló la versión nueva, borra el APK descargado */
    fun cleanup(a: Activity) {
        try { apk(a).takeIf { it.exists() }?.delete() } catch (e: Exception) {}
    }

    private fun js(a: Activity, web: WebView, code: String) = a.runOnUiThread { web.evaluateJavascript(code, null) }

    /** Convierte un enlace de Google Drive (compartir/ver) en descarga directa */
    private fun driveDirect(u: String): String {
        val m = Regex("drive\\.google\\.com/file/d/([\\w-]+)").find(u)
            ?: Regex("(?:drive|docs)\\.google\\.com/(?:open|uc)\\?(?:[^#]*&)?id=([\\w-]+)").find(u)
        return if (m != null) "https://drive.usercontent.google.com/download?id=" + m.groupValues[1] + "&export=download&confirm=t" else u
    }

    fun download(a: Activity, web: WebView, url: String) {
        if (busy) return
        if (!url.startsWith("https://")) { js(a, web, "mfUpd('err',0,'Enlace no válido')"); return }
        busy = true
        Thread {
            try {
                var u = driveDirect(url)
                var conn: HttpURLConnection? = null
                for (i in 0..6) {
                    val c = URL(u).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    c.instanceFollowRedirects = false
                    c.setRequestProperty("User-Agent", "MiFlix-Updater")
                    val code = c.responseCode
                    if (code in intArrayOf(301, 302, 303, 307, 308)) {
                        val loc = c.getHeaderField("Location") ?: throw Exception("Redirección sin destino")
                        c.disconnect()
                        u = URL(URL(u), loc).toString()
                        if (!u.startsWith("https://")) throw Exception("Enlace no seguro")
                        continue
                    }
                    if (code != 200) { c.disconnect(); throw Exception("Error $code al descargar") }
                    if ((c.contentType ?: "").lowercase().startsWith("text/html")) {
                        c.disconnect()
                        throw Exception("El enlace devolvió una página web, no el APK. En Drive comparte el archivo como «Cualquiera con el enlace»")
                    }
                    conn = c
                    break
                }
                val c = conn ?: throw Exception("Demasiadas redirecciones")
                val total = c.contentLengthLong
                val tmp = File(apk(a).parentFile, "MiFlix.part")
                var done = 0L
                var last = -1
                c.inputStream.use { inp ->
                    FileOutputStream(tmp).use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val p = (done * 100 / total).toInt()
                                if (p != last) { last = p; js(a, web, "mfUpd('p',$p)") }
                            }
                        }
                    }
                }
                c.disconnect()
                val dest = apk(a)
                dest.delete()
                if (!tmp.renameTo(dest)) throw Exception("No se pudo guardar el archivo")
                // Comprueba que sea un APK de MiFlix y más nuevo que el instalado
                @Suppress("DEPRECATION")
                val info = a.packageManager.getPackageArchiveInfo(dest.absolutePath, 0)
                if (info == null || info.packageName != a.packageName) { dest.delete(); throw Exception("El archivo no es un APK de MiFlix") }
                // Protección: el APK debe traer un número de versión mayor que el instalado, si no Android lo rechaza
                val newCode = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode.toInt() else @Suppress("DEPRECATION") info.versionCode
                if (newCode <= versionCode(a)) {
                    dest.delete()
                    throw Exception("El APK descargado es la versión 1.$newCode, igual o menor que la instalada (1.${versionCode(a)}). Compila y sube un APK más nuevo")
                }
                busy = false
                a.runOnUiThread { install(a, web) }
            } catch (e: Exception) {
                busy = false
                js(a, web, "mfUpd('err',0,${JSONObject.quote(e.message ?: "Error")})")
            }
        }.start()
    }

    /** Abre el instalador de Android con el APK descargado */
    fun install(a: Activity, web: WebView) {
        val f = apk(a)
        if (!f.exists()) { js(a, web, "mfUpd('err',0,'Primero descarga la actualización')"); return }
        if (Build.VERSION.SDK_INT >= 26 && !a.packageManager.canRequestPackageInstalls()) {
            // Android pide permiso una sola vez para instalar apps desde MiFlix
            pendingInstall = true
            Toast.makeText(a, L.t("Activa «Permitir de esta fuente» para MiFlix y vuelve", "Turn on “Allow from this source” for MiFlix and come back"), Toast.LENGTH_LONG).show()
            a.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.packageName)))
            return
        }
        pendingInstall = false
        try {
            val uri = FileProvider.getUriForFile(a, a.packageName + ".fileprovider", f)
            a.startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            js(a, web, "mfUpd('inst',100)")
        } catch (e: Exception) {
            js(a, web, "mfUpd('err',0,${JSONObject.quote(e.message ?: "No se pudo abrir el instalador")})")
        }
    }

    /** Al volver de los ajustes de "instalar apps desconocidas": continúa la instalación */
    fun onResume(a: Activity, web: WebView) {
        if (pendingInstall && Build.VERSION.SDK_INT >= 26 && a.packageManager.canRequestPackageInstalls()) install(a, web)
    }
}
